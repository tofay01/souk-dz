@echo off
chcp 65001 >nul
echo ============================================
echo   Souk-DZ - رفع المشروع إلى GitHub
echo ============================================
echo.
echo ضع رابط المستودع الذي أنشأته على GitHub (مثال: https://github.com/اسمك/souk-dz.git)
echo.
set /p REPO=رابط المستودع: 

git init
git add .
git commit -m "Souk-DZ initial deploy"
git branch -M main
git remote add origin %REPO%
git push -u origin main

echo.
echo ============================================
echo   تم! انتقل إلى الخطوة التالية (Vercel)
echo ============================================
pause
