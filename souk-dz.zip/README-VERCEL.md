# نشر Souq-DZ على Vercel (مجاني، بدون سيرفر) — 10 دقائق

هذا أسرع حل لرؤية موقعك على رابط **ثابت يعمل دائماً** من أي متصفح.

## ما ستحتاجه (كله مجاني):
1. حساب **GitHub** (github.com)
2. حساب **Neon** (neon.tech) — قاعدة بيانات Postgres مجانية
3. حساب **Vercel** (vercel.com) — يستورد من GitHub مباشرة

## الخطوات:

### 1) قاعدة البيانات (Neon) — 2 دقائق
- اذهب إلى neon.tech → Sign up (بإيميلك أو بجوجل)
- "Create a new project" → أي منطقة
- بعد الإنشاء: انسخ **Connection String** (يبدو هكذا):
  `postgresql://USER:PASS@ep-xxx.neon.tech/neondb?sslmode=require`
- احفظه — سنسميه `DATABASE_URL`

### 2) مزامنة الجداول مرة واحدة (من جهازك) — 3 دقائق
- ثبّت Node.js 18+ (nodejs.org)
- انسخ ملفات المشروع إلى جهازك ثم:
```bash
npm install
echo "DATABASE_URL=postgresql://USER:PASS@ep-xxx.neon.tech/neondb?sslmode=require" > .env
npx drizzle-kit push          # يبدع كل الجداول في Neon
node scripts/seed-admin.mjs    # ينشئ حساب الأدمن (admin@dzsouq.dz / admin123)
```
- ستظهر رسالة `✅ Admin ready`

### 3) الرفع إلى GitHub — 3 دقائق
```bash
git init
git add .
git commit -m "Souq-DZ"
# أنشئ مستودعاً جديداً على github.com ثم:
git remote add origin https://github.com/USERNAME/souk-dz.git
git push -u origin main
```
⚠️ تأكد أن `.env` **غير مرفوع** (فيه `node_modules` و`.env` في `.gitignore` — أضيفهما إن لم يكونا):
```bash
echo "node_modules" >> .gitignore
echo ".env" >> .gitignore
```

### 4) النشر على Vercel — 2 دقائق
- اذهب إلى vercel.com → "Add New Project" → اختر مستودع souk-dz
- أضف **Environment Variables**:
  | الاسم | القيمة |
  |---|---|
  | `DATABASE_URL` | (نفس رابط Neon) |
  | `AUTH_SECRET` | أي جملة طويلة عشوائية |
  | `CHARGILY_API_KEY` | (اتركه فارغاً الآن — وضع تجريبي) |
  | `CHARGILY_LIVE` | `false` |
  | `NEXT_PUBLIC_APP_URL` | اتركه فارغاً الآن، وحدّثه بعد النشر |
- اضغط **Deploy** → انتظر دقيقتين

### 5) النتيجة
- ستحصل على رابط ثابت: `https://souk-dz.vercel.app` — **لا يموت أبداً**
- بعد النشر: عُد إلى Environment Variables ووضّع `NEXT_PUBLIC_APP_URL=https://souk-dz.vercel.app` ثم Deploy مرة أخرى (تفعيل حماية Origin + روابط الدفع)
- الدخول: `/admin` → `admin@dzsouq.dz` / `admin123`

### لاحقاً:
- **الدفع الحقيقي**: ضع `CHARGILY_API_KEY=live_sk_...` و`CHARGILY_LIVE=true` في Vercel
- **دومين جزائري**: Vercel → Settings → Domains → أضف دومينك (يتولى SSL تلقائياً)
- **Webhook Chargily**: `https://souk-dz.vercel.app/api/payments/webhook`

## ملاحظة:
Vercel يعيد البناء تلقائياً عند كل `git push` — أي تعديل تفعله هنا في بيئة العمل، انسخه لـ GitHub وادفعه وسينعكس على الموقع مباشرة.
