#!/bin/sh
# Revive the preview: build (if missing) + app server + cloudflare tunnel
# Prints the public URL at the end.
set -e
cd "$(dirname "$0")/.."

# 1) Ensure production build
if [ ! -f .next/BUILD_ID ]; then
  echo "→ Building..."
  npm run build > /tmp/revive-build.log 2>&1 || { tail -n 20 /tmp/revive-build.log; exit 1; }
  echo "→ Build OK"
fi

# 2) Ensure app server on :3000
if ! curl -s -o /dev/null --max-time 5 http://localhost:3000/; then
  nohup npm run start -- -p 3000 > /tmp/revive-app.log 2>&1 &
  sleep 8
fi
curl -s -o /dev/null -w "→ app: %{http_code}\n" --max-time 10 http://localhost:3000/

# 3) Ensure cloudflared binary
if [ ! -x /tmp/cloudflared ]; then
  echo "→ Downloading cloudflared..."
  curl -sL -o /tmp/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
  chmod +x /tmp/cloudflared
fi

# 4) Restart tunnel if not serving
pkill -f "cloudflared tunnel" 2>/dev/null || true
sleep 1
nohup /tmp/cloudflared tunnel --url http://localhost:3000 --no-autoupdate > /tmp/revive-cf.log 2>&1 &

# 5) Wait for URL
U=""
i=0
while [ $i -lt 30 ]; do
  U=$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /tmp/revive-cf.log 2>/dev/null | head -n 1 || true)
  [ -n "$U" ] && break
  sleep 3
  i=$((i+1))
done

if [ -n "$U" ]; then
  CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 "$U/" || echo 000)
  echo "PUBLIC_URL: $U (HTTP $CODE)"
else
  echo "TUNNEL FAILED — check /tmp/revive-cf.log"
  tail -n 10 /tmp/revive-cf.log
  exit 1
fi
