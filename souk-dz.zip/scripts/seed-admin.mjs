// Creates (or upgrades) the admin account on a fresh database.
// Env: DATABASE_URL, ADMIN_EMAIL (default admin@dzsouq.dz), ADMIN_PASSWORD (default admin123)
import pg from "pg";
import bcrypt from "bcryptjs";

const url = process.env.DATABASE_URL;
if (!url) {
  console.log("⚠️ DATABASE_URL missing — skipping admin seed");
  process.exit(0);
}
const email = process.env.ADMIN_EMAIL || "admin@dzsouq.dz";
const password = process.env.ADMIN_PASSWORD || "admin123";

const client = new pg.Client({ connectionString: url });
await client.connect();
const hash = bcrypt.hashSync(password, 10);
await client.query(
  `INSERT INTO users (first_name, last_name, email, phone, password_hash, plan, status, is_admin)
   VALUES ('Admin', 'DzSouq', $1, '0550000000', $2, 'vip', 'verified', true)
   ON CONFLICT (email) DO UPDATE SET is_admin = true, status = 'verified', plan = 'vip'
   RETURNING id`,
  [email, hash]
);
console.log(`✅ Admin ready: ${email} (change password after first login!)`);
await client.end();
