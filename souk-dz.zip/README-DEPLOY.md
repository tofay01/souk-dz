# نشر Souq-DZ على سيرفرك الخاص (Docker) — 5 دقائق

المشروع جاهز بالكامل: قاعدة البيانات، الأدمن، الدفع (Chargily)، الشات، 2FA...
هذا الدليل ينشره على أي VPS (Hetzner / DigitalOcean / OVH...) بثلاث أوامر.

## المتطلبات
- سيرفر Ubuntu 22.04+ بـ 2GB RAM
- Docker + Docker Compose (`curl -fsSL https://get.docker.com | sh`)
- دومين موجه للسيرفر (A record → IP)

## خطوات النشر

```bash
# 1) انسخ ملفات المشروع إلى السيرفر
scp -r ./souk-dz root@YOUR_SERVER_IP:/opt/souk-dz

# 2) أنشئ ملف البيئة (مهم!)
cat > /opt/souk-dz/.env <<'EOF'
CHARGILY_API_KEY=live_sk_...
CHARGILY_LIVE=true
NEXT_PUBLIC_APP_URL=https://souk-dz.dz
AUTH_SECRET=شعار-عشوائي-طويل-آمن-2026
ADMIN_EMAIL=you@domain.dz
ADMIN_PASSWORD=كلمة-سر-قوية
EOF

# 3) شغّل كل شيء
cd /opt/souk-dz && docker compose up -d --build
```

النتيجة:
- ✅ `docker compose` ينشئ Postgres + الموقع تلقائياً
- ✅ `drizzle-kit push` يبدع جداول قاعدة البيانات
- ✅ `seed-admin.mjs` ينشئ حساب الأدمن (`ADMIN_EMAIL` / `ADMIN_PASSWORD`)
- ✅ الصور والمرفوعات محفوظة في volume `uploads` (لا تضيع عند التحديث)
- ✅ قاعدة البيانات محفوظة في volume `pgdata`

## SSL (Let's Encrypt) عبر Nginx

```nginx
server {
  server_name souk-dz.dz;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    client_max_body_size 80M; # لرفع الفيديو
  }
}
```
```bash
apt install nginx certbot python3-certbot-nginx
certbot --nginx -d souk-dz.dz
```

## Webhook Chargily
في لوحة Chargily أضف: `https://souk-dz.dz/api/payments/webhook`

## الصيانة اليومية
```bash
cd /opt/souk-dz
docker compose pull && docker compose up -d --build   # تحديث
docker compose logs -f web                             # السجلات
docker exec souk-dz-db-1 pg_dump -U postgres app_db > backup.sql   # نسخة احتياطية
```

## ⚠️ بعد أول دخول
1. غيّر `ADMIN_PASSWORD`
2. فعّل 2FA من لوحة الأدمن → "🔐 تأمين الحساب"
3. تأكد أن `CHARGILY_LIVE=true` مع مفتاح `live_sk_...`
