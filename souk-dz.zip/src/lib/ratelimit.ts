import { NextResponse } from "next/server";

// Simple in-memory sliding-window rate limiter (per IP + group).
// Sufficient for a single instance; for multi-node, move to Redis.

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

if (typeof setInterval !== "undefined") {
  const t = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of buckets) if (v.resetAt <= now) buckets.delete(k);
  }, 60_000);
  if (typeof t.unref === "function") t.unref();
}

export function rateLimit(key: string, limit: number, windowMs: number): { ok: boolean; retryAfter?: number } {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true };
  }
  if (b.count >= limit) return { ok: false, retryAfter: Math.max(1, Math.ceil((b.resetAt - now) / 1000)) };
  b.count++;
  return { ok: true };
}

export function ipOf(req: { headers: { get(n: string): string | null } }): string {
  return (
    (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() ||
    (req.headers.get("x-real-ip") || "").trim() ||
    "unknown"
  );
}

// Returns a 429 response when the limit is exceeded, otherwise null
export function guard429(req: { headers: { get(n: string): string | null } }, key: string, limit: number, windowMs: number, msgAr: string): NextResponse | null {
  const rl = rateLimit(`${key}:${ipOf(req)}`, limit, windowMs);
  if (!rl.ok) {
    return NextResponse.json({ error: "rate_limited", message: `⏳ ${msgAr}`, retryAfter: rl.retryAfter }, { status: 429, headers: { "Retry-After": String(rl.retryAfter) } });
  }
  return null;
}
