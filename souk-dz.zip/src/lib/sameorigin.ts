import { NextRequest, NextResponse } from "next/server";

// Same-origin (CSRF) guard for mutating endpoints.
// Active in production when NEXT_PUBLIC_APP_URL is configured; in sandbox the
// HttpOnly + SameSite=Lax cookie already blocks cross-site cookie sending.
export function sameOrigin(req: NextRequest): NextResponse | null {
  const appUrl = (process.env.NEXT_PUBLIC_APP_URL || "").trim();
  if (!appUrl) return null; // not configured → rely on SameSite=Lax
  let appHost = "";
  try {
    appHost = new URL(appUrl).host.toLowerCase();
  } catch {
    return null;
  }
  const same = (h: string | null) => {
    if (!h) return true; // no header (SSR/curl same host) → allow
    try {
      const u = new URL(h);
      return u.host.toLowerCase() === appHost;
    } catch {
      return false;
    }
  };
  const origin = req.headers.get("origin");
  const referer = req.headers.get("referer");
  if (!same(origin) || !same(referer)) {
    return NextResponse.json({ error: "origin_mismatch", message: "طلب مرفوض — مصدر غير مطابق" }, { status: 403 });
  }
  return null;
}
