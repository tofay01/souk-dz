import crypto from "crypto";

// Minimal RFC-6238 TOTP (SHA1, 30s, 6 digits) — no external deps

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

function base32Decode(s: string): Buffer {
  const clean = s.toUpperCase().replace(/=+$/, "").replace(/\s/g, "");
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx === -1) throw new Error("invalid base32");
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function generateSecret(): string {
  const bytes = crypto.randomBytes(20);
  let out = "";
  let bits = 0;
  let value = 0;
  for (const b of bytes) {
    value = (value << 8) | b;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function totpCode(secret: string, time: number = Date.now(), period = 30): string {
  const key = base32Decode(secret);
  const counter = Math.floor(time / 1000 / period);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", key).update(buf).digest();
  const off = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[off] & 0x7f) << 24) | (hmac[off + 1] << 16) | (hmac[off + 2] << 8) | hmac[off + 3];
  return String(code % 1_000_000).padStart(6, "0");
}

// ±1 window (30s before/after) for clock drift
export function verifyTotp(secret: string, token: string, window = 1, time: number = Date.now(), period = 30): boolean {
  const t = String(token).replace(/\s/g, "");
  if (!/^\d{6}$/.test(t)) return false;
  const target = Buffer.from(t);
  for (let i = -window; i <= window; i++) {
    const cand = Buffer.from(totpCode(secret, time + i * period * 1000, period));
    if (cand.length === target.length && crypto.timingSafeEqual(cand, target)) return true;
  }
  return false;
}

export function authenticatorURI(secret: string, email: string): string {
  return `otpauth://totp/Souq-DZ:${encodeURIComponent(email)}?secret=${secret}&issuer=Souq-DZ&algorithm=SHA1&digits=6&period=30`;
}
