// ─────────────────────────────────────────────────────────────
// Chargily Pay — Production-ready client (API v2)
// Docs: https://dev.chargily.com/pay-v2
//
// ENV VARS:
//   CHARGILY_API_KEY      = your secret key (test_sk_... / live_sk_...)
//                           (CHARGILY_SECRET_KEY is also accepted)
//   CHARGILY_LIVE         = optional "true" — defaults to auto-detect from key prefix
//   NEXT_PUBLIC_APP_URL   = your site public URL (success/failure/webhook URLs)
//
// If CHARGILY_API_KEY is empty → DEMO mode (mock checkout page + manual confirm)
// Webhook endpoint: POST {NEXT_PUBLIC_APP_URL}/api/payments/webhook
//   Signature: `signature` header = HMAC-SHA256(rawBody, CHARGILY_API_KEY) hex
// ─────────────────────────────────────────────────────────────

export type ChargilyMode = "demo" | "test" | "live";

type Cfg = { mode: ChargilyMode; apiKey: string | null; baseUrl: string };

// SECURITY: no keys are hardcoded in code. Without CHARGILY_API_KEY the app runs in
// DEMO mode (mock checkout). Set the env var (test_sk_... / live_sk_...) to go live.
export function chargilyConfig(): Cfg {
  const apiKey = (process.env.CHARGILY_API_KEY || process.env.CHARGILY_SECRET_KEY || "").trim();
  if (!apiKey) return { mode: "demo", apiKey: null, baseUrl: "" };
  const live = process.env.CHARGILY_LIVE === "true" ? true : apiKey.startsWith("live");
  const baseUrl =
    process.env.CHARGILY_API_URL ||
    (live ? "https://pay.chargily.dz/api/v2" : "https://pay.chargily.dz/test/api/v2");
  return { mode: live ? "live" : "test", apiKey, baseUrl };
}

export function chargilyMode(): ChargilyMode {
  return chargilyConfig().mode;
}

export function publicAppUrl(reqUrl?: string) {
  return process.env.NEXT_PUBLIC_APP_URL || (reqUrl ? new URL(reqUrl).origin : "http://localhost:3000");
}

// External webhook (Supabase Edge Function) — every event is forwarded there
export function externalWebhookUrl(): string {
  return (process.env.CHARGILY_EXTERNAL_WEBHOOK || "").trim();
}

export type CheckoutInput = {
  amountCents: number; // amounts are in centimes — 50 DZD = 5000
  description: string;
  successUrl: string;
  failureUrl: string;
  metadata?: Record<string, string>;
  locale?: "ar" | "en" | "fr";
  paymentMethod?: "edahabia" | "cib"; // preselect card, customer can change on Chargily page
};

export async function createChargilyCheckout(input: CheckoutInput, reqUrl?: string): Promise<{ id: string; url: string; mode: ChargilyMode }> {
  const cfg = chargilyConfig();
  const base = publicAppUrl(reqUrl);

  if (cfg.mode === "demo" || !cfg.apiKey) {
    const id = `demo_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    return { id, url: `${base}/paiement/${id}`, mode: "demo" };
  }

  try {
    const body: Record<string, unknown> = {
      amount: Math.max(1, Math.round(input.amountCents)),
      currency: "dzd",
      payment_method: input.paymentMethod ?? "edahabia",
      success_url: input.successUrl,
      failure_url: input.failureUrl,
      webhook_endpoint: `${base}/api/payments/webhook`,
      description: input.description.slice(0, 500),
      locale: input.locale ?? "ar",
      metadata: input.metadata ?? {},
    };
    const headers = { Authorization: `Bearer ${cfg.apiKey}`, "Content-Type": "application/json" };
    let res = await fetch(`${cfg.baseUrl}/checkouts`, { method: "POST", headers, body: JSON.stringify(body) });
    let data: any = await res.json().catch(() => ({}));
    // Retry without webhook_endpoint if Chargily rejects the endpoint
    if (!res.ok && body.webhook_endpoint) {
      const b2: Record<string, unknown> = { ...body };
      delete b2.webhook_endpoint;
      res = await fetch(`${cfg.baseUrl}/checkouts`, { method: "POST", headers, body: JSON.stringify(b2) });
      data = await res.json().catch(() => ({}));
    }
    if (!res.ok) {
      console.error("Chargily checkout error:", res.status, JSON.stringify(data).slice(0, 300));
      const id = `demo_err_${Date.now().toString(36)}`;
      return { id, url: `${base}/paiement/${id}?err=1`, mode: "demo" };
    }
    return {
      id: String(data?.id ?? ""),
      url: String(data?.checkout_url ?? data?.url ?? `${base}/paiement/`),
      mode: cfg.mode,
    };
  } catch (e) {
    console.error("Chargily network error:", e);
    const id = `demo_fallback_${Date.now().toString(36)}`;
    return { id, url: `${base}/paiement/${id}?err=1`, mode: "demo" };
  }
}

// Verify `signature` header: HMAC-SHA256(rawBody, apiKey) hex — per Chargily docs
export function verifyChargilySignature(rawBody: string, signature: string | null): boolean {
  const cfg = chargilyConfig();
  if (cfg.mode === "demo" || !cfg.apiKey) return true; // demo accepts all
  if (!signature) return false;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const crypto = require("crypto") as typeof import("crypto");
  const computed = crypto.createHmac("sha256", cfg.apiKey).update(rawBody).digest("hex");
  try {
    const a = Buffer.from(computed, "hex");
    const b = Buffer.from(signature, "hex");
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
