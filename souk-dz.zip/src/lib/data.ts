export const WILAYAS: { code: string; ar: string; fr: string }[] = [
  { code: "01", ar: "أدرار", fr: "Adrar" },
  { code: "02", ar: "الشلف", fr: "Chlef" },
  { code: "03", ar: "الأغواط", fr: "Laghouat" },
  { code: "04", ar: "أم البواقي", fr: "Oum El Bouaghi" },
  { code: "05", ar: "باتنة", fr: "Batna" },
  { code: "06", ar: "بجاية", fr: "Béjaïa" },
  { code: "07", ar: "بسكرة", fr: "Biskra" },
  { code: "08", ar: "بشار", fr: "Béchar" },
  { code: "09", ar: "البليدة", fr: "Blida" },
  { code: "10", ar: "البويرة", fr: "Bouira" },
  { code: "11", ar: "تمنراست", fr: "Tamanrasset" },
  { code: "12", ar: "تبسة", fr: "Tébessa" },
  { code: "13", ar: "تلمسان", fr: "Tlemcen" },
  { code: "14", ar: "تيارت", fr: "Tiaret" },
  { code: "15", ar: "تيزي وزو", fr: "Tizi Ouzou" },
  { code: "16", ar: "الجزائر", fr: "Alger" },
  { code: "17", ar: "الجلفة", fr: "Djelfa" },
  { code: "18", ar: "جيجل", fr: "Jijel" },
  { code: "19", ar: "سطيف", fr: "Sétif" },
  { code: "20", ar: "سعيدة", fr: "Saïda" },
  { code: "21", ar: "سكيكدة", fr: "Skikda" },
  { code: "22", ar: "سيدي بلعباس", fr: "Sidi Bel Abbès" },
  { code: "23", ar: "عنابة", fr: "Annaba" },
  { code: "24", ar: "قالمة", fr: "Guelma" },
  { code: "25", ar: "قسنطينة", fr: "Constantine" },
  { code: "26", ar: "المدية", fr: "Médéa" },
  { code: "27", ar: "مستغانم", fr: "Mostaganem" },
  { code: "28", ar: "المسيلة", fr: "M'Sila" },
  { code: "29", ar: "معسكر", fr: "Mascara" },
  { code: "30", ar: "ورقلة", fr: "Ouargla" },
  { code: "31", ar: "وهران", fr: "Oran" },
  { code: "32", ar: "البيض", fr: "El Bayadh" },
  { code: "33", ar: "إليزي", fr: "Illizi" },
  { code: "34", ar: "برج بوعريريج", fr: "Bordj Bou Arréridj" },
  { code: "35", ar: "بومرداس", fr: "Boumerdès" },
  { code: "36", ar: "الطارف", fr: "El Tarf" },
  { code: "37", ar: "تندوف", fr: "Tindouf" },
  { code: "38", ar: "تيسمسيلت", fr: "Tissemsilt" },
  { code: "39", ar: "الوادي", fr: "El Oued" },
  { code: "40", ar: "خنشلة", fr: "Khenchela" },
  { code: "41", ar: "سوق أهراس", fr: "Souk Ahras" },
  { code: "42", ar: "تيبازة", fr: "Tipaza" },
  { code: "43", ar: "ميلة", fr: "Mila" },
  { code: "44", ar: "عين الدفلى", fr: "Aïn Defla" },
  { code: "45", ar: "النعامة", fr: "Naâma" },
  { code: "46", ar: "عين تموشنت", fr: "Aïn Témouchent" },
  { code: "47", ar: "غرداية", fr: "Ghardaïa" },
  { code: "48", ar: "غليزان", fr: "Relizane" },
  { code: "49", ar: "تيميمون", fr: "Timimoun" },
  { code: "50", ar: "برج باجي مختار", fr: "Bordj Badji Mokhtar" },
  { code: "51", ar: "أولاد جلال", fr: "Ouled Djellal" },
  { code: "52", ar: "بني عباس", fr: "Béni Abbès" },
  { code: "53", ar: "عين صالح", fr: "In Salah" },
  { code: "54", ar: "عين قزام", fr: "In Guezzam" },
  { code: "55", ar: "تقرت", fr: "Touggourt" },
  { code: "56", ar: "جانت", fr: "Djanet" },
  { code: "57", ar: "المغير", fr: "El M'Ghair" },
  { code: "58", ar: "المنيعة", fr: "El Meniaa" },
];

export const wilayaName = (code: string, lang: "ar" | "fr") => {
  const w = WILAYAS.find((x) => x.code === code);
  if (!w) return code;
  return lang === "ar" ? `${code} - ${w.ar}` : `${code} - ${w.fr}`;
};

export const CATEGORIES: { slug: string; ar: string; fr: string; icon: string; color: string }[] = [
  { slug: "immobilier", ar: "عقارات", fr: "Immobilier", icon: "🏠", color: "#2563eb" },
  { slug: "vehicules", ar: "سيارات", fr: "Véhicules", icon: "🚗", color: "#059669" },
  { slug: "materiels", ar: "معدات مهنية", fr: "Matériel pro", icon: "🧰", color: "#7c3aed" },
  { slug: "emploi", ar: "وظائف", fr: "Emploi", icon: "💼", color: "#db2777" },
  { slug: "mode", ar: "أزياء", fr: "Mode", icon: "👕", color: "#0891b2" },
  { slug: "maison", ar: "منزل وحديقة", fr: "Maison & Jardin", icon: "🌿", color: "#ea580c" },
  { slug: "famille", ar: "عائلة", fr: "Famille", icon: "👶", color: "#be123c" },
  { slug: "electronique", ar: "إلكترونيات", fr: "Électronique", icon: "📱", color: "#0d9488" },
  { slug: "loisirs", ar: "ترفيه", fr: "Loisirs", icon: "⚽", color: "#16a34a" },
  { slug: "autres", ar: "أخرى", fr: "Autres", icon: "📦", color: "#475569" },
  { slug: "bonsplans", ar: "عروض!", fr: "Bons plans !", icon: "🏷️", color: "#ff6e14" },
];

export const categoryName = (slug: string, lang: "ar" | "fr") => {
  const c = CATEGORIES.find((x) => x.slug === slug);
  if (!c) return slug;
  return lang === "ar" ? c.ar : c.fr;
};

export const DELIVERY_PROVIDERS = [
  { id: "yalidine", ar: "ياليدين Yalidine", fr: "Yalidine", baseHome: 750, baseOffice: 450, perKg: 0, logo: "🟡" },
  { id: "maystro", ar: "مايسترو Maystro", fr: "Maystro Delivery", baseHome: 690, baseOffice: 420, perKg: 0, logo: "🔵" },
  { id: "ems", ar: "البريد السريع EMS", fr: "EMS Algérie", baseHome: 500, baseOffice: 350, perKg: 0, logo: "📮" },
  { id: "noest", ar: "نوست Noest Express", fr: "Noest Express", baseHome: 650, baseOffice: 400, perKg: 0, logo: "🟢" },
  { id: "cash", ar: "الدفع عند الاستلام", fr: "Cash à la livraison", baseHome: 0, baseOffice: 0, perKg: 0, logo: "💵" },
];

export function deliveryFee(providerId: string, type: "home" | "office", wilayaCode: string) {
  const p = DELIVERY_PROVIDERS.find((x) => x.id === providerId) ?? DELIVERY_PROVIDERS[0];
  const base = type === "home" ? p.baseHome : p.baseOffice;
  const remote = ["01", "11", "33", "37", "49", "50", "52", "53", "54", "56"].includes(wilayaCode) ? 350 : 0;
  const far = ["16", "31", "25", "23", "09", "19"].includes(wilayaCode) ? 0 : 120;
  return base + remote + far;
}

export const PRICING = {
  listingFee: 50,
  vipMonthly: 1500,
  vipYearly: 12000,
  storeYearly: 5000,
  currency: "DZD",
};

// Chargily/EDAHABIA max amount for a single card transaction (verified: 100,000 DA passes, 300,000 DA is rejected)
export const CARD_TX_LIMIT_DA = 100000;

// Deterministic DZD number format: Latin digits, dot thousands, no decimals (185.000)
export function formatDZN(n: number): string {
  const v = Math.round(Number(n) || 0);
  return v.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
export function formatPrice(n: number, lang: "ar" | "fr" = "fr") {
  return `${formatDZN(n)} ${lang === "ar" ? "دج" : "DA"}`;
}
