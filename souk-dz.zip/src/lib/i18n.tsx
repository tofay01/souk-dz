"use client";
import React, { createContext, useContext, useEffect, useState } from "react";

export type Lang = "ar" | "fr";

const dict = {
  ar: {
    tagline: "سوق الجزائر الأول للإعلانات المبوبة",
    searchPlaceholder: "ابحث عن سيارة، هاتف، شقة، عمل...",
    search: "ابحث",
    publish: "انشر إعلانك",
    allAds: "كل الإعلانات",
    categories: "التصنيفات",
    recent: "أحدث الإعلانات",
    featured: "إعلانات مميزة VIP",
    stores: "المتاجر",
    pricing: "الأسعار والاشتراكات",
    delivery: "التوصيل",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    logout: "خروج",
    dashboard: "لوحتي",
    admin: "الإدارة",
    wilaya: "الولاية",
    allWilayas: "كل الولايات",
    category: "التصنيف",
    allCategories: "كل التصنيفات",
    price: "السعر",
    details: "التفاصيل",
    contact: "اتصل بالبائع",
    favorite: "مفضلة",
    home: "الرئيسية",
    freeAd: "إعلان عادي — 50 دج",
    vipAd: "اشتراك VIP ومتجر — 5000 دج/سنة",
    ctaTitle: "بيع واشري في 58 ولاية",
    ctaSub: "انشر إعلانك في دقيقة، ادفع عبر Chargily Pay (CIB / EDAHABIA)، ووصّل سلعتك عبر Yalidine و Maystro و EMS.",
  },
  fr: {
    tagline: "Le marché algérien des petites annonces",
    searchPlaceholder: "Rechercher voiture, téléphone, appart, emploi...",
    search: "Rechercher",
    publish: "Publier une annonce",
    allAds: "Toutes les annonces",
    categories: "Catégories",
    recent: "Annonces récentes",
    featured: "Annonces VIP en avant",
    stores: "Boutiques",
    pricing: "Tarifs & Abonnements",
    delivery: "Livraison",
    login: "Connexion",
    register: "Créer un compte",
    logout: "Déconnexion",
    dashboard: "Mon espace",
    admin: "Admin",
    wilaya: "Wilaya",
    allWilayas: "Toutes wilayas",
    category: "Catégorie",
    allCategories: "Toutes catégories",
    price: "Prix",
    details: "Détails",
    contact: "Contacter le vendeur",
    favorite: "Favori",
    home: "Accueil",
    freeAd: "Annonce classique — 50 DA",
    vipAd: "Abonnement VIP + Boutique — 5000 DA/an",
    ctaTitle: "Achetez & vendez dans 58 wilayas",
    ctaSub: "Publiez en 1 minute, payez via Chargily Pay (CIB / EDAHABIA), livrez avec Yalidine, Maystro et EMS.",
  },
} as const;

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (typeof dict)["ar"]; dir: "rtl" | "ltr" };
const LangCtx = createContext<Ctx>({ lang: "ar", setLang: () => {}, t: dict.ar, dir: "rtl" });

export function LangProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");
  useEffect(() => {
    const s = localStorage.getItem("dz_lang") as Lang | null;
    if (s === "ar" || s === "fr") setLangState(s);
  }, []);
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    localStorage.setItem("dz_lang", lang);
  }, [lang]);
  const setLang = (l: Lang) => setLangState(l);
  return <LangCtx.Provider value={{ lang, setLang, t: dict[lang] as unknown as (typeof dict)["ar"], dir: lang === "ar" ? "rtl" : "ltr" }}>{children}</LangCtx.Provider>;
}
export const useLang = () => useContext(LangCtx);
