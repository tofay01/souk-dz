import { cookies, headers } from "next/headers";
import { getSessionFromCookie } from "./auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function getSessionUser() {
  const h = await headers();
  const c = await cookies();
  const cookieHeader = c.toString() || h.get("cookie");
  return getSessionFromCookie(cookieHeader);
}

// Central session check — also enforces session revocation via sessionVersion
export async function getDbUser() {
  const s = await getSessionUser();
  if (!s) return null;
  const rows = await db.select().from(users).where(eq(users.id, s.id)).limit(1);
  const u = rows[0];
  if (!u) return null;
  const svToken = typeof s.sv === "number" ? s.sv : 0;
  if (u.sessionVersion !== svToken) return null; // session revoked (logout-all / password change)
  return u;
}

export function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9\u0600-\u06FF]+/g, "-").replace(/-+/g, "-").slice(0, 60) + "-" + Math.random().toString(36).slice(2, 6);
}
