import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const SECRET = process.env.AUTH_SECRET || "dz-souq-secret-change-me-2026";
const SESSION_MAX_AGE = 72 * 3600; // 3 days

export type SessionUser = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  plan: string;
  status: string;
  isAdmin: boolean;
  sv?: number; // session version — bumped to revoke all sessions
};

export async function hashPassword(pw: string) {
  return bcrypt.hash(pw, 10);
}
export async function verifyPassword(pw: string, hash: string) {
  return bcrypt.compare(pw, hash);
}
export function signToken(user: SessionUser) {
  return jwt.sign(user, SECRET, { expiresIn: SESSION_MAX_AGE });
}
// Short-lived token used only for the 2FA step (no session cookie attached)
export function signTwoFactorToken(user: SessionUser) {
  return jwt.sign({ ...user, twofa: true }, SECRET, { expiresIn: "10m" });
}
export function verifyToken(token: string): SessionUser | null {
  try {
    return jwt.verify(token, SECRET) as SessionUser;
  } catch {
    return null;
  }
}
export function getSessionFromCookie(cookieHeader: string | null): SessionUser | null {
  if (!cookieHeader) return null;
  const m = cookieHeader.match(/dz_session=([^;]+)/);
  if (!m) return null;
  try {
    const u = verifyToken(decodeURIComponent(m[1]));
    if (u && (u as any).twofa) return null; // 2FA step tokens are not sessions
    return u;
  } catch {
    return null;
  }
}
export function sessionCookie(token: string) {
  // Secure in production → cookie only travels over HTTPS
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `dz_session=${encodeURIComponent(token)}; Path=/; Max-Age=${SESSION_MAX_AGE}; HttpOnly; SameSite=Lax${secure}`;
}
export function clearCookie() {
  return `dz_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax`;
}
