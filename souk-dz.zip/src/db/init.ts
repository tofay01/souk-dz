// Self-initializing database: on first hit, creates all tables (idempotent)
// and seeds the default admin account. Lets the app deploy to a brand-new
// Postgres database with zero manual steps (e.g. Vercel + Neon).
import { sql } from "drizzle-orm";
import { db } from "./index";

const DDL = `
DO $$ BEGIN CREATE TYPE plan AS ENUM ('free','vip'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE user_status AS ENUM ('pending','verified','rejected','suspended'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE listing_status AS ENUM ('pending_payment','active','rejected','sold','expired','pending_review'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE payment_status AS ENUM ('pending','paid','failed','expired'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE payment_type AS ENUM ('listing_fee','vip_subscription','store_subscription','purchase'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name varchar(100) NOT NULL,
  last_name varchar(100) NOT NULL,
  email varchar(255) NOT NULL UNIQUE,
  phone varchar(30) NOT NULL,
  password_hash text NOT NULL,
  plan plan NOT NULL DEFAULT 'free',
  status user_status NOT NULL DEFAULT 'pending',
  reject_reason text,
  id_front_url text,
  id_back_url text,
  avatar_url text,
  wilaya_code varchar(5) DEFAULT '16',
  commune varchar(120) DEFAULT '',
  address text DEFAULT '',
  is_admin boolean NOT NULL DEFAULT false,
  vip_expires_at timestamptz,
  totp_secret text,
  session_version integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title varchar(200) NOT NULL,
  description text NOT NULL,
  price integer NOT NULL DEFAULT 0,
  category varchar(80) NOT NULL,
  wilaya_code varchar(5) NOT NULL DEFAULT '16',
  commune varchar(120) DEFAULT '',
  phone varchar(30) DEFAULT '',
  condition varchar(20) DEFAULT 'used',
  images jsonb NOT NULL DEFAULT '[]',
  video_url text,
  status listing_status NOT NULL DEFAULT 'active',
  is_featured boolean NOT NULL DEFAULT false,
  is_vip boolean NOT NULL DEFAULT false,
  views integer NOT NULL DEFAULT 0,
  delivery_available boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  name varchar(150) NOT NULL,
  slug varchar(150) NOT NULL UNIQUE,
  description text DEFAULT '',
  logo_url text DEFAULT '',
  cover_color varchar(20) DEFAULT '#0EA5E9',
  wilaya_code varchar(5) DEFAULT '16',
  commune varchar(120) DEFAULT '',
  phone varchar(30) DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  paid_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type payment_type NOT NULL,
  amount integer NOT NULL,
  currency varchar(10) NOT NULL DEFAULT 'DZD',
  status payment_status NOT NULL DEFAULT 'pending',
  checkout_url text DEFAULT '',
  checkout_id varchar(200) DEFAULT '',
  listing_id uuid REFERENCES listings(id) ON DELETE SET NULL,
  store_id uuid REFERENCES stores(id) ON DELETE SET NULL,
  meta jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz
);

CREATE TABLE IF NOT EXISTS delivery_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid REFERENCES listings(id) ON DELETE SET NULL,
  buyer_name varchar(150) NOT NULL,
  buyer_phone varchar(30) NOT NULL,
  buyer_wilaya varchar(5) NOT NULL,
  buyer_commune varchar(120) DEFAULT '',
  buyer_address text DEFAULT '',
  provider varchar(30) NOT NULL DEFAULT 'yalidine',
  delivery_type varchar(20) DEFAULT 'home',
  fee integer NOT NULL DEFAULT 0,
  status varchar(30) NOT NULL DEFAULT 'pending',
  tracking_code varchar(60) DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listing_id uuid NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  reason text NOT NULL,
  reporter_phone varchar(30) DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  key varchar(100) PRIMARY KEY,
  value text NOT NULL
);

CREATE TABLE IF NOT EXISTS password_resets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  phone varchar(30) NOT NULL,
  token varchar(120) NOT NULL UNIQUE,
  status varchar(20) NOT NULL DEFAULT 'pending',
  requested_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  used_at timestamptz
);

CREATE TABLE IF NOT EXISTS login_locks (
  key varchar(255) PRIMARY KEY,
  attempts integer NOT NULL DEFAULT 0,
  last_attempt_at timestamptz,
  locked_until timestamptz
);

CREATE TABLE IF NOT EXISTS admin_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid,
  action varchar(60) NOT NULL,
  target_id varchar(120),
  detail text,
  created_at timestamptz NOT NULL DEFAULT now()
);
`;

// Default admin (bcrypt hash of "admin123" — change after first login!)
const ADMIN_SEED = `
INSERT INTO users (first_name, last_name, email, phone, password_hash, plan, status, is_admin)
VALUES ('Admin', 'DzSouq', 'admin@dzsouq.dz', '0550000000',
        '$2a$10$5IovHX.b.iyWhPPn9YJNIeXLzfWfYT0nTUsmuPC7B85xIZewtOqNC',
        'vip', 'verified', true)
ON CONFLICT (email) DO NOTHING;
`;

let initPromise: Promise<void> | null = null;

export function ensureDb(): Promise<void> {
  if (!initPromise) {
    initPromise = (async () => {
      try {
        await db.execute(sql.raw(DDL));
        await db.execute(sql.raw(ADMIN_SEED));
      } catch (e) {
        // Never block the app on init errors — log for inspection
        console.error("[ensureDb] init error:", e);
      }
    })();
  }
  return initPromise;
}
