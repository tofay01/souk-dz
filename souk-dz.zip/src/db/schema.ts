import { pgTable, text, varchar, integer, boolean, timestamp, uuid, jsonb, pgEnum } from "drizzle-orm/pg-core";

export const planEnum = pgEnum("plan", ["free", "vip"]);
export const userStatusEnum = pgEnum("user_status", ["pending", "verified", "rejected", "suspended"]);
export const listingStatusEnum = pgEnum("listing_status", ["pending_payment", "active", "rejected", "sold", "expired", "pending_review"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "paid", "failed", "expired"]);
export const paymentTypeEnum = pgEnum("payment_type", ["listing_fee", "vip_subscription", "store_subscription", "purchase"]);

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 30 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  plan: planEnum("plan").default("free").notNull(),
  status: userStatusEnum("status").default("pending").notNull(),
  rejectReason: text("reject_reason"),
  idFrontUrl: text("id_front_url"),
  idBackUrl: text("id_back_url"),
  avatarUrl: text("avatar_url"),
  wilayaCode: varchar("wilaya_code", { length: 5 }).default("16"),
  commune: varchar("commune", { length: 120 }).default(""),
  address: text("address").default(""),
  isAdmin: boolean("is_admin").default(false).notNull(),
  vipExpiresAt: timestamp("vip_expires_at"),
  totpSecret: text("totp_secret"),
  sessionVersion: integer("session_version").default(0).notNull(),
  baridiMob: varchar("baridi_mob", { length: 30 }).default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const listings = pgTable("listings", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull().default(0),
  category: varchar("category", { length: 80 }).notNull(),
  wilayaCode: varchar("wilaya_code", { length: 5 }).notNull().default("16"),
  commune: varchar("commune", { length: 120 }).default(""),
  phone: varchar("phone", { length: 30 }).default(""),
  condition: varchar("condition", { length: 20 }).default("used"),
  images: jsonb("images").$type<string[]>().default([]).notNull(),
  videoUrl: text("video_url"),
  status: listingStatusEnum("status").default("active").notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  isVip: boolean("is_vip").default(false).notNull(),
  views: integer("views").default(0).notNull(),
  deliveryAvailable: boolean("delivery_available").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const stores = pgTable("stores", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull().unique(),
  name: varchar("name", { length: 150 }).notNull(),
  slug: varchar("slug", { length: 150 }).notNull().unique(),
  description: text("description").default(""),
  logoUrl: text("logo_url").default(""),
  coverColor: varchar("cover_color", { length: 20 }).default("#0EA5E9"),
  wilayaCode: varchar("wilaya_code", { length: 5 }).default("16"),
  commune: varchar("commune", { length: 120 }).default(""),
  phone: varchar("phone", { length: 30 }).default(""),
  isActive: boolean("is_active").default(true).notNull(),
  paidUntil: timestamp("paid_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  type: paymentTypeEnum("type").notNull(),
  amount: integer("amount").notNull(),
  currency: varchar("currency", { length: 10 }).default("DZD").notNull(),
  status: paymentStatusEnum("status").default("pending").notNull(),
  checkoutUrl: text("checkout_url").default(""),
  checkoutId: varchar("checkout_id", { length: 200 }).default(""),
  listingId: uuid("listing_id").references(() => listings.id, { onDelete: "set null" }),
  storeId: uuid("store_id").references(() => stores.id, { onDelete: "set null" }),
  meta: jsonb("meta").$type<Record<string, unknown>>().default({}).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  paidAt: timestamp("paid_at"),
});

export const deliveryOrders = pgTable("delivery_orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  listingId: uuid("listing_id").references(() => listings.id, { onDelete: "set null" }),
  buyerName: varchar("buyer_name", { length: 150 }).notNull(),
  buyerPhone: varchar("buyer_phone", { length: 30 }).notNull(),
  buyerWilaya: varchar("buyer_wilaya", { length: 5 }).notNull(),
  buyerCommune: varchar("buyer_commune", { length: 120 }).default(""),
  buyerAddress: text("buyer_address").default(""),
  provider: varchar("provider", { length: 30 }).notNull().default("yalidine"),
  deliveryType: varchar("delivery_type", { length: 20 }).default("home"),
  fee: integer("fee").default(0).notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(),
  trackingCode: varchar("tracking_code", { length: 60 }).default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const favorites = pgTable("favorites", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  listingId: uuid("listing_id").references(() => listings.id, { onDelete: "cascade" }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reports = pgTable("reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  listingId: uuid("listing_id").references(() => listings.id, { onDelete: "cascade" }).notNull(),
  reason: text("reason").notNull(),
  reporterPhone: varchar("reporter_phone", { length: 30 }).default(""),
  status: varchar("status", { length: 20 }).default("open").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 100 }).primaryKey(),
  value: text("value").notNull(),
});

// Password recovery requests (phone-based, admin-approved)
export const passwordResets = pgTable("password_resets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // pending | approved | used | rejected
  token: text("token"),
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  usedAt: timestamp("used_at"),
});

// Brute-force protection: 5 failed logins → 48h lock
export const loginLocks = pgTable("login_locks", {
  key: varchar("key", { length: 255 }).primaryKey(),
  attempts: integer("attempts").default(0).notNull(),
  lastAttemptAt: timestamp("last_attempt_at"),
  lockedUntil: timestamp("locked_until"),
});

// Audit trail of every admin action (who did what, when)
export const adminAudit = pgTable("admin_audit", {
  id: uuid("id").defaultRandom().primaryKey(),
  adminId: uuid("admin_id"),
  action: varchar("action", { length: 60 }).notNull(),
  targetId: varchar("target_id", { length: 120 }),
  detail: text("detail"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Admin ↔ user chat (password reset links, support, announcements)
export const messages = pgTable("messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  senderId: uuid("sender_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  recipientId: uuid("recipient_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  body: text("body").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
