"use client";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { useLang } from "@/lib/i18n";
import { formatDZN } from "@/lib/data";

// Parse "11digits-2key" | "11digits" | "13digits" → BaridiMob beneficiary code
// Full code as entered in the BMA app: 00799999 + CCP (11) + control key (2)
export function parseCcp(raw: string): { ccp: string; key: string; full: string } | null {
  const s = String(raw || "").trim();
  const m = s.match(/^(\d{11})-(\d{2})$/);
  if (m) return { ccp: m[1], key: m[2], full: `00799999${m[1]}-${m[2]}` };
  const n = s.replace(/\D/g, "");
  if (n.length === 11) return { ccp: n, key: "", full: `00799999${n}` };
  if (n.length === 13) return { ccp: n.slice(0, 11), key: n.slice(11), full: `00799999${n.slice(0, 11)}-${n.slice(11)}` };
  return null;
}

function buildQrText(info: { full: string }, amount?: number, title?: string, lang: "ar" | "fr" = "ar") {
  const lines = [
    lang === "ar" ? "Souq-DZ — دفع عبر BaridiMob" : "Souq-DZ — Paiement BrédiMob",
    lang === "ar" ? `المستفيد (00799999+CCP+مفتاح): ${info.full}` : `Bénéficiaire (00799999+CCP+clé) : ${info.full}`,
  ];
  if (amount) lines.push(lang === "ar" ? `المبلغ: ${amount} دج` : `Montant : ${amount} DA`);
  if (title) lines.push(lang === "ar" ? `المنتج: ${title}` : `Article : ${title}`);
  return lines.join("\n");
}

// Small QR image (used in the dashboard preview)
export function CcpQrImage({ ccpRaw, amount, title, size = 120 }: { ccpRaw: string; amount?: number; title?: string; size?: number }) {
  const { lang } = useLang();
  const [src, setSrc] = useState("");
  useEffect(() => {
    const info = parseCcp(ccpRaw);
    if (!info) { setSrc(""); return; }
    QRCode.toDataURL(buildQrText(info, amount, title, lang), { width: size * 2, margin: 1 }).then(setSrc).catch(() => setSrc(""));
  }, [ccpRaw, amount, title]);
  if (!src) return null;
  return <img src={src} alt="QR" style={{ width: size, height: size }} className="rounded-xl border p-1.5" />;
}

// Full payment modal: QR + beneficiary code + steps + WhatsApp reference
export function CcpQRModal({
  sellerName, ccpRaw, amount, title, waPhone, onClose,
}: {
  sellerName: string;
  ccpRaw: string;
  amount: number;
  title: string;
  waPhone: string;
  onClose: () => void;
}) {
  const { lang } = useLang();
  const [src, setSrc] = useState("");
  const info = parseCcp(ccpRaw);

  useEffect(() => {
    if (!info) return;
    QRCode.toDataURL(buildQrText(info, amount, title, lang), { width: 260, margin: 1 }).then(setSrc).catch(() => {});
  }, [info, amount, title]);

  const waMsg = encodeURIComponent(
    lang === "ar"
      ? `مرحباً 👋 — طلب من Souq-DZ\n📦 المنتج: ${title}\n💰 أنجزت تحويل BaridiMob بقيمة ${amount} دج\n🏦 إلى CCP: ${info?.full || "—"}\n🔖 رقم مرجع التحويل: [اكتب الرقم هنا]\nبانتظار التأكيد 🙏`
      : `Bonjour 👋 — Commande via Souq-DZ\n📦 Article : ${title}\n💰 Virement BrédiMob de ${amount} DA effectué\n🏦 vers le CCP : ${info?.full || "—"}\n🔖 N° de référence : [à compléter]\nEn attente de confirmation 🙏`
  );

  return (
    <div className="fixed inset-0 z-[110] grid place-items-center bg-black/70 p-4" onClick={onClose}>
      <div className="anim-up w-full max-w-sm rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <p className="text-sm font-black text-[#0b2a5b]">📱 {lang === "ar" ? "الدفع عبر BaridiMob" : "Payer par BrédiMob"}</p>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full bg-slate-100 text-sm font-black hover:bg-slate-200">✕</button>
        </div>

        {info ? (
          <>
            <div className="mt-3 rounded-2xl bg-slate-50 p-3 text-center">
              {src ? (
                <img src={src} alt="QR" className="mx-auto h-56 w-56 rounded-2xl border-2 border-slate-200 bg-white p-2" />
              ) : (
                <div className="grid h-56 w-56 animate-pulse place-items-center rounded-2xl bg-slate-100 text-xs font-bold text-slate-400">QR...</div>
              )}
              <p className="mt-2 text-[11px] font-bold text-slate-400">{lang === "ar" ? "امسح الرمز — ستنسخ بيانات التحويل" : "Scannez — les données de virement s'affichent"}</p>
            </div>

            <div className="mt-3 rounded-2xl bg-slate-900 p-3 text-center">
              <p className="text-[10px] font-bold text-slate-400">{lang === "ar" ? "الكود الكامل للمستفيد (لإدخاله يدوياً)" : "Code bénéficiaire complet (saisie manuelle)"}</p>
              <p className="mt-0.5 text-lg font-black tracking-[0.12em] text-green-300" dir="ltr">{info.full}</p>
              <p className="mt-1 text-sm font-black text-amber-300">
                {lang === "ar" ? "أرسل المبلغ:" : "Montant à envoyer :"} {formatDZN(amount)} {lang === "ar" ? "دج" : "DA"}
              </p>
              <p className="mt-0.5 text-[11px] font-bold text-slate-400 truncate">👤 {sellerName} • {title}</p>
            </div>

            <ol className="mt-3 space-y-1.5 text-[12px] font-bold text-slate-600">
              <li>1️⃣ {lang === "ar" ? "افتح تطبيق BaridiMob (BMA)" : "Ouvrez l'app BrédiMob (BMA)"}</li>
              <li>2️⃣ {lang === "ar" ? "اختر: Virement vers autre compte CCP" : "Choisissez : Virement vers autre compte CCP"}</li>
              <li>3️⃣ {lang === "ar" ? `أدخل الكود ${info.full} (أو امسح QR)` : `Saisissez ${info.full} (ou scannez le QR)`}</li>
              <li>4️⃣ {lang === "ar" ? `أدخل المبلغ ${formatDZN(amount)} دج وأكّد` : `Saisissez le montant et confirmez`}</li>
            </ol>

            {waPhone && (
              <a href={`https://wa.me/${waPhone}?text=${waMsg}`} target="_blank" rel="noreferrer" className="mt-3 block w-full rounded-2xl bg-[#25D366] py-3 text-center text-sm font-black text-white transition hover:opacity-90">
                ✅ {lang === "ar" ? "أرسلت التحويل — إرسال رقم المرجع" : "Virement envoyé — envoyer la référence"}
              </a>
            )}
          </>
        ) : (
          <p className="mt-3 rounded-2xl bg-amber-50 p-3 text-center text-xs font-bold text-amber-800">
            ⚠️ {lang === "ar" ? "البائع لم يسجّل رقم CCP صالحاً بعد" : "Le vendeur n'a pas enregistré de CCP valide"}
          </p>
        )}
      </div>
    </div>
  );
}
