"use client";
import Link from "next/link";
import { Fragment, useEffect, useRef, useState } from "react";
import { useLang } from "@/lib/i18n";
import { CATEGORIES, formatDZN } from "@/lib/data";
import { Logo, CartMark } from "@/components/Logo";
import { ProfileAvatar } from "@/components/ProfileAvatar";

export function Navbar({ user }: { user: { firstName: string; isAdmin: boolean; plan: string; avatarUrl?: string } | null }) {
  const { lang, setLang, t } = useLang();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [navAvatar, setNavAvatar] = useState<string | undefined>(user?.avatarUrl);
  useEffect(() => { setNavAvatar(user?.avatarUrl); }, [user]);
  const logoutNav = async () => {
    if (!confirm(lang === "ar" ? "تسجيل الخروج؟" : "Déconnexion ?")) return;
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/";
  };
  return (
    <>
    <header className="sticky top-0 z-50 shadow-sm">
      <TickerBar />
      <div className="bg-[#0b2a5b] text-white">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-2 text-xs">
          <span className="hidden sm:inline">🇩🇿 {lang === "ar" ? "التوصيل لـ 58 ولاية • الدفع CIB / EDAHABIA عبر Chargily Pay" : "Livraison 58 wilayas • Paiement CIB / EDAHABIA via Chargily Pay"}</span>
          <span className="sm:hidden">🇩🇿 Chargily Pay • 58 Wilayas</span>
          <div className="ms-auto flex items-center gap-2">
            <button onClick={() => setLang("ar")} className={`rounded-full px-3 py-1 font-bold ${lang === "ar" ? "bg-[#ff6e14]" : "bg-white/15 hover:bg-white/25"}`}>عربية</button>
            <button onClick={() => setLang("fr")} className={`rounded-full px-3 py-1 font-bold ${lang === "fr" ? "bg-[#ff6e14]" : "bg-white/15 hover:bg-white/25"}`}>Français</button>
          </div>
        </div>
      </div>
      <div className="bg-white">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <CartMark className="h-12 w-auto shrink-0" />
            <span className="leading-tight">
              <span className="font-logo block text-2xl font-extrabold leading-none"><span className="text-[#148a3c]">Souq-</span><span className="text-[#e3193a]">DZ</span> <span className="font-logo-ar text-xl font-black text-slate-700">سوق دز</span></span>
              <span className="block text-[11px] font-medium text-slate-500">{t.tagline}</span>
            </span>
          </Link>
          <form action="/annonces" className="hidden flex-1 items-center gap-2 md:flex">
            <div className="flex flex-1 items-center overflow-hidden rounded-xl border-2 border-[#0b2a5b]/15 bg-slate-50 focus-within:border-[#ff6e14]">
              <input name="q" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.searchPlaceholder} className="w-full bg-transparent px-4 py-2.5 text-sm outline-none" />
              <button className="btn-brand m-1 rounded-lg px-5 py-2 text-sm font-bold">🔍 {t.search}</button>
            </div>
          </form>
          <div className="ms-auto flex items-center gap-2">
            {user ? (
              <>
                <Link href="/dashboard" className="hidden items-center gap-2 rounded-xl bg-slate-100 px-3 py-1.5 text-sm font-bold text-[#0b2a5b] hover:bg-slate-200 sm:flex">
                  <ProfileAvatar user={{ name: user.firstName, avatarUrl: navAvatar }} editable size={32} onUpdated={setNavAvatar} />
                  {user.firstName} {user.plan === "vip" ? "⭐" : ""}
                </Link>
                {user.isAdmin && <Link href="/admin" className="hidden rounded-xl bg-[#0b2a5b] px-4 py-2 text-sm font-bold text-white lg:block">🛠️ {t.admin}</Link>}
                <Link href="/publier" className="btn-brand rounded-xl px-4 py-2 text-sm font-black">＋ {t.publish}</Link>
                <button onClick={logoutNav} title={t.logout} className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100 text-base hover:bg-red-100">🚪</button>
              </>
            ) : (
              <>
                <Link href="/auth/login" className="rounded-xl px-3 py-2 text-sm font-bold text-[#0b2a5b] hover:bg-slate-100">{t.login}</Link>
                <Link href="/publier" className="btn-brand rounded-xl px-4 py-2 text-sm font-black">＋ {t.publish}</Link>
              </>
            )}
            <button className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100 md:hidden" onClick={() => setOpen(!open)}>☰</button>
          </div>
        </div>
        <nav className="border-t border-slate-100">
          <div className="mx-auto flex max-w-7xl items-center gap-0.5 overflow-x-auto no-scrollbar px-4 py-1.5 text-[13px] font-bold text-slate-700">
            {CATEGORIES.map((c) => (
              <Link
                key={c.slug}
                href={c.slug === "bonsplans" ? "/annonces?featured=1" : `/annonces?category=${c.slug}`}
                className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 transition ${c.slug === "bonsplans" ? "text-[#ff6e14]" : "hover:bg-orange-50 hover:text-[#ff6e14]"}`}
              >
                <CatIcon slug={c.slug} className="h-5 w-5 shrink-0" />
                <span>{lang === "ar" ? c.ar : c.fr}</span>
              </Link>
            ))}
            <span className="mx-1.5 h-4 w-px shrink-0 bg-slate-200" />
            <Link href="/annonces" className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 hover:bg-orange-50 hover:text-[#ff6e14]">📋 {t.allAds}</Link>
            <Link href="/boutiques" className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 hover:bg-orange-50 hover:text-[#ff6e14]">🏬 {t.stores}</Link>
            <Link href="/tarifs" className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 hover:bg-orange-50 hover:text-[#ff6e14]">⭐ {t.pricing}</Link>
            <Link href="/livraison" className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 hover:bg-orange-50 hover:text-[#ff6e14]">🚚 {t.delivery}</Link>
            {user && <Link href="/dashboard" className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 hover:bg-orange-50 hover:text-[#ff6e14]">📊 {t.dashboard}</Link>}
          </div>
        </nav>
        {open && (
          <div className="border-t bg-white p-4 md:hidden">
            <form action="/annonces" className="flex gap-2">
              <input name="q" placeholder={t.searchPlaceholder} className="w-full rounded-xl border px-3 py-2 text-sm" />
              <button className="btn-brand rounded-xl px-4 py-2 text-sm font-bold">{t.search}</button>
            </form>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {!user && <Link href="/auth/login" className="rounded-xl bg-slate-100 px-3 py-2 text-center text-sm font-bold">{t.login}</Link>}
              {!user && <Link href="/auth/register" className="rounded-xl bg-slate-100 px-3 py-2 text-center text-sm font-bold">{t.register}</Link>}
              {user && <Link href="/dashboard" className="rounded-xl bg-slate-100 px-3 py-2 text-center text-sm font-bold">{t.dashboard}</Link>}
              <Link href="/tarifs" className="rounded-xl bg-orange-50 px-3 py-2 text-center text-sm font-bold text-[#ff6e14]">{t.pricing}</Link>
              {user && <button onClick={logoutNav} className="rounded-xl bg-red-50 px-3 py-2 text-center text-sm font-bold text-red-600">🚪 {t.logout}</button>}
            </div>
          </div>
        )}
      </div>
    </header>
    <ChatWidget />
    </>
  );
}

export function CatIcon({ slug, className }: { slug: string; className?: string }) {
  switch (slug) {
    case "immobilier":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8h5z" /></svg>;
    case "vehicules":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" /></svg>;
    case "materiels":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M4 10h16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2zm2 0V8a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2h-3v2h-4v-2H6z" /><path fill="#fff" d="M9.5 14.5h5v3h-5z" rx="1" /><path fill="#fff" d="m10.5 15.5 3 3 1-1-3-3z" /></svg>;
    case "emploi":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-2 .89-2 2v11c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z" /></svg>;
    case "mode":
      return <svg viewBox="0 0 16 16" className={className} fill="currentColor"><path d="M4 2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2h-1l-1 1h-4L6 2Zm0 2h.177L6 5h4l1.823-1H12a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z" /></svg>;
    case "maison":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M11.6 22c-.3-3.4-.2-6.3.6-9l1.7 1.2c-.8 2.6-.9 5.4-.7 7.8h-1.6z" /><path d="M11.4 15.4C6.3 15.4 2.5 12.3 2.5 7c5 0 8.9 3.1 8.9 8.4z" /><path d="M14 13.6c0-5 3.8-8.6 9-8.6 0 5-3.8 8.6-9 8.6z" /></svg>;
    case "famille":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M1.6 9.4 12 1.8l10.4 7.6h-3.6L12 5.2 5.2 9.4H1.6z" /><circle cx="7.6" cy="13.4" r="2.2" /><path d="M4.9 21.4c0-2.5 1.2-3.9 2.7-3.9s2.7 1.4 2.7 3.9H4.9z" /><circle cx="16.4" cy="13.4" r="2.2" /><path d="M13.7 21.4c0-2.5 1.2-3.9 2.7-3.9s2.7 1.4 2.7 3.9h-5.4z" /><circle cx="12" cy="15.6" r="1.6" /><path d="M10.4 21.4c0-1.8.7-2.9 1.6-2.9s1.6 1.1 1.6 2.9h-3.2z" /></svg>;
    case "electronique":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><rect x="6" y="1" width="12" height="22" rx="2.5" /><rect x="8" y="4.2" width="8" height="14.6" rx="1" fill="#fff" /><circle cx="12" cy="21" r="1.2" /></svg>;
    case "loisirs":
      return <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="12" r="10" /><path d="M12 7.2 16.4 10.4 14.7 15.5H9.3L7.6 10.4z" fill="currentColor" stroke="none" /><path d="M12 2v5.2M2.3 9.3l5.3 1.1M21.7 9.3l-5.3 1.1M4.5 19.9l4.8-4.4M19.5 19.9l-4.8-4.4" /></svg>;
    case "autres":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M12 2 3 7v10l9 5 9-5V7l-9-5z" /><path d="M3 7l9 5 9-5M12 12v10" stroke="#fff" strokeWidth="1.4" fill="none" /></svg>;
    case "bonsplans":
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path fillRule="evenodd" d="M20.6 12.6 12.6 20.6a2 2 0 0 1-2.8 0L2 12.8V2h10.8l7.8 7.8a2 2 0 0 1 0 2.8zM6.5 8a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" /></svg>;
    default:
      return <svg viewBox="0 0 24 24" className={className} fill="currentColor"><path d="M12 2 3 7v10l9 5 9-5V7l-9-5z" /></svg>;
  }
}

export function CategoryBar() {
  const { lang } = useLang();
  return (
    <div className="overflow-x-auto no-scrollbar rounded-2xl border border-slate-100 bg-white shadow-sm">
      <div className="flex min-w-max items-start justify-center px-4 py-5">
        {CATEGORIES.map((c, i) => (
          <Fragment key={c.slug}>
            {i > 0 && <span className="mx-1 mt-8 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-300" />}
            <Link
              href={c.slug === "bonsplans" ? "/annonces?featured=1" : `/annonces?category=${c.slug}`}
              className={`group flex w-[76px] shrink-0 flex-col items-center gap-2.5 px-1 text-center transition ${c.slug === "bonsplans" ? "text-[#ff6e14]" : "text-[#2b3a4e] hover:text-[#ff6e14]"}`}
            >
              <CatIcon slug={c.slug} className="h-10 w-10" />
              <span className="text-[12.5px] font-bold leading-tight" dir={lang === "ar" ? "rtl" : "ltr"}>{lang === "ar" ? c.ar : c.fr}</span>
            </Link>
          </Fragment>
        ))}
      </div>
    </div>
  );
}

// Repeat items so each half fills wide screens (no blank gaps mid-read),
// and scale duration with content width so perceived speed stays constant.
function tickerEstimate(seq: string[], size: number) {
  return seq.reduce((w, it) => w + it.length * size * 0.62 + 68, 0);
}
function tickerSeq(items: string[], size: number, target = 1600) {
  let seq = [...items];
  let guard = 0;
  while (tickerEstimate(seq, size) < target && guard < 12) { seq = [...seq, ...items]; guard++; }
  return seq;
}

export function TickerMarquee({ items, speed, size, color }: { items: string[]; speed: number; size: number; color: string }) {
  const seq = tickerSeq(items, size);
  const estW = tickerEstimate(seq, size);
  const duration = Math.max(5, speed * (estW / 1600));
  const half = (key: string) => (
    <div key={key} className="flex w-max shrink-0 items-center">
      {seq.map((it, i) => (
        <span key={i} className="mx-8 inline-flex items-center gap-2 whitespace-nowrap font-bold" style={{ fontSize: size, color }}>
          <span style={{ fontSize: size + 1 }}>📢</span>
          {it}
        </span>
      ))}
    </div>
  );
  return (
    <div className="overflow-hidden" dir="ltr">
      <div className="ticker-anim flex w-max" style={{ animationDuration: `${duration}s` }}>
        {half("a")}
        {half("b")}
      </div>
    </div>
  );
}

export function TickerBar() {
  const { lang } = useLang();
  const [tick, setTick] = useState<{ items: string[]; speed: number; fontSize: number; color: string; enabled: boolean } | null>(null);
  useEffect(() => {
    const f = () => fetch("/api/ticker").then((r) => r.json()).then((d) => d && setTick(d)).catch(() => {});
    f();
    const iv = setInterval(f, 60000);
    return () => clearInterval(iv);
  }, []);
  if (!tick?.enabled || !tick.items?.length) return null;
  return (
    <div className="overflow-hidden bg-[#071b3a]">
      <div className="flex items-center">
        <span className="z-10 shrink-0 bg-[#c8102e] px-3 py-1.5 text-[11px] font-black text-white shadow-lg">📰 {lang === "ar" ? "أخبار & عروض" : "Actus & Offres"}</span>
        <div className="relative flex-1 py-1.5">
          <TickerMarquee items={tick.items} speed={tick.speed} size={tick.fontSize} color={tick.color} />
        </div>
      </div>
    </div>
  );
}

export function ListingCard({ l, lang }: { l: { id: string; title: string; price: number; images: string[]; wilayaCode: string; category: string; createdAt: string | Date; isVip?: boolean; isFeatured?: boolean; videoUrl?: string }; lang: "ar" | "fr" }) {
  const img = l.images?.[0] || "";
  return (
    <Link href={`/annonces/${l.id}`} className="card-hover relative overflow-hidden rounded-2xl border border-slate-100 bg-white">
      {(l.isVip || l.isFeatured) && <span className="absolute start-2 top-2 z-10 rounded-full bg-gradient-to-l from-amber-400 to-orange-500 px-2.5 py-1 text-[11px] font-black text-white shadow">⭐ VIP</span>}
      {l.videoUrl && <span className="absolute end-2 top-2 z-10 rounded-full bg-black/70 px-2 py-1 text-[11px] font-black text-white">🎬</span>}
      <div className="relative h-44 bg-slate-100">
        {img ? <img src={img} alt={l.title} className="h-full w-full object-cover" loading="lazy" /> : <div className="grid h-full place-items-center text-5xl">📦</div>}
        <span className="absolute bottom-2 end-2 rounded-full bg-black/60 px-2.5 py-1 text-[11px] font-bold text-white">📍 {l.wilayaCode}</span>
      </div>
      <div className="p-3">
        <p className="clamp2 min-h-[2.6em] text-[13px] font-bold leading-snug text-slate-800">{l.title}</p>
        <p className="mt-1 text-[15px] font-black text-[#0b2a5b]" dir="ltr">{formatDZN(l.price)} <span className="text-xs font-bold text-[#ff6e14]">{lang === "ar" ? "دج" : "DA"}</span></p>
        <p className="mt-1 text-[11px] text-slate-400">{new Date(l.createdAt).toLocaleDateString(lang === "ar" ? "ar-DZ" : "fr-FR")}</p>
      </div>
    </Link>
  );
}

export function Footer() {
  const { lang } = useLang();
  const [stats, setStats] = useState<{ listings: number } | null>(null);
  useEffect(() => { fetch("/api/stats").then((r) => r.json()).then(setStats).catch(() => {}); }, []);
  return (
    <footer className="mt-12 bg-[#0b2a5b] text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <CartMark className="h-11 w-auto shrink-0" />
            <p className="font-logo text-xl font-extrabold"><span className="text-[#4ade80]">Souq-</span><span className="text-[#ff5a6e]">DZ</span> <span className="font-logo-ar font-black text-white">سوق دز</span></p>
          </div>
          <p className="mt-2 text-sm text-white/70">{lang === "ar" ? "منصة الإعلانات المبوبة الجزائرية — بيع واشري بثقة في 58 ولاية." : "La plateforme algérienne des annonces — achetez et vendez en confiance dans 58 wilayas."}</p>
          <div className="mt-3 flex gap-2 text-xs">
            <span className="rounded-lg bg-white/10 px-2 py-1">CIB 💳</span>
            <span className="rounded-lg bg-white/10 px-2 py-1">EDAHABIA 💳</span>
            <span className="rounded-lg bg-white/10 px-2 py-1">Chargily ⚡</span>
          </div>
        </div>
        <div className="text-sm">
          <p className="font-black text-[#ff6e14]">{lang === "ar" ? "روابط" : "Liens"}</p>
          <div className="mt-2 space-y-1.5 text-white/80">
            <Link className="block hover:text-white" href="/annonces">{lang === "ar" ? "كل الإعلانات" : "Toutes les annonces"}</Link>
            <Link className="block hover:text-white" href="/publier">{lang === "ar" ? "انشر إعلان" : "Publier"}</Link>
            <Link className="block hover:text-white" href="/boutiques">{lang === "ar" ? "المتاجر" : "Boutiques"}</Link>
            <Link className="block hover:text-white" href="/tarifs">{lang === "ar" ? "الأسعار" : "Tarifs"}</Link>
          </div>
        </div>
        <div className="text-sm">
          <p className="font-black text-[#ff6e14]">{lang === "ar" ? "التوصيل" : "Livraison"}</p>
          <div className="mt-2 space-y-1.5 text-white/80">
            <span className="block">🟡 Yalidine</span>
            <span className="block">🔵 Maystro</span>
            <span className="block">📮 EMS Algérie</span>
            <span className="block">🟢 Noest Express</span>
          </div>
        </div>
        <div className="text-sm">
          <p className="font-black text-[#ff6e14]">{lang === "ar" ? "مساعدة" : "Aide"}</p>
          <div className="mt-2 space-y-1.5 text-white/80">
            <Link className="block hover:text-white" href="/livraison">{lang === "ar" ? "حاسبة التوصيل" : "Calculateur livraison"}</Link>
            <Link className="block hover:text-white" href="/tarifs">{lang === "ar" ? "كيف تدفع؟" : "Comment payer ?"}</Link>
            <Link className="block hover:text-white" href="/auth/register">{lang === "ar" ? "توثيق الهوية" : "Vérification d'identité"}</Link>
          </div>
          {stats && <p className="mt-3 rounded-xl bg-white/10 px-3 py-2 text-xs">📊 {stats.listings} {lang === "ar" ? "إعلان منشور" : "annonces publiées"}</p>}
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/60">© 2026 Souq-DZ سوق دز — Alger, Algérie 🇩🇿 • CIB / EDAHABIA via Chargily Pay</div>
    </footer>
  );
}

export function ChatWidget() {
  const { lang } = useLang();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<any[]>([]);
  const [admin, setAdmin] = useState<any>(null);
  const [meId, setMeId] = useState("");
  const [draft, setDraft] = useState("");
  const [unread, setUnread] = useState(0);
  const [authed, setAuthed] = useState<boolean | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  const loadConv = async () => {
    const r = await fetch("/api/chat");
    if (r.status === 401) { setAuthed(false); return; }
    setAuthed(true);
    const d = await r.json().catch(() => ({}));
    setAdmin(d.user || null);
    setMeId(d.meId || "");
    setMsgs(d.messages || []);
  };
  useEffect(() => {
    loadConv();
    const iv = setInterval(() => {
      if (document.hidden) return;
      loadConv();
      fetch("/api/chat?peek=1").then((r) => (r.ok ? r.json() : null)).then((d) => { if (d && !open) setUnread(d.count || 0); }).catch(() => {});
    }, 15000);
    return () => clearInterval(iv);
  }, [open]);
  useEffect(() => {
    if (open) setUnread(0);
    if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight;
  }, [msgs, open]);

  const send = async () => {
    const body = draft.trim();
    if (!body) return;
    setDraft("");
    await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body }) }).catch(() => {});
    loadConv();
  };

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-5 z-[95] grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-[#25D366] to-[#128C7E] text-2xl text-white shadow-2xl transition hover:scale-110"
        style={{ insetInlineStart: "1.25rem" }}
        title={lang === "ar" ? "الدردشة مع الإدارة" : "Chat avec l'admin"}
      >
        {open ? "✕" : "💬"}
        {unread > 0 && !open && <span className="absolute -top-1 -end-1 grid h-6 min-w-6 place-items-center rounded-full bg-red-500 px-1 text-xs font-black">{unread}</span>}
      </button>
      {open && (
        <div className="fixed bottom-24 z-[95] flex w-[min(22rem,calc(100vw-2rem))] flex-col overflow-hidden rounded-3xl bg-white shadow-2xl ring-1 ring-slate-200" style={{ insetInlineStart: "1rem" }}>
          <div className="flex items-center gap-2.5 bg-[#0b2a5b] px-4 py-3 text-white">
            {admin?.avatarUrl ? <img src={admin.avatarUrl} className="h-9 w-9 rounded-full object-cover ring-2 ring-white/30" alt="" /> : <span className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-lg">🛡️</span>}
            <div className="flex-1">
              <p className="text-sm font-black">{lang === "ar" ? "الإدارة — Souq-DZ" : "Admin — Souq-DZ"}</p>
              <p className="text-[11px] text-green-300">● {lang === "ar" ? "متصل الآن" : "En ligne"}</p>
            </div>
          </div>
          <div ref={boxRef} className="h-72 space-y-2 overflow-y-auto bg-slate-50 p-3">
            {authed === false && (
              <p className="rounded-2xl bg-white p-4 text-center text-sm font-bold text-slate-500">🔐 {lang === "ar" ? "سجّل دخولك للدردشة مع الإدارة" : "Connectez-vous pour discuter"}</p>
            )}
            {authed === true && msgs.length === 0 && (
              <p className="rounded-2xl bg-white p-4 text-center text-sm font-bold text-slate-400">
                {lang === "ar" ? "ابدأ المحادثة — اسأل عن طلبك، الاسترجاع، أو أي مساعدة 🤝" : "Démarrez la conversation — questions, réinitialisation, aide 🤝"}
              </p>
            )}
            {msgs.map((m) => {
              const mine = m.senderId === meId;
              return (
                <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm font-bold leading-relaxed ${mine ? "rounded-br-md bg-[#0b2a5b] text-white" : "rounded-bl-md bg-white text-slate-800 shadow"}`}>
                    <p className="whitespace-pre-line break-words">{m.body}</p>
                    <p className={`mt-1 text-right text-[10px] ${mine ? "text-white/50" : "text-slate-400"}`} dir="ltr">{new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex items-center gap-2 border-t bg-white p-2.5">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder={lang === "ar" ? "اكتب رسالتك..." : "Écrivez..."}
              className="flex-1 rounded-xl bg-slate-100 px-3.5 py-2.5 text-sm font-bold outline-none focus:ring-2 focus:ring-[#25D366]/40"
            />
            <button onClick={send} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#25D366] text-lg text-white transition hover:scale-105">➤</button>
          </div>
        </div>
      )}
    </>
  );
}

export function useMe() {
  const [me, setMe] = useState<{ id: string; firstName: string; plan: string; isAdmin: boolean; status: string } | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("/api/auth/me").then(async (r) => {
      if (r.ok) setMe(await r.json());
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);
  return { me, loading };
}
