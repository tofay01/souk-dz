// Souq-DZ brand — shopping cart with the Algerian flag, speed lines, bag & "Souq-DZ" wordmark
// Inline SVG so web fonts (Baloo 2 / Cairo) render crisply.

function CartG({ idp }: { idp: string }) {
  return (
    <>
      <defs>
        <clipPath id={`${idp}-basket`}>
          <path d="M168 148 L432 148 L396 318 L212 318 Z" />
        </clipPath>
        <mask id={`${idp}-cresm`}>
          <circle cx="287" cy="233" r="46" fill="#fff" />
          <circle cx="301" cy="225" r="37" fill="#000" />
        </mask>
      </defs>
      {/* soft shadow */}
      <ellipse cx="300" cy="384" rx="160" ry="11" fill="#0f172a" opacity="0.08" />
      {/* speed lines */}
      <rect x="38" y="112" width="112" height="26" rx="13" fill="#1a9e4b" />
      <rect x="26" y="158" width="124" height="26" rx="13" fill="#d9dde3" />
      <rect x="40" y="204" width="112" height="26" rx="13" fill="#e3193a" />
      {/* shopping bag (behind cart) */}
      <path d="M300 62 C 306 20 356 20 362 62" fill="none" stroke="#18a04b" strokeWidth="13" strokeLinecap="round" />
      <path d="M262 62 L400 62 L412 150 L250 150 Z" fill="#18a04b" />
      {/* white parcel + red tab */}
      <path d="M404 60 L466 76 L458 150 L414 150 Z" fill="#f1f3f5" />
      <path d="M432 44 L476 57 L472 78 L428 65 Z" fill="#e3193a" />
      {/* cart handle */}
      <path d="M80 92 L150 92 L198 150" fill="none" stroke="#148a3c" strokeWidth="26" strokeLinecap="round" strokeLinejoin="round" />
      {/* basket */}
      <path d="M168 148 L432 148 L396 318 L212 318 Z" fill="#148a3c" />
      {/* flag on the basket */}
      <g clipPath={`url(#${idp}-basket)`}>
        <rect x="300" y="148" width="132" height="170" fill="#f2f4f6" />
        <circle cx="287" cy="233" r="46" fill="#e3193a" mask={`url(#${idp}-cresm)`} />
        <polygon
          points="326,216 329.8,227.7 342.2,227.8 332.4,235.1 336,246.8 326,239.6 316,246.8 319.6,235.1 309.8,227.8 322.2,227.7"
          fill="#e3193a"
        />
      </g>
      {/* axle + wheels */}
      <rect x="196" y="314" width="208" height="16" rx="8" fill="#148a3c" />
      <circle cx="252" cy="352" r="27" fill="#0e5c28" />
      <circle cx="252" cy="352" r="10" fill="#ffffff" />
      <circle cx="356" cy="352" r="27" fill="#0e5c28" />
      <circle cx="356" cy="352" r="10" fill="#ffffff" />
    </>
  );
}

// Cart mark only (no wordmark) — for navbar / footer / favicon-like uses
export function CartMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 512 400" className={className} role="img" aria-label="Souq-DZ">
      <CartG idp="m" />
    </svg>
  );
}

// Full lockup: cart + "Souq-DZ" wordmark + swoosh
export function Logo({ size = 160, className = "" }: { size?: number; className?: string }) {
  return (
    <svg viewBox="0 0 512 534" width={size} height={Math.round((size * 534) / 512)} className={className} role="img" aria-label="Souq-DZ">
      <CartG idp="l" />
      <text x="256" y="496" textAnchor="middle" fontFamily="'Baloo 2', 'Cairo', sans-serif" fontWeight="800" fontSize="98">
        <tspan fill="#148a3c">Souq-</tspan>
        <tspan fill="#e3193a">DZ</tspan>
      </text>
      <path d="M52 512 Q 185 534 298 517" fill="none" stroke="#148a3c" strokeWidth="10" strokeLinecap="round" />
      <path d="M318 519 Q 398 532 462 512" fill="none" stroke="#e3193a" strokeWidth="9" strokeLinecap="round" />
    </svg>
  );
}
