"use client";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { CartMark } from "@/components/Logo";

type IcProps = { className?: string };
export const MailIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="3" /><path d="m3 7 9 6 9-6" /></svg>
);
export const LockIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>
);
export const UserIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5" /></svg>
);
export const PhoneIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6.6 10.8a15.5 15.5 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11.4 11.4 0 0 0 .57 3.6 1 1 0 0 1-.25 1l-2.22 2.2z" /></svg>
);
export const EyeIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></svg>
);
export const EyeOffIc = ({ className = "h-5 w-5" }: IcProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3l18 18" /><path d="M10.5 5.2A10.7 10.7 0 0 1 12 5c6 0 10 7 10 7a17.8 17.8 0 0 1-3 3.7M6.6 6.6A17 17 0 0 0 2 12s4 7 10 7a10 10 0 0 0 4.3-1" /></svg>
);

export function Field({
  icon, label, children,
}: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-[13px] font-black text-slate-700">{label}</label>
      <div className="relative">
        <span className="pointer-events-none absolute inset-y-0 start-3.5 grid place-items-center text-slate-400">{icon}</span>
        {children}
      </div>
    </div>
  );
}

export const inputCls =
  "auth-input w-full rounded-2xl border-2 border-slate-200 bg-white py-3.5 pe-4 ps-11 text-sm font-bold text-slate-800 outline-none placeholder:font-medium placeholder:text-slate-300";

export function AuthLayout({ children }: { children: React.ReactNode }) {
  const { lang, setLang } = useLang();
  const feats = [
    { e: "💳", a: "دفع آمن عبر Chargily Pay — CIB / EDAHABIA", f: "Paiement sécurisé Chargily — CIB / EDAHABIA" },
    { e: "🚚", a: "توصيل لـ 58 ولاية: Yalidine • Maystro • EMS", f: "Livraison 58 wilayas : Yalidine, Maystro, EMS" },
    { e: "🪪", a: "هوية موثقة — بيع واشترِ بثقة", f: "Identité vérifiée — achetez en confiance" },
    { e: "🏬", a: "متاجر VIP احترافية من 5000 دج/سنة", f: "Boutiques VIP pro dès 5000 DA/an" },
  ];
  return (
    <div className="grid min-h-screen bg-white lg:grid-cols-2">
      {/* Brand side */}
      <div className="relative hidden flex-col justify-between overflow-hidden p-10 text-white lg:flex" style={{ background: "linear-gradient(140deg, #0b2a5b 0%, #0e3f6e 45%, #0e5c28 115%)" }}>
        <div className="blob absolute -start-24 -top-24 h-80 w-80 rounded-full bg-[#ff6e14]/25 blur-3xl" />
        <div className="blob2 absolute -end-20 bottom-0 h-96 w-96 rounded-full bg-[#148a3c]/35 blur-3xl" />
        <div className="grid-pattern pointer-events-none absolute inset-0 opacity-40" />
        <Link href="/" className="anim-up relative z-10 inline-flex w-fit items-center gap-1.5 text-sm font-bold text-white/80 transition hover:text-white">
          <span className="inline-block transition-transform group-hover:-translate-x-1">←</span>
          <span>{lang === "ar" ? "العودة للموقع" : "Retour au site"}</span>
        </Link>
        <div className="relative z-10">
          <CartMark className="float-y h-44 w-auto drop-shadow-2xl" />
          <h1 className="anim-up d2 font-logo mt-5 text-6xl font-extrabold tracking-tight">
            <span className="text-[#7ce3a1]">Souq-</span>
            <span className="text-[#ff8a97]">DZ</span>
          </h1>
          <p className="anim-up d3 font-logo-ar mt-1 text-2xl font-black text-white/95">{lang === "ar" ? "سوق دز — سوق الجزائر الأول للإعلانات" : "Souq Dz — Le marché n°1 d'Algérie"}</p>
          <p className="anim-up d4 mt-3 max-w-sm text-sm leading-relaxed text-white/70">
            {lang === "ar"
              ? "انشر إعلانك في دقيقة، ادفع ببطاقتك البنكية أو الذهبية، ووصّل سلعتك لأي ولاية. كل ذلك في منصة واحدة آمنة."
              : "Publiez en 1 minute, payez par carte CIB ou Or, livrez dans toute l'Algérie. Le tout sur une plateforme sécurisée."}
          </p>
          <ul className="mt-7 space-y-3.5">
            {feats.map((f, i) => (
              <li key={i} className={`anim-up flex items-center gap-3 text-sm font-bold ${["d3", "d4", "d5", "d6"][i]}`}>
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-white/10 text-lg backdrop-blur">{f.e}</span>
                <span className="text-white/90">{lang === "ar" ? f.a : f.f}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="relative z-10 flex flex-wrap gap-2">
          <span className="float-y rounded-xl bg-white/10 px-3 py-2 text-xs font-black backdrop-blur">💳 CIB</span>
          <span className="float-y2 rounded-xl bg-white/10 px-3 py-2 text-xs font-black backdrop-blur">🥇 EDAHABIA</span>
          <span className="float-y3 rounded-xl bg-white/10 px-3 py-2 text-xs font-black backdrop-blur">⚡ Chargily Pay</span>
          <span className="float-y2 rounded-xl bg-white/10 px-3 py-2 text-xs font-black backdrop-blur">🚚 58 Wilayas</span>
        </div>
      </div>
      {/* Form side — translucent so the zellige pattern shows through */}
      <div className="flex items-center justify-center bg-[#f6f8fb]/80 p-6">
        <div className="w-full max-w-md">
          <div className="anim-up mb-5 flex items-center justify-between">
            <Link href="/" className="text-sm font-bold text-slate-500 transition hover:text-[#148a3c]">🏠 {lang === "ar" ? "الرئيسية" : "Accueil"}</Link>
            <div className="flex rounded-full bg-white p-1 text-xs font-black shadow-sm">
              <button onClick={() => setLang("ar")} className={`rounded-full px-3.5 py-1.5 transition-all ${lang === "ar" ? "bg-[#0b2a5b] text-white shadow" : "text-slate-500 hover:text-slate-800"}`}>عربية</button>
              <button onClick={() => setLang("fr")} className={`rounded-full px-3.5 py-1.5 transition-all ${lang === "fr" ? "bg-[#0b2a5b] text-white shadow" : "text-slate-500 hover:text-slate-800"}`}>FR</button>
            </div>
          </div>
          <CartMark className="anim-up mx-auto h-24 w-auto drop-shadow-md lg:hidden" />
          {children}
        </div>
      </div>
    </div>
  );
}
