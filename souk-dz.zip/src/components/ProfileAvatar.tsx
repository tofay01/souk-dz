"use client";
import { useRef, useState } from "react";
import { useLang } from "@/lib/i18n";

// Unified profile avatar — shows a 📷 badge and inline upload when `editable`.
export function ProfileAvatar({
  user,
  editable = false,
  size = 32,
  onUpdated,
}: {
  user: { id?: string; name: string; avatarUrl?: string };
  editable?: boolean;
  size?: number;
  onUpdated?: (url: string) => void;
}) {
  const { lang } = useLang();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const pick = (e: React.MouseEvent) => {
    if (!editable || busy) return;
    e.preventDefault();
    e.stopPropagation();
    inputRef.current?.click();
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    setBusy(true);
    setErr("");
    try {
      const fd = new FormData();
      fd.append("file", f);
      const up = await fetch("/api/upload", { method: "POST", body: fd }).then((r) => r.json()).catch(() => ({}));
      const url = up?.urls?.[0];
      if (!url) throw new Error("upload");
      const r = await fetch("/api/auth/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl: url }),
      });
      if (!r.ok) throw new Error("save");
      onUpdated?.(url);
    } catch {
      setErr(lang === "ar" ? "⚠️ فشل الرفع — حاول مجدداً" : "⚠️ Échec de l'upload");
      setTimeout(() => setErr(""), 3000);
    } finally {
      setBusy(false);
    }
  };

  return (
    <span className="relative inline-flex items-center gap-1 align-middle">
      <button
        type="button"
        onClick={pick}
        disabled={!editable || busy}
        title={editable ? (lang === "ar" ? "تغيير صورة البروفايل" : "Changer ma photo") : undefined}
        className={`relative shrink-0 overflow-visible rounded-full ${editable ? "cursor-pointer ring-2 ring-[#ff6e14]/60 transition hover:ring-[#ff6e14]" : ""}`}
        style={{ width: size, height: size }}
      >
        <span className="block h-full w-full overflow-hidden rounded-full">
          {user.avatarUrl ? (
            <img src={user.avatarUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="grid h-full w-full place-items-center bg-[#0b2a5b] font-black text-white" style={{ fontSize: Math.max(11, size * 0.4) }}>
              {(user.name || "؟").trim().slice(0, 1).toUpperCase()}
            </span>
          )}
        </span>
        {busy && (
          <span className="absolute inset-0 grid place-items-center rounded-full bg-black/40">
            <span className="spin inline-block h-4 w-4 rounded-full border-2 border-white/40 border-t-white" />
          </span>
        )}
        {editable && !busy && (
          <span className="absolute -bottom-0.5 -end-0.5 grid h-[42%] w-[42%] min-h-[18px] min-w-[18px] place-items-center rounded-full bg-[#ff6e14] text-[10px] leading-none text-white shadow ring-2 ring-white">📷</span>
        )}
      </button>
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={onFile} />
      {err && <span className="text-[11px] font-bold text-red-600">{err}</span>}
    </span>
  );
}
