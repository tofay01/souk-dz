"use client";
import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";

// 2FA (TOTP) setup card for the admin dashboard
export function TwoFACard() {
  const { lang } = useLang();
  const [state, setState] = useState<"off" | "setup" | "on">("off");
  const [qr, setQr] = useState("");
  const [secret, setSecret] = useState("");
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/auth/totp")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (d) setState(d.enabled ? "on" : "off"); })
      .catch(() => {});
  }, []);

  const start = async () => {
    setMsg("");
    const d = await fetch("/api/auth/totp").then((r) => r.json()).catch(() => null);
    if (d && !d.enabled) {
      setQr(d.qr);
      setSecret(d.secret);
      setState("setup");
    }
  };

  const enable = async () => {
    setBusy(true);
    setMsg("");
    const r = await fetch("/api/auth/totp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "enable", secret, code }),
    });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) { setMsg(d.message || d.error); return; }
    setState("on");
  };

  const disable = async () => {
    const pw = prompt(lang === "ar" ? "أدخل كلمة السر لتعطيل 2FA:" : "Mot de passe pour désactiver 2FA :");
    if (pw === null) return;
    setBusy(true);
    setMsg("");
    const r = await fetch("/api/auth/totp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "disable", password: pw }),
    });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) { setMsg(d.message || d.error); return; }
    setState("off");
  };

  return (
    <div className="mt-4 rounded-3xl bg-white p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-black text-[#0b2a5b]">🔐 {lang === "ar" ? "تأمين الحساب — التحقق المزدوج (2FA)" : "Sécurité du compte — 2FA"}</p>
        {state === "on" && <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-black text-green-700">✓ {lang === "ar" ? "مفعّل" : "Actif"}</span>}
      </div>

      {state === "off" && (
        <>
          <p className="mt-2 text-sm font-bold text-slate-500">
            {lang === "ar"
              ? "فعّل الرمز المزدوج (Google Authenticator / FreeOTP): بعد التفعيل يُطلب رمز من 6 أرقام عند كل دخول للأدمن. أقوى حماية لحسابك."
              : "Activez le code à 6 chiffres (Google Authenticator / FreeOTP). Après activation, chaque connexion admin exige un code. La protection maximale."}
          </p>
          <button onClick={start} disabled={busy} className="btn-auth mt-3 rounded-xl bg-[#0b2a5b] px-6 py-2.5 text-sm font-black text-white">
            {lang === "ar" ? "تفعيل 2FA" : "Activer le 2FA"}
          </button>
        </>
      )}

      {state === "setup" && (
        <div className="mt-3 flex flex-col items-center gap-4 md:flex-row md:items-start">
          {qr && <img src={qr} alt="QR" className="rounded-2xl border p-2" />}
          <div className="flex-1 space-y-2">
            <p className="text-sm font-bold text-slate-600">
              {lang === "ar" ? "1) امسح الرمز بتطبيق المصادقة أو أدخل المفتاح يدوياً:" : "1) Scannez avec votre app ou saisissez la clé manuellement :"}
            </p>
            <code className="block break-all rounded-xl bg-slate-900 p-3 text-xs text-green-300" dir="ltr">{secret}</code>
            <p className="text-sm font-bold text-slate-600">{lang === "ar" ? "2) أدخل الرمز الحالي من التطبيق للتأكيد:" : "2) Saisissez le code actuel pour confirmer :"}</p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              inputMode="numeric"
              placeholder="••••••"
              dir="ltr"
              className="w-full max-w-[200px] rounded-xl border-2 border-slate-200 px-4 py-2.5 text-center text-xl font-black tracking-[0.4em] outline-none focus:border-[#148a3c]"
            />
            {msg && <p className="rounded-xl bg-red-50 p-2 text-xs font-bold text-red-600">⚠️ {msg}</p>}
            <div className="flex gap-2 pt-1">
              <button onClick={enable} disabled={busy || code.length < 6} className="btn-auth rounded-xl bg-[#148a3c] px-5 py-2 text-sm font-black text-white disabled:opacity-50">
                {busy ? "⏳..." : `✅ ${lang === "ar" ? "تأكيد وتفعيل" : "Confirmer"}`}
              </button>
              <button onClick={() => setState("off")} className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-bold">✕</button>
            </div>
          </div>
        </div>
      )}

      {state === "on" && (
        <>
          <p className="mt-2 text-sm font-bold text-green-700">
            {lang === "ar" ? "كل دخول الآن يتطلب رمز 6 أرقام من تطبيقك. احتفظ بمفتاح استرداد إن أمكن، ولا تعطل 2FA على حساباتك المهمة." : "Chaque connexion exige maintenant un code à 6 chiffres. Ne désactivez pas le 2FA sur un compte important."}
          </p>
          <button onClick={disable} disabled={busy} className="mt-3 rounded-xl bg-red-50 px-5 py-2 text-sm font-black text-red-600 hover:bg-red-100">
            {lang === "ar" ? "تعطيل 2FA" : "Désactiver le 2FA"}
          </button>
        </>
      )}
    </div>
  );
}
