import { NextRequest, NextResponse } from "next/server";
import { readFile } from "fs/promises";
import path from "path";

const CT: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".avif": "image/avif",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
};

// Serve uploaded files (avatars, listing photos, ID cards) from disk.
// Works in production (next start) where runtime-added public/ files are not static-served.
export async function GET(_: NextRequest, { params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  if (!/^[\w][\w.-]*\.(jpe?g|png|webp|gif|avif|mp4|webm)$/i.test(name)) {
    return NextResponse.json({ error: "bad_name" }, { status: 400 });
  }
  const candidates = [
    path.join(process.cwd(), ".data", "uploads", name),
    path.join(process.cwd(), "public", "uploads", name),
  ];
  for (const p of candidates) {
    try {
      const buf = await readFile(p);
      const ext = path.extname(name).toLowerCase();
      return new NextResponse(new Uint8Array(buf), {
        headers: {
          "Content-Type": CT[ext] || "application/octet-stream",
          "Cache-Control": "public, max-age=31536000, immutable",
        },
      });
    } catch {
      /* try next candidate */
    }
  }
  return NextResponse.json({ error: "not_found" }, { status: 404 });
}
