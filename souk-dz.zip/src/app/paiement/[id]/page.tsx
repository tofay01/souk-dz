"use client";
import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { formatDZN } from "@/lib/data";
import { Navbar, Footer, useMe } from "@/components/site";

export default function PayDemo({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { lang } = useLang();
  const { me } = useMe();
  const [pay, setPay] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/payments").then((r) => r.json()).then((all) => {
      const p = (Array.isArray(all) ? all : []).find((x: any) => x.checkoutId === id);
      setPay(p || { checkoutId: id, amount: 0 });
    });
  }, [id]);

  const confirm = async (ok: boolean) => {
    if (!ok) { window.location.href = "/paiement/fail"; return; }
    setBusy(true);
    await fetch("/api/payments/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ checkoutId: id }) });
    window.location.href = pay?.type === "purchase" ? `/paiement/success?purchase=1&listing=${pay.listingId || ""}` : "/paiement/success?demo=1";
  };

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-md px-4 py-10">
        <div className="rounded-3xl bg-white p-6 text-center shadow">
          <p className="text-5xl">⚡</p>
          <h1 className="mt-2 text-xl font-black">Chargily Pay <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs">DEMO</span></h1>
          <p className="text-xs text-slate-400" dir="ltr">checkout: {id}</p>
          {pay?.amount ? <p className="mt-2 text-3xl font-black text-[#0b2a5b]">{formatDZN(Number(pay.amount))} DA</p> : null}
          <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-start text-sm">
            <p className="font-bold">💳 CIB **** 1234</p>
            <p className="font-bold">💳 EDAHABIA **** 5678</p>
            <p className="mt-2 text-[11px] text-slate-500">{lang === "ar" ? "وضع تجريبي: في الإنتاج تظهر صفحة Chargily الحقيقية. اضغط «دفعت بنجاح» لمحاكاة الـ Webhook." : "Mode démo : en prod, page Chargily réelle. Cliquez «Payé» pour simuler le webhook."}</p>
          </div>
          <div className="mt-4 grid gap-2">
            <button onClick={() => confirm(true)} disabled={busy} className="w-full rounded-2xl bg-green-600 py-3 font-black text-white">✅ {lang === "ar" ? "دفعت بنجاح (محاكاة)" : "Paiement réussi (simuler)"}</button>
            <button onClick={() => confirm(false)} className="w-full rounded-2xl bg-slate-100 py-3 font-bold">❌ {lang === "ar" ? "إلغاء" : "Annuler"}</button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
