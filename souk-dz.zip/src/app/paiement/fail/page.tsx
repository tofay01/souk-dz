"use client";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";
export default function Fail() {
  const { lang } = useLang();
  const { me } = useMe();
  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-md px-4 py-14 text-center">
        <p className="text-7xl">❌</p>
        <h1 className="mt-3 text-2xl font-black text-red-600">{lang === "ar" ? "فشل الدفع" : "Paiement échoué"}</h1>
        <p className="mt-2 text-sm text-slate-500">{lang === "ar" ? "لم يتم خصم أي مبلغ — حاول مجدداً" : "Aucun montant débité — réessayez"}</p>
        <div className="mt-5 grid gap-2">
          <Link href="/dashboard" className="btn-brand rounded-2xl py-3 font-black">🔄 {lang === "ar" ? "حاول مجدداً" : "Réessayer"}</Link>
          <Link href="/" className="rounded-2xl bg-slate-100 py-3 font-bold">🏠 {lang === "ar" ? "الرئيسية" : "Accueil"}</Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
