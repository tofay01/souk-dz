"use client";
import { Suspense, useEffect } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";

function Inner() {
  const { lang } = useLang();
  const { me } = useMe();
  const sp = useSearchParams();
  useEffect(() => {
    const listing = sp.get("listing");
    // auto-confirm demo payments for this listing
    if (listing) {
      fetch("/api/payments").then((r) => r.json()).then((all) => {
        const p = (Array.isArray(all) ? all : []).find((x: any) => x.listingId === listing && x.status === "pending");
        if (p) fetch("/api/payments/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ checkoutId: p.checkoutId }) });
      }).catch(() => {});
    }
    if (sp.get("vip") === "1") {
      fetch("/api/payments").then((r) => r.json()).then((all) => {
        const pend = (Array.isArray(all) ? all : []).filter((x: any) => x.status === "pending" && (x.type === "store_subscription" || x.type === "vip_subscription"));
        pend.forEach((p: any) => fetch("/api/payments/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ checkoutId: p.checkoutId }) }));
      }).catch(() => {});
    }
  }, [sp]);
  const listing = sp.get("listing");
  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-md px-4 py-14 text-center">
        <p className="text-7xl">🎉</p>
        <h1 className="mt-3 text-2xl font-black text-green-700">{sp.get("purchase") === "1" ? (lang === "ar" ? "تم الشراء بنجاح!" : "Achat réussi !") : (lang === "ar" ? "تم الدفع بنجاح!" : "Paiement réussi !")}</h1>
        <p className="mt-2 text-sm text-slate-500">{sp.get("purchase") === "1" ? (lang === "ar" ? "تم الدفع عبر Chargily Pay. سيتواصل معك البائع بخصوص التسليم 📞" : "Payé via Chargily Pay. Le vendeur vous contactera. 📞") : (lang === "ar" ? "تم تفعيل إعلانك / اشتراك VIP. شكراً لثقتك" : "Annonce / VIP activé. Merci")}</p>
        <div className="mt-5 grid gap-2">
          {listing && <Link href={`/annonces/${listing}`} className="btn-brand rounded-2xl py-3 font-black">📋 {lang === "ar" ? "عرض إعلاني" : "Voir mon annonce"}</Link>}
          <Link href="/dashboard" className="rounded-2xl bg-slate-900 py-3 font-bold text-white">📊 {lang === "ar" ? "لوحتي" : "Mon espace"}</Link>
          <Link href="/" className="rounded-2xl bg-slate-100 py-3 font-bold">🏠 {lang === "ar" ? "الرئيسية" : "Accueil"}</Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
