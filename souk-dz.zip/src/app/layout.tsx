import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { LangProvider } from "@/lib/i18n";
import { ensureDb } from "@/db/init";

export const metadata: Metadata = {
  title: "Souq-DZ سوق دز — سوق الجزائر للإعلانات | Le bon coin algérien",
  description: "منصة الإعلانات المبوبة الجزائرية: سيارات، عقارات، هواتف، وظائف في 58 ولاية. الدفع Chargily Pay والتوصيل Yalidine Maystro EMS.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  // Self-initialize the schema on a fresh database (no-op otherwise)
  await ensureDb();
  return (
    <html lang="ar" dir="rtl">
      <body className="min-h-screen text-slate-900 antialiased">
        <LangProvider>{children}</LangProvider>
      </body>
    </html>
  );
}
