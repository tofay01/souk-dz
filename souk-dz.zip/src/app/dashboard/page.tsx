"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer } from "@/components/site";
import { formatPrice } from "@/lib/data";
import { CcpQrImage, parseCcp } from "@/components/CcpQR";

export default function Dashboard() {
  const { lang } = useLang();
  const [me, setMe] = useState<any>(null);
  const [ads, setAds] = useState<any[]>([]);
  const [pays, setPays] = useState<any[]>([]);
  const [sales, setSales] = useState<any[]>([]);
  const [store, setStore] = useState<any>(null);
  const [tab, setTab] = useState("ads");
  const [baridi, setBaridi] = useState("");
  const [busyB, setBusyB] = useState(false);

  const saveBaridi = async () => {
    setBusyB(true);
    await fetch("/api/auth/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ baridiMob: baridi }) });
    setMe((m: any) => ({ ...m, baridiMob: baridi }));
    setBusyB(false);
  };
  const [sForm, setSForm] = useState({ name: "", description: "", phone: "", wilayaCode: "16", commune: "", coverColor: "#0EA5E9" });

  const load = async () => {
    const m = await fetch("/api/auth/me").then((r) => (r.ok ? r.json() : null));
    if (!m) { window.location.href = "/auth/login?next=/dashboard"; return; }
    setMe(m);
    if (m?.baridiMob) setBaridi(m.baridiMob);
    fetch("/api/listings?mine=1").then((r) => r.json()).then((d) => Array.isArray(d) && setAds(d));
    fetch("/api/payments").then((r) => r.json()).then((d) => Array.isArray(d) && setPays(d));
    fetch("/api/payments?sales=1").then((r) => r.json()).then((d) => Array.isArray(d) && setSales(d));
    fetch("/api/stores").then((r) => r.json()).then((all) => {
      const s = (Array.isArray(all) ? all : []).find((x: any) => x.userId === m.id);
      if (s) { setStore(s); setSForm({ name: s.name, description: s.description || "", phone: s.phone || "", wilayaCode: s.wilayaCode || "16", commune: s.commune || "", coverColor: s.coverColor || "#0EA5E9" }); }
      else if (m.plan === "vip") setSForm((f) => ({ ...f, name: `متجر ${m.firstName} ${m.lastName}`, phone: m.phone }));
    });
  };
  useEffect(() => { load(); }, []);

  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/"; };
  const logoutAll = async () => {
    if (!confirm(lang === "ar" ? "تسجيل الخروج من جميع الأجهزة وإلغاء كل الجلسات؟" : "Se déconnecter de tous les appareils ?")) return;
    await fetch("/api/auth/logout?all=1", { method: "POST" });
    window.location.href = "/";
  };
  const del = async (id: string) => {
    if (!confirm(lang === "ar" ? "حذف الإعلان؟" : "Supprimer ?")) return;
    await fetch(`/api/listings/${id}`, { method: "DELETE" });
    load();
  };
  const saveStore = async () => {
    const r = await fetch("/api/stores", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sForm) });
    const d = await r.json();
    if (!r.ok) return alert(d.message || d.error);
    alert("✅"); load();
  };
  const confirmPay = async (cid: string) => {
    await fetch("/api/payments/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ checkoutId: cid }) });
    load();
  };

  if (!me) return <div className="grid min-h-screen place-items-center">⏳...</div>;
  const isVip = me.plan === "vip";

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="flex flex-wrap items-center gap-3 rounded-3xl bg-white p-5">
          <label className="group relative cursor-pointer" title={lang === "ar" ? "تغيير صورة البروفايل" : "Changer la photo"}>
            {me.avatarUrl ? (
              <img src={me.avatarUrl} alt="" className="h-14 w-14 rounded-2xl object-cover ring-2 ring-slate-200" />
            ) : (
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#0b2a5b] text-2xl text-white">{(me.firstName || "؟").slice(0, 1).toUpperCase()}</span>
            )}
            <span className="absolute -bottom-1 -end-1 grid h-6 w-6 place-items-center rounded-full bg-[#ff6e14] text-[11px] text-white shadow">📷</span>
            <input
              id="avatarInput"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const fd = new FormData();
                fd.append("file", f);
                const up = await fetch("/api/upload", { method: "POST", body: fd }).then((r) => r.json()).catch(() => ({}));
                const url = up?.urls?.[0];
                if (!url) { alert("⚠️ " + (lang === "ar" ? "فشل رفع الصورة" : "Échec de l'upload")); return; }
                await fetch("/api/auth/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ avatarUrl: url }) });
                load();
              }}
            />
          </label>
          <div className="flex-1">
            <p className="text-lg font-black">{me.firstName} {me.lastName} {isVip ? <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-700">⭐ VIP</span> : <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">📋 {lang === "ar" ? "عادي" : "Classique"}</span>}</p>
            <p className="text-xs text-slate-400" dir="ltr">{me.email} • {me.phone} • {me.status === "verified" ? "✅ موثّق / vérifié" : me.status === "pending" ? "⏳ قيد المراجعة" : me.status}</p>
            <button type="button" onClick={() => document.getElementById("avatarInput")?.click()} className="mt-1 text-[11px] font-black text-[#ff6e14] hover:underline">📷 {lang === "ar" ? "تغيير صورة البروفايل" : "Changer ma photo de profil"}</button>
          </div>
          {me.isAdmin && <Link href="/admin" className="rounded-xl bg-[#0b2a5b] px-4 py-2 text-sm font-bold text-white">🛠️ Admin</Link>}
          {!isVip && <Link href="/tarifs" className="rounded-xl bg-gradient-to-l from-amber-400 to-orange-500 px-4 py-2 text-sm font-black text-white">⭐ VIP — 5000 DA</Link>}
          <Link href="/publier" className="btn-brand rounded-xl px-4 py-2 text-sm font-black">＋ {lang === "ar" ? "إعلان جديد" : "Nouvelle annonce"}</Link>
          <button onClick={logoutAll} title={lang === "ar" ? "خروج من كل الأجهزة" : "Tous les appareils"} className="rounded-xl bg-red-50 px-3 py-2 text-xs font-black text-red-600 hover:bg-red-100">🚪 {lang === "ar" ? "كل الأجهزة" : "Tous"}</button>
          <button onClick={logout} className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-bold">🚪</button>
        </div>
        {/* BaridiMob receiving account */}
        <div className="mt-3 rounded-2xl border border-slate-100 bg-white p-3.5">
          <label className="text-xs font-black text-slate-600">🏦 {lang === "ar" ? "رقم CCP + مفتاح التحقق (11 رقماً + 2) — يُولَّد منه رمز QR تلقائياً" : "Numéro CCP + clé (11 + 2 chiffres) — génère un QR"}</label>
          <div className="mt-1.5 flex gap-2">
            <input value={baridi} onChange={(e) => setBaridi(e.target.value)} placeholder="00012345678-99" dir="ltr" className="flex-1 rounded-xl border-2 border-slate-200 px-3 py-2 text-sm font-bold outline-none focus:border-[#0b2a5b]" />
            <button onClick={saveBaridi} disabled={busyB} className="btn-brand rounded-xl px-5 py-2 text-sm font-black disabled:opacity-50">{busyB ? "⏳" : (lang === "ar" ? "حفظ" : "Enregistrer")}</button>
          </div>
          {parseCcp(baridi) ? (
            <div className="mt-3 flex items-center gap-3 rounded-2xl border border-green-200 bg-green-50 p-3">
              <CcpQrImage ccpRaw={baridi} size={96} />
              <div className="min-w-0 text-xs">
                <p className="font-black text-green-800">✅ {lang === "ar" ? "رمز QR جاهز!" : "QR prêt !"}</p>
                <p className="mt-0.5 font-bold leading-snug text-green-700">{lang === "ar" ? "سيظهر للمشتري في نافذة الدفع عند الضغط على «شراء عبر BaridiMob»." : "Affiché à l'acheteur dans la fenêtre de paiement."}</p>
                <p className="mt-1 font-black text-slate-600" dir="ltr">{parseCcp(baridi)!.full}</p>
              </div>
            </div>
          ) : baridi.trim() ? (
            <p className="mt-2 text-[11px] font-bold text-red-500">⚠️ {lang === "ar" ? "الصيغة: 11 رقماً + شق + مفتاح من رقمين (مثال: 00012345678-99)" : "Format : 11 chiffres + tiret + clé 2 chiffres"}</p>
          ) : null}
        </div>

        {me.status === "pending" && <div className="mt-3 rounded-2xl bg-amber-50 border border-amber-200 p-4 text-sm font-bold text-amber-800">⏳ {lang === "ar" ? "حسابك قيد مراجعة بطاقة الهوية من الإدارة — ستصلك الموافقة قريباً." : "Vérification CNI en cours."}</div>}

        <div className="mt-4 flex gap-2 overflow-x-auto">
          {[["ads", `📋 ${lang === "ar" ? "إعلاناتي" : "Mes annonces"} (${ads.length})`], ["sales", `🛒 ${lang === "ar" ? "مبيعاتي" : "Mes ventes"} (${sales.length})`], ["payments", `💳 ${lang === "ar" ? "مدفوعاتي" : "Paiements"} (${pays.length})`], ["store", `🏬 ${lang === "ar" ? "متجري" : "Ma boutique"}`]].map(([k, label]) => (
            <button key={k} onClick={() => setTab(k)} className={`whitespace-nowrap rounded-xl px-4 py-2 text-sm font-black ${tab === k ? "bg-[#0b2a5b] text-white" : "bg-white"}`}>{label}</button>
          ))}
        </div>

        {tab === "ads" && (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {ads.map((a) => (
              <div key={a.id} className="flex gap-3 rounded-2xl bg-white p-3">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100">{a.images?.[0] ? <img src={a.images[0]} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-3xl">📦</div>}</div>
          <div className="flex-1 text-sm">
            <p className="font-bold">{a.title}</p>
            <p className="font-black text-[#0b2a5b]">{formatPrice(a.price, lang)} • <span className={`text-xs ${a.status === "active" ? "text-green-600" : a.status === "rejected" || a.status === "expired" ? "text-red-500" : "text-amber-600"}`}>{
              a.status === "active" ? (lang === "ar" ? "✅ منشور" : "✅ Actif") :
              a.status === "pending_review" ? (lang === "ar" ? "⏳ قيد المراجعة" : "⏳ En révision") :
              a.status === "pending_payment" ? (lang === "ar" ? "💳 بانتظار الدفع" : "💳 À payer") :
              a.status === "sold" ? (lang === "ar" ? "✅ مباع" : "✅ Vendu") :
              a.status === "rejected" ? (lang === "ar" ? "❌ مرفوض" : "❌ Refusé") : a.status
            }</span></p>
            <div className="mt-1 flex gap-2">
              <Link href={`/annonces/${a.id}`} className="rounded-lg bg-slate-100 px-3 py-1 text-xs font-bold">👁️</Link>
              {(a.status === "pending_payment" || a.status === "pending_review") && <button onClick={() => { const p = pays.find((x: any) => x.listingId === a.id); if (p) window.location.href = p.checkoutUrl || `/paiement/${p.checkoutId}`; }} className="rounded-lg bg-orange-100 px-3 py-1 text-xs font-black text-orange-700">💳 {lang === "ar" ? "ادفع 50 دج" : "Payer 50 DA"}</button>}
                    <button onClick={() => fetch(`/api/listings/${a.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: a.status === "sold" ? "active" : "sold" }) }).then(load)} className="rounded-lg bg-slate-100 px-3 py-1 text-xs font-bold">{a.status === "sold" ? "🔄" : "✅ بيع"}</button>
                    <button onClick={() => del(a.id)} className="rounded-lg bg-red-50 px-3 py-1 text-xs font-bold text-red-600">🗑️</button>
                  </div>
                </div>
              </div>
            ))}
            {!ads.length && <p className="col-span-full rounded-2xl bg-white p-8 text-center text-sm text-slate-400">{lang === "ar" ? "لا إعلانات — انشر أول إعلان! 🎉" : "Aucune annonce"} <Link href="/publier" className="font-black text-[#ff6e14]">＋</Link></p>}
          </div>
        )}

        {tab === "sales" && (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {sales.map((s) => (
              <div key={s.id} className="rounded-2xl bg-white p-3">
                <div className="flex gap-3">
                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-slate-100">{s.productImg ? <img src={s.productImg} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-2xl">📦</div>}</div>
                  <div className="flex-1 text-sm">
                    <p className="clamp2 font-bold">{s.product}</p>
                    <p className="font-black text-[#0b2a5b]">{formatPrice(s.amount, lang)}</p>
                    <p className={`text-xs font-black ${s.status === "paid" ? "text-green-600" : "text-amber-600"}`}>{s.status === "paid" ? (lang === "ar" ? "✅ تم الدفع" : "✅ Payé") : (lang === "ar" ? "⏳ قيد الدفع" : "⏳ En attente")}</p>
                  </div>
                </div>
                <div className="mt-2 flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-xs">
                  <span className="font-bold">👤 {s.buyer?.name} {s.buyer?.phone ? <span dir="ltr"> • {s.buyer.phone}</span> : ""}</span>
                  {s.buyer?.phone && <a href={`https://wa.me/213${String(s.buyer.phone).replace(/\D/g, "").slice(1)}?text=${encodeURIComponent("مرحباً 👋 بخصوص عملية الشراء من Souq-DZ")}`} target="_blank" className="rounded-lg bg-[#25D366] px-3 py-1 font-black text-white">💬</a>}
                </div>
                <Link href={`/annonces/${s.listingId}`} className="mt-2 block rounded-xl bg-slate-100 py-1.5 text-center text-xs font-bold">{lang === "ar" ? "👁️ عرض الإعلان" : "Voir l'annonce"}</Link>
              </div>
            ))}
            {!sales.length && <p className="col-span-full rounded-2xl bg-white p-8 text-center text-sm text-slate-400">🛒 {lang === "ar" ? "لا مبيعات بعد — عندما يشتري زبون منتجك عبر Chargily ستظهر هنا مع اسمه ورقمه!" : "Aucune vente — quand un client achète via Chargily, il apparaît ici !"}</p>}
          </div>
        )}

        {tab === "payments" && (
          <div className="mt-4 space-y-2">
            {pays.map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-2xl bg-white p-4 text-sm">
                <span className="text-2xl">{p.type === "listing_fee" ? "📋" : "⭐"}</span>
                <div className="flex-1">
                  <p className="font-bold">{p.type === "listing_fee" ? (lang === "ar" ? "رسم إعلان — 50 دج" : "Frais annonce — 50 DA") : (lang === "ar" ? "اشتراك VIP + متجر — 5000 دج/سنة" : "VIP + Boutique — 5000 DA/an")}</p>
                  <p className="text-xs text-slate-400" dir="ltr">{p.checkoutId} • {new Date(p.createdAt).toLocaleString()}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-black ${p.status === "paid" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>{p.status}</span>
                {p.status === "pending" && (
                  <>
                    <a href={p.checkoutUrl || `/paiement/${p.checkoutId}`} className="rounded-xl bg-green-600 px-4 py-2 text-xs font-black text-white">💳 {lang === "ar" ? "ادفع" : "Payer"}</a>
                    <button onClick={() => confirmPay(p.checkoutId)} className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-bold" title="Demo confirm">✅</button>
                  </>
                )}
              </div>
            ))}
            {!pays.length && <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-400">💳 {lang === "ar" ? "لا مدفوعات" : "Aucun paiement"}</p>}
          </div>
        )}

        {tab === "store" && (
          <div className="mt-4 rounded-3xl bg-white p-5">
            {!isVip ? (
              <div className="text-center">
                <p className="text-5xl">🏬</p>
                <p className="mt-2 font-black">{lang === "ar" ? "المتاجر خاصة بمشتركي VIP" : "Boutiques réservées aux VIP"}</p>
                <Link href="/tarifs" className="btn-brand mt-3 inline-block rounded-xl px-6 py-2 font-bold">⭐ 5000 DA/an</Link>
              </div>
            ) : (
              <div className="grid gap-3">
                <div className="grid gap-3 md:grid-cols-2">
                  <input value={sForm.name} onChange={(e) => setSForm({ ...sForm, name: e.target.value })} placeholder={lang === "ar" ? "اسم المتجر" : "Nom boutique"} className="rounded-xl border px-4 py-2.5 text-sm" />
                  <input value={sForm.phone} onChange={(e) => setSForm({ ...sForm, phone: e.target.value })} placeholder="05..." className="rounded-xl border px-4 py-2.5 text-sm" />
                </div>
                <textarea value={sForm.description} onChange={(e) => setSForm({ ...sForm, description: e.target.value })} placeholder={lang === "ar" ? "وصف المتجر..." : "Description..."} rows={3} className="rounded-xl border px-4 py-2.5 text-sm" />
                <div className="flex items-center gap-2 text-sm">
                  <span>🎨</span>
                  {["#0EA5E9", "#ff6e14", "#059669", "#7c3aed", "#be123c", "#0b2a5b"].map((c) => (
                    <button key={c} type="button" onClick={() => setSForm({ ...sForm, coverColor: c })} className={`h-8 w-8 rounded-full ${sForm.coverColor === c ? "ring-2 ring-black" : ""}`} style={{ background: c }} />
                  ))}
                </div>
                <button onClick={saveStore} className="btn-brand rounded-2xl py-3 font-black">💾 {lang === "ar" ? "حفظ المتجر" : "Enregistrer"}</button>
                {store && <Link href={`/boutiques/${store.slug}`} className="rounded-2xl bg-slate-900 py-3 text-center font-bold text-white">🔗 {lang === "ar" ? "عرض متجري" : "Voir ma boutique"}</Link>}
              </div>
            )}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
