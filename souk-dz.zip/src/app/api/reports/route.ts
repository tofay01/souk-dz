import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reports } from "@/db/schema";
export async function POST(req: NextRequest) {
  const { listingId, reason, reporterPhone } = await req.json();
  if (!listingId || !reason) return NextResponse.json({ error: "missing" }, { status: 400 });
  await db.insert(reports).values({ listingId, reason: String(reason).slice(0, 500), reporterPhone: String(reporterPhone || "") });
  return NextResponse.json({ ok: true });
}
