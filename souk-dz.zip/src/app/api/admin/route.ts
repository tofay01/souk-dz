import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, listings, payments, stores, deliveryOrders, reports, passwordResets, messages, adminAudit } from "@/db/schema";
import { desc, eq, sql, inArray, and } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { chargilyMode } from "@/lib/chargily";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

async function requireAdmin() {
  const me = await getDbUser();
  if (!me || !me.isAdmin) return null;
  return me;
}

export async function GET(req: NextRequest) {
  const me = await requireAdmin();
  if (!me) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { searchParams } = new URL(req.url);
  const tab = searchParams.get("tab") || "stats";
  try {
    if (tab === "users") {
      const all = await db.select().from(users).orderBy(desc(users.createdAt)).limit(200);
      return NextResponse.json(all.map(({ passwordHash, ...u }) => u));
    }
    if (tab === "listings") {
      const all = await db.select().from(listings).orderBy(desc(listings.createdAt)).limit(200);
      return NextResponse.json(all);
    }
    if (tab === "payments") {
      const all = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(200);
      return NextResponse.json(all);
    }
    if (tab === "stores") {
      const all = await db.select().from(stores).orderBy(desc(stores.createdAt)).limit(100);
      return NextResponse.json(all);
    }
    if (tab === "delivery") {
      const all = await db.select().from(deliveryOrders).orderBy(desc(deliveryOrders.createdAt)).limit(100);
      return NextResponse.json(all);
    }
    if (tab === "reports") {
      const all = await db.select().from(reports).orderBy(desc(reports.createdAt)).limit(100);
      return NextResponse.json(all);
    }
    if (tab === "resets") {
      const all = await db.select().from(passwordResets).orderBy(desc(passwordResets.requestedAt)).limit(50);
      const ids = [...new Set(all.map((r) => r.userId))];
      const us = ids.length ? await db.select().from(users).where(inArray(users.id, ids)) : [];
      return NextResponse.json(
        all.map((r) => ({
          ...r,
          user: us.find((u) => u.id === r.userId)
            ? {
                name: `${us.find((u) => u.id === r.userId)!.firstName} ${us.find((u) => u.id === r.userId)!.lastName}`,
                email: us.find((u) => u.id === r.userId)!.email,
                phone: us.find((u) => u.id === r.userId)!.phone,
                idFrontUrl: us.find((u) => u.id === r.userId)!.idFrontUrl,
                idBackUrl: us.find((u) => u.id === r.userId)!.idBackUrl,
              }
            : null,
        }))
      );
    }
    // stats
    const [uCount, lCount, pSum, sCount] = await Promise.all([
      db.select({ c: sql<number>`count(*)` }).from(users),
      db.select({ c: sql<number>`count(*)` }).from(listings),
      db.select({ s: sql<number>`coalesce(sum(amount),0)` }).from(payments).where(eq(payments.status, "paid")),
      db.select({ c: sql<number>`count(*)` }).from(stores),
    ]);
    const pendingUsers = await db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.status, "pending"));
    const pendingPayments = await db.select({ c: sql<number>`count(*)` }).from(payments).where(eq(payments.status, "pending"));
    const recent = await db.select().from(listings).orderBy(desc(listings.createdAt)).limit(6);
    return NextResponse.json({
      users: Number(uCount[0]?.c || 0), listings: Number(lCount[0]?.c || 0),
      revenue: Number(pSum[0]?.s || 0), stores: Number(sCount[0]?.c || 0),
      pendingUsers: Number(pendingUsers[0]?.c || 0), pendingPayments: Number(pendingPayments[0]?.c || 0),
      chargilyMode: chargilyMode(),
      recent,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "admin-actions", 30, 10 * 60 * 1000, "أفعال كثيرة — انتظر قليلاً");
  if (denied) return denied;
  const me = await requireAdmin();
  if (!me) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = await req.json();
  const { action, id, value } = body;
  try {
    if (action === "verify_user") {
      await db.update(users).set({ status: "verified", rejectReason: null }).where(eq(users.id, id));
    } else if (action === "reject_user") {
      await db.update(users).set({ status: "rejected", rejectReason: String(value || "") }).where(eq(users.id, id));
    } else if (action === "suspend_user") {
      await db.update(users).set({ status: "suspended" }).where(eq(users.id, id));
    } else if (action === "make_admin") {
      await db.update(users).set({ isAdmin: true, status: "verified" }).where(eq(users.id, id));
    } else if (action === "moderate_listing") {
      await db.update(listings).set({ status: String(value) as "active" | "rejected" | "sold" | "expired" | "pending_payment" | "pending_review" }).where(eq(listings.id, id));
    } else if (action === "feature_listing") {
      await db.update(listings).set({ isFeatured: value === true || value === "true", isVip: value === true || value === "true" }).where(eq(listings.id, id));
    } else if (action === "confirm_payment") {
      await db.update(payments).set({ status: "paid", paidAt: new Date() }).where(eq(payments.id, id));
      const prow = (await db.select().from(payments).where(eq(payments.id, id)).limit(1))[0];
      if (prow?.listingId) await db.update(listings).set({ status: "active" }).where(eq(listings.id, prow.listingId));
      if (prow && (prow.type === "store_subscription" || prow.type === "vip_subscription")) {
        const until = new Date(); until.setFullYear(until.getFullYear() + 1);
        await db.update(users).set({ plan: "vip", vipExpiresAt: until }).where(eq(users.id, prow.userId));
      }
    } else if (action === "approve_reset") {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const token = require("crypto").randomBytes(24).toString("hex");
      const rrows = await db.select().from(passwordResets).where(eq(passwordResets.id, id)).limit(1);
      const rr = rrows[0];
      await db.update(passwordResets)
        .set({ status: "approved", token, approvedAt: new Date() })
        .where(eq(passwordResets.id, id));
      // Auto-deliver the link to the user's phone-based inbox (works even if the user is locked out / can't log in)
      if (rr) {
        const origin = req.nextUrl.origin;
        const link = `${origin}/auth/reset?token=${token}`;
        await db.insert(messages).values({
          senderId: me.id,
          recipientId: rr.userId,
          body: `🔑 رابط إعادة تعيين كلمة السر (لمرة واحدة) / Lien de réinitialisation (usage unique) :\n${link}\n\n— فريق Souq-DZ / Équipe Souq-DZ 🇩`,
        });
      }
      await db.insert(adminAudit).values({ adminId: me.id, action: "approve_reset", targetId: String(id || ""), detail: `token issued for user ${rr?.userId ?? ""}` }).catch(() => {});
      return NextResponse.json({ ok: true, token });
    } else if (action === "reject_reset") {
      await db.update(passwordResets).set({ status: "rejected" }).where(eq(passwordResets.id, id));
    } else {
      return NextResponse.json({ error: "bad_action" }, { status: 400 });
    }
    // Audit trail: who did what, when
    await db.insert(adminAudit).values({
      adminId: me.id,
      action: String(action),
      targetId: String(id || ""),
      detail: JSON.stringify({ ...(value ? { value: String(value).slice(0, 200) } : {}) }).slice(0, 500),
    }).catch(() => {});
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
