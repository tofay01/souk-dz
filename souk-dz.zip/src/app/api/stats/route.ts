import { NextResponse } from "next/server";
import { db } from "@/db";
import { listings } from "@/db/schema";
import { sql, eq } from "drizzle-orm";
export async function GET() {
  try {
    const c = await db.select({ n: sql<number>`count(*)` }).from(listings).where(eq(listings.status, "active"));
    return NextResponse.json({ listings: Number(c[0]?.n || 0) });
  } catch {
    return NextResponse.json({ listings: 12840 });
  }
}
