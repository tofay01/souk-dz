import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { and, asc, eq, inArray } from "drizzle-orm";
import { guard429 } from "@/lib/ratelimit";

// Public inbox by phone number — NO login required.
// Delivery channel for locked-out users (password reset links).
// Hardened: uniform response shape (no name/exists leak) + rate limit.
export async function GET(req: NextRequest) {
  const denied = guard429(req, "inbox", 20, 5 * 60 * 1000, "طلبات كثيرة — انتظر دقيقة ثم حاول");
  if (denied) return denied;
  const phone = String(req.nextUrl.searchParams.get("phone") || "").trim();
  if (!phone || phone.length < 8) return NextResponse.json({ messages: [] });
  try {
    const u = (await db.select().from(users).where(eq(users.phone, phone)).limit(1))[0];
    if (!u) return NextResponse.json({ messages: [] }); // same shape as "no messages"
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    const adminIds = admins.map((a) => a.id);
    const msgs = adminIds.length
      ? await db.select().from(messages).where(and(eq(messages.recipientId, u.id), inArray(messages.senderId, adminIds))).orderBy(asc(messages.createdAt)).limit(50)
      : [];
    await db.update(messages).set({ isRead: true }).where(and(eq(messages.recipientId, u.id), eq(messages.isRead, false)));
    return NextResponse.json({ messages: msgs });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ messages: [] });
  }
}
