import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { deliveryOrders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { DELIVERY_PROVIDERS, deliveryFee } from "@/lib/data";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const provider = searchParams.get("provider") || "yalidine";
  const type = (searchParams.get("type") || "home") as "home" | "office";
  const wilaya = searchParams.get("wilaya") || "16";
  const fee = deliveryFee(provider, type, wilaya);
  const p = DELIVERY_PROVIDERS.find((x) => x.id === provider);
  return NextResponse.json({ fee, provider: p, eta: wilaya === "16" ? "24-48h" : "48-72h" });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { listingId, buyerName, buyerPhone, buyerWilaya, buyerCommune, buyerAddress, provider, deliveryType } = body;
    if (!buyerName || !buyerPhone || !buyerWilaya) return NextResponse.json({ error: "missing" }, { status: 400 });
    const fee = deliveryFee(provider || "yalidine", deliveryType === "office" ? "office" : "home", buyerWilaya);
    const tracking = `DZ${Date.now().toString().slice(-8)}${Math.floor(Math.random() * 90 + 10)}`;
    const inserted = await db.insert(deliveryOrders).values({
      listingId: listingId || null, buyerName, buyerPhone, buyerWilaya,
      buyerCommune: buyerCommune || "", buyerAddress: buyerAddress || "",
      provider: provider || "yalidine", deliveryType: deliveryType || "home",
      fee, status: "pending", trackingCode: tracking,
    }).returning();
    return NextResponse.json({ ok: true, order: inserted[0] });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
