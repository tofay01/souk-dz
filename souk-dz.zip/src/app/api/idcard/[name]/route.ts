import { NextRequest, NextResponse } from "next/server";
import { readFile } from "fs/promises";
import path from "path";
import { getDbUser } from "@/lib/server";

const CT: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
};

// ID card images — ADMIN ONLY (identity proof must never be publicly accessible)
export async function GET(_: NextRequest, { params }: { params: Promise<{ name: string }> }) {
  const me = await getDbUser();
  if (!me?.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { name } = await params;
  if (!/^[\w][\w.-]*\.(jpe?g|png|webp|gif)$/i.test(name)) return NextResponse.json({ error: "bad_name" }, { status: 400 });
  const candidates = [
    path.join(process.cwd(), ".data", "id", name),
    path.join(process.cwd(), "public", "uploads", name),
  ];
  for (const p of candidates) {
    try {
      const buf = await readFile(p);
      const ext = path.extname(name).toLowerCase();
      return new NextResponse(new Uint8Array(buf), {
        headers: { "Content-Type": CT[ext] || "application/octet-stream", "Cache-Control": "private, max-age=300" },
      });
    } catch {
      /* try next */
    }
  }
  return NextResponse.json({ error: "not_found" }, { status: 404 });
}
