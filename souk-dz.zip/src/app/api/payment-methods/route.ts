import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { sameOrigin } from "@/lib/sameorigin";

const DEFAULTS: Record<string, boolean> = { cib: true, edahabia: true, baridi: true, cod: true };
const KEYS = ["cib", "edahabia", "baridi", "cod"] as const;

async function currentMethods(): Promise<Record<string, boolean>> {
  const row = (await db.select().from(settings).where(eq(settings.key, "payment_methods")).limit(1))[0];
  try {
    const parsed = row ? JSON.parse(row.value) : {};
    const out: Record<string, boolean> = { ...DEFAULTS };
    for (const k of KEYS) if (typeof parsed[k] === "boolean") out[k] = parsed[k];
    return out;
  } catch {
    return { ...DEFAULTS };
  }
}

// Public — listing pages use this to show/hide payment options
export async function GET() {
  return NextResponse.json({ methods: await currentMethods() });
}

// Admin only — activate / freeze a payment method (applied instantly)
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me?.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  try {
    const body = await req.json().catch(() => ({}));
    const m = body.methods || {};
    const next: Record<string, boolean> = {};
    for (const k of KEYS) next[k] = typeof m[k] === "boolean" ? m[k] : DEFAULTS[k];
    const value = JSON.stringify(next);
    await db.insert(settings)
      .values({ key: "payment_methods", value })
      .onConflictDoUpdate({ target: settings.key, set: { value } });
    return NextResponse.json({ ok: true, methods: next });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
