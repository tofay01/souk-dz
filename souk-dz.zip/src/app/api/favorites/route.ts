import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { favorites, listings } from "@/db/schema";
import { asc, and, eq, inArray } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { sameOrigin } from "@/lib/sameorigin";

// GET /api/favorites → my favorites list
// GET /api/favorites?listing=<id> → { fav: boolean }
// POST /api/favorites { listingId } → toggle, returns { fav }
export async function GET(req: NextRequest) {
  const me = await getDbUser();
  if (!me) return NextResponse.json([], { status: 401 });
  try {
    const listingId = req.nextUrl.searchParams.get("listing");
    if (listingId) {
      const r = await db.select().from(favorites).where(and(eq(favorites.userId, me.id), eq(favorites.listingId, listingId))).limit(1);
      return NextResponse.json({ fav: r.length > 0 });
    }
    const mine = await db.select().from(favorites).where(eq(favorites.userId, me.id)).orderBy(asc(favorites.createdAt)).limit(50);
    const ids = mine.map((f) => f.listingId);
    const ls = ids.length ? await db.select().from(listings).where(inArray(listings.id, ids)) : [];
    return NextResponse.json(
      mine
        .map((f) => {
          const l = ls.find((x) => x.id === f.listingId);
          return l ? { id: l.id, title: l.title, price: l.price, images: l.images, wilayaCode: l.wilayaCode, status: l.status } : null;
        })
        .filter(Boolean)
    );
  } catch (e) {
    console.error(e);
    return NextResponse.json([], { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  try {
    const { listingId } = await req.json();
    if (!listingId) return NextResponse.json({ error: "missing" }, { status: 400 });
    const existing = await db.select().from(favorites).where(and(eq(favorites.userId, me.id), eq(favorites.listingId, String(listingId)))).limit(1);
    if (existing.length) {
      await db.delete(favorites).where(eq(favorites.id, existing[0].id));
      return NextResponse.json({ fav: false });
    }
    await db.insert(favorites).values({ userId: me.id, listingId: String(listingId) });
    return NextResponse.json({ fav: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
