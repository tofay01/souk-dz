import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { stores } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getDbUser, slugify } from "@/lib/server";

export async function GET() {
  try {
    const all = await db.select().from(stores).orderBy(desc(stores.createdAt)).limit(50);
    return NextResponse.json(all.filter((s) => s.isActive));
  } catch {
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  if (me.plan !== "vip") return NextResponse.json({ error: "vip_only", message: "المتاجر خاصة بمشتركي VIP (5000 دج/سنة)" }, { status: 403 });
  const body = await req.json();
  const existing = await db.select().from(stores).where(eq(stores.userId, me.id)).limit(1);
  if (existing.length) {
    await db.update(stores).set({ name: body.name, description: body.description, phone: body.phone, wilayaCode: body.wilayaCode, commune: body.commune, coverColor: body.coverColor }).where(eq(stores.id, existing[0].id));
    return NextResponse.json({ ok: true, store: existing[0], updated: true });
  }
  const name = String(body.name || `متجر ${me.firstName}`);
  const inserted = await db.insert(stores).values({
    userId: me.id, name, slug: slugify(name),
    description: String(body.description || ""), phone: String(body.phone || me.phone || ""),
    wilayaCode: String(body.wilayaCode || me.wilayaCode || "16"), commune: String(body.commune || ""),
    coverColor: String(body.coverColor || "#0EA5E9"), isActive: true,
  }).returning();
  return NextResponse.json({ ok: true, store: inserted[0] });
}
