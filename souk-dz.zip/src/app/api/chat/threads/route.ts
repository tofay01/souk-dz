import { NextResponse } from "next/server";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import { getDbUser } from "@/lib/server";

// Admin only — list of user threads (last message + unread count)
export async function GET() {
  const me = await getDbUser();
  if (!me) return NextResponse.json([], { status: 401 });
  if (!me.isAdmin) return NextResponse.json([], { status: 403 });
  try {
    const recent = await db.select().from(messages).where(eq(messages.recipientId, me.id)).orderBy(desc(messages.createdAt)).limit(500);
    const threads: Record<string, { userId: string; last: any; unread: number }> = {};
    for (const m of recent) {
      const t = threads[m.senderId] || (threads[m.senderId] = { userId: m.senderId, last: null, unread: 0 });
      if (!t.last) t.last = m;
      if (!m.isRead) t.unread++;
    }
    const ids = Object.keys(threads);
    const us = ids.length ? await db.select().from(users).where(inArray(users.id, ids)) : [];
    const list = ids
      .map((id) => {
        const u = us.find((x) => x.id === id);
        const t = threads[id];
        return {
          userId: id,
          name: u ? `${u.firstName} ${u.lastName}` : "—",
          phone: u?.phone || "",
          avatarUrl: u?.avatarUrl || "",
          plan: u?.plan || "free",
          lastBody: t.last ? t.last.body : "",
          fromMe: t.last ? t.last.senderId === me.id : false,
          at: t.last ? t.last.createdAt : new Date().toISOString(),
          unread: t.unread,
        };
      })
      .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
    return NextResponse.json(list);
  } catch (e) {
    console.error(e);
    return NextResponse.json([], { status: 500 });
  }
}
