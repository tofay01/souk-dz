import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { asc, desc, and, eq, or } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

async function findAdmin() {
  const rows = await db.select().from(users).where(eq(users.isAdmin, true)).limit(1);
  return rows[0] ?? null;
}

const pubUser = (u: any) => (u ? { id: u.id, name: `${u.firstName} ${u.lastName}`, phone: u.phone, avatarUrl: u.avatarUrl || "", plan: u.plan, status: u.status } : null);

// GET /api/chat
//  - user (non-admin): conversation with the admin; marks incoming as read; ?peek=1 → unread count only
//  - admin + ?with=<userId>: conversation with that user
export async function GET(req: NextRequest) {
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  try {
    const withId = req.nextUrl.searchParams.get("with");
    const peek = req.nextUrl.searchParams.get("peek") === "1";

    if (me.isAdmin) {
      if (!withId) return NextResponse.json({ error: "with_required" }, { status: 400 });
      const partner = (await db.select().from(users).where(eq(users.id, withId)).limit(1))[0];
      if (!partner) return NextResponse.json({ error: "not_found" }, { status: 404 });
      const msgs = await db.select().from(messages)
        .where(or(and(eq(messages.senderId, withId), eq(messages.recipientId, me.id)), and(eq(messages.senderId, me.id), eq(messages.recipientId, withId))))
        .orderBy(asc(messages.createdAt))
        .limit(300);
      if (!peek) {
        await db.update(messages).set({ isRead: true }).where(and(eq(messages.senderId, withId), eq(messages.recipientId, me.id), eq(messages.isRead, false)));
      }
      return NextResponse.json({ user: pubUser(partner), meId: me.id, messages: msgs });
    }

    const admin = await findAdmin();
    if (!admin) return NextResponse.json({ user: null, meId: me.id, messages: [] });
    if (peek) {
      const r = await db.select().from(messages).where(and(eq(messages.senderId, admin.id), eq(messages.recipientId, me.id), eq(messages.isRead, false))).limit(1);
      return NextResponse.json({ count: r.length });
    }
    const msgs = await db.select().from(messages)
      .where(or(and(eq(messages.senderId, admin.id), eq(messages.recipientId, me.id)), and(eq(messages.senderId, me.id), eq(messages.recipientId, admin.id))))
      .orderBy(asc(messages.createdAt))
      .limit(300);
    await db.update(messages).set({ isRead: true }).where(and(eq(messages.senderId, admin.id), eq(messages.recipientId, me.id), eq(messages.isRead, false)));
    return NextResponse.json({ user: pubUser(admin), meId: me.id, messages: msgs });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}

// POST /api/chat { to?, body } — send a message
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "chat", 30, 10 * 60 * 1000, "رسائل كثيرة — انتظر قليلاً");
  if (denied) return denied;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  try {
    const { to, body } = await req.json().catch(() => ({}));
    const text = String(body || "").trim().slice(0, 2000);
    if (!text) return NextResponse.json({ error: "empty" }, { status: 400 });

    let targetId: string | undefined = to;
    if (!me.isAdmin) {
      // non-admins can only talk to the admin
      const admin = await findAdmin();
      if (!admin) return NextResponse.json({ error: "no_admin" }, { status: 500 });
      targetId = admin.id;
    }
    if (!targetId) return NextResponse.json({ error: "to_required" }, { status: 400 });
    const target = (await db.select().from(users).where(eq(users.id, targetId)).limit(1))[0];
    if (!target) return NextResponse.json({ error: "not_found" }, { status: 404 });
    await db.insert(messages).values({ senderId: me.id, recipientId: target.id, body: text });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
