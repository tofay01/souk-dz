import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { getDbUser } from "@/lib/server";

export const DEFAULT_TICKER = {
  items: [
    "🔥 عرض VIP: افتح متجرك الخاص بـ 5000 دج فقط للسنة — نشر غير محدود!",
    "🚚 توصيل لـ 58 ولاية عبر Yalidine و Maystro و EMS",
    "💳 ادفع ببطاقة CIB أو EDAHABIA عبر Chargily Pay — الدفع آمن 100%",
    "🪪 سجّل الآن ووثّق هويتك — النشر في أقل من دقيقة",
  ],
  speed: 45, // seconds for one full loop (smaller = faster)
  fontSize: 13,
  color: "#ffffff",
  enabled: true,
};

export async function GET() {
  try {
    const rows = await db.select().from(settings);
    const map: Record<string, string> = {};
    rows.forEach((r) => { map[r.key] = r.value; });
    const out = { ...DEFAULT_TICKER };
    if (map.ticker_items) {
      try { out.items = JSON.parse(map.ticker_items); } catch { out.items = DEFAULT_TICKER.items; }
    }
    if (map.ticker_speed) out.speed = Number(map.ticker_speed) || out.speed;
    if (map.ticker_font_size) out.fontSize = Number(map.ticker_font_size) || out.fontSize;
    if (map.ticker_font_color) out.color = map.ticker_font_color;
    if (map.ticker_enabled !== undefined) out.enabled = map.ticker_enabled === "true";
    return NextResponse.json(out);
  } catch {
    return NextResponse.json(DEFAULT_TICKER);
  }
}

export async function POST(req: NextRequest) {
  const me = await getDbUser();
  if (!me || !me.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = await req.json();
  const pairs: [string, string][] = [
    ["ticker_items", JSON.stringify(Array.isArray(body.items) ? body.items.map(String).slice(0, 20) : DEFAULT_TICKER.items)],
    ["ticker_speed", String(Math.min(Math.max(Number(body.speed) || 45, 8), 180))],
    ["ticker_font_size", String(Math.min(Math.max(Number(body.fontSize) || 13, 10), 26))],
    ["ticker_font_color", String(body.color || "#ffffff").slice(0, 20)],
    ["ticker_enabled", String(body.enabled === true || body.enabled === "true")],
  ];
  try {
    for (const [k, v] of pairs) {
      await db.insert(settings).values({ key: k, value: v }).onConflictDoUpdate({ target: settings.key, set: { value: v } });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
