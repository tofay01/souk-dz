import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { payments, users, listings, stores } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getDbUser, slugify } from "@/lib/server";
import { sameOrigin } from "@/lib/sameorigin";

// Demo confirm: in production this is called by Chargily webhook.
// For demo mode, user/admin clicks "تأكيد الدفع" and we activate.
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  const { checkoutId } = await req.json();
  if (!checkoutId) return NextResponse.json({ error: "missing" }, { status: 400 });
  const rows = await db.select().from(payments).where(eq(payments.checkoutId, String(checkoutId))).limit(1);
  const pay = rows[0];
  if (!pay) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (pay.userId !== me.id && !me.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });

  await db.update(payments).set({ status: "paid", paidAt: new Date() }).where(eq(payments.id, pay.id));

  if (pay.type === "listing_fee" && pay.listingId) {
    // Publish only if it was awaiting payment; otherwise it stays in admin review
    const cur = (await db.select().from(listings).where(eq(listings.id, pay.listingId)).limit(1))[0];
    if (cur && cur.status === "pending_payment") {
      await db.update(listings).set({ status: "active" }).where(eq(listings.id, cur.id));
    }
  }
  if (pay.type === "purchase" && pay.listingId) {
    await db.update(listings).set({ status: "sold" }).where(eq(listings.id, pay.listingId));
  }
  if (pay.type === "store_subscription" || pay.type === "vip_subscription") {
    const until = new Date();
    until.setFullYear(until.getFullYear() + 1);
    await db.update(users).set({ plan: "vip", vipExpiresAt: until, status: "verified" }).where(eq(users.id, pay.userId));
    const meta = (pay.meta as Record<string, string>) || {};
    const existing = await db.select().from(stores).where(eq(stores.userId, pay.userId)).limit(1);
    const targetUser = (await db.select().from(users).where(eq(users.id, pay.userId)).limit(1))[0];
    if (!existing.length) {
      const name = String(meta.storeName || `متجر ${targetUser?.firstName || ""} ${targetUser?.lastName || ""}`.trim() || "متجري");
      const slug = slugify(name);
      const s = await db.insert(stores).values({
        userId: pay.userId, name, slug,
        description: String(meta.storeDescription || ""),
        wilayaCode: String(meta.wilayaCode || targetUser?.wilayaCode || "16"),
        phone: String(meta.phone || targetUser?.phone || ""),
        isActive: true, paidUntil: until,
      }).returning();
      await db.update(payments).set({ storeId: s[0].id }).where(eq(payments.id, pay.id));
    } else {
      await db.update(stores).set({ isActive: true, paidUntil: until }).where(eq(stores.id, existing[0].id));
    }
  }
  return NextResponse.json({ ok: true });
}
