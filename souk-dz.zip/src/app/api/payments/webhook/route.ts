import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { payments, users, listings, stores } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyChargilySignature, externalWebhookUrl } from "@/lib/chargily";
import { slugify } from "@/lib/server";

// POST /api/payments/webhook — Chargily Pay webhook endpoint
// Signature: `signature` header = HMAC-SHA256(rawBody, CHARGILY_API_KEY) hex
// Events: checkout.paid / checkout.failed — event.data = checkout object
export async function POST(req: NextRequest) {
  const raw = await req.text();
  const sig = req.headers.get("signature") || req.headers.get("x-chargily-signature");
  if (!verifyChargilySignature(raw, sig)) {
    return NextResponse.json({ error: "bad_signature" }, { status: 401 });
  }
  // Forward the signed raw event to the external webhook (Supabase Edge Function)
  const ext = externalWebhookUrl();
  if (ext) {
    fetch(ext, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(sig ? { signature: sig } : {}) },
      body: raw,
      signal: AbortSignal.timeout(6000),
    }).catch(() => {});
  }
  try {
    const event = JSON.parse(raw);
    const type = event?.type; // checkout.paid / checkout.failed
    const checkout = event?.data ?? event?.checkout ?? {};
    const checkoutId = String(checkout?.id ?? checkout?.invoice_number ?? "");
    if (!checkoutId) return NextResponse.json({ ok: true });
    const rows = await db.select().from(payments).where(eq(payments.checkoutId, checkoutId)).limit(1);
    const pay = rows[0];
    if (!pay) return NextResponse.json({ ok: true });
    if (type === "checkout.paid" || event?.status === "paid") {
      await db.update(payments).set({ status: "paid", paidAt: new Date() }).where(eq(payments.id, pay.id));
      if (pay.type === "listing_fee" && pay.listingId) {
        const cur = (await db.select().from(listings).where(eq(listings.id, pay.listingId)).limit(1))[0];
        if (cur && cur.status === "pending_payment") {
          await db.update(listings).set({ status: "active" }).where(eq(listings.id, cur.id));
        }
      }
      if (pay.type === "purchase" && pay.listingId) {
        await db.update(listings).set({ status: "sold" }).where(eq(listings.id, pay.listingId));
      }
      if ((pay.type === "store_subscription" || pay.type === "vip_subscription") && pay.status !== "paid") {
        const until = new Date();
        until.setFullYear(until.getFullYear() + 1);
        await db.update(users).set({ plan: "vip", vipExpiresAt: until }).where(eq(users.id, pay.userId));
        const meta = (pay.meta as Record<string, string>) || {};
        const existing = await db.select().from(stores).where(eq(stores.userId, pay.userId)).limit(1);
        if (!existing.length) {
          await db.insert(stores).values({
            userId: pay.userId, name: String(meta.storeName || "متجري"), slug: slugify(String(meta.storeName || "store")),
            description: String(meta.storeDescription || ""), isActive: true, paidUntil: until,
          });
        } else {
          await db.update(stores).set({ isActive: true, paidUntil: until }).where(eq(stores.id, existing[0].id));
        }
      }
    } else if (type === "checkout.failed" || type === "checkout.expired") {
      await db.update(payments).set({ status: type.includes("expired") ? "expired" : "failed" }).where(eq(payments.id, pay.id));
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ ok: true });
  }
}
