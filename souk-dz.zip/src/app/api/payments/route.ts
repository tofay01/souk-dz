import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { payments, users, listings, stores } from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import { getDbUser, slugify } from "@/lib/server";
import { createChargilyCheckout } from "@/lib/chargily";
import { PRICING } from "@/lib/data";
import { sameOrigin } from "@/lib/sameorigin";

export async function GET(req: NextRequest) {
  const me = await getDbUser();
  if (!me) return NextResponse.json([], { status: 401 });
  const { searchParams } = new URL(req.url);
  if (searchParams.get("all") === "1" && me.isAdmin) {
    const all = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(100);
    return NextResponse.json(all);
  }
  if (searchParams.get("sales") === "1") {
    const all = await db.select().from(payments).where(eq(payments.type, "purchase")).orderBy(desc(payments.createdAt)).limit(100);
    const ids = [...new Set(all.map((p) => p.listingId).filter(Boolean) as string[])];
    const userIds = [...new Set(all.map((p) => p.userId))];
    const ls = ids.length ? await db.select().from(listings).where(inArray(listings.id, ids)) : [];
    const buyers = userIds.length ? await db.select().from(users).where(inArray(users.id, userIds)) : [];
    const out = all
      .map((p) => {
        const listing = ls.find((x) => x.id === p.listingId);
        if (!listing || listing.userId !== me.id) return null;
        const buyer = buyers.find((b) => b.id === p.userId);
        return {
          id: p.id, status: p.status, amount: p.amount, createdAt: p.createdAt,
          product: listing.title, productImg: (listing.images?.[0] as string) || "", wilaya: listing.wilayaCode,
          listingId: listing.id,
          buyer: buyer ? { name: `${buyer.firstName} ${buyer.lastName}`, phone: buyer.phone } : { name: "—", phone: "" },
        };
      })
      .filter(Boolean);
    return NextResponse.json(out);
  }
  const mine = await db.select().from(payments).where(eq(payments.userId, me.id)).orderBy(desc(payments.createdAt)).limit(50);
  return NextResponse.json(mine);
}

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  const body = await req.json();
  const { type, storeName, storeDescription, wilayaCode, phone } = body;
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin;

  if (type === "vip_subscription" || type === "store_subscription") {
    const amount = PRICING.storeYearly;
    const checkout = await createChargilyCheckout({
      amountCents: amount * 100, // 5000 DZD = 500000 centimes
      description: `اشتراك VIP + متجر خاص لمدة سنة — 5000 دج / Abonnement VIP + Boutique 1 an`,
      successUrl: `${appUrl}/paiement/success?vip=1`,
      failureUrl: `${appUrl}/paiement/fail`,
      metadata: { userId: me.id, type, storeName: storeName || "" },
    }, req.url);
    const p = await db.insert(payments).values({
      userId: me.id, type: "store_subscription", amount,
      status: "pending", checkoutId: checkout.id, checkoutUrl: checkout.url,
      meta: { mode: checkout.mode, storeName: storeName || "", storeDescription: storeDescription || "", wilayaCode: wilayaCode || me.wilayaCode, phone: phone || me.phone },
    }).returning();
    return NextResponse.json({ ok: true, payment: p[0], paymentUrl: checkout.url, mode: checkout.mode });
  }
  return NextResponse.json({ error: "bad_type" }, { status: 400 });
}
