import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword, signToken, sessionCookie } from "@/lib/auth";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "register", 5, 60 * 60 * 1000, "سجلات كثيرة من نفس الجهاز — انتظر ساعة ثم حاول");
  if (denied) return denied;
  try {
    const body = await req.json();
    const { firstName, lastName, email, phone, password, wilayaCode, commune, idFrontUrl, idBackUrl, plan, avatarUrl } = body;
    if (!firstName || !lastName || !email || !phone || !password) {
      return NextResponse.json({ error: "missing_fields" }, { status: 400 });
    }
    if (!idFrontUrl || !idBackUrl) {
      return NextResponse.json({ error: "id_required", message: "صورة بطاقة الهوية (أمام + خلف) إجبارية / CNI recto+verso obligatoire" }, { status: 400 });
    }
    // Strong password policy: 8+ chars, at least one letter and one digit
    if (String(password).length < 8 || !/[A-Za-z]/.test(String(password)) || !/\d/.test(String(password))) {
      return NextResponse.json({ error: "weak_password", message: "كلمة السر يجب أن تكون 8 أحرف على الأقل وتحتوي حروفاً وأرقاماً" }, { status: 400 });
    }
    const existing = await db.select().from(users).where(or(eq(users.email, String(email).toLowerCase()), eq(users.phone, String(phone)))).limit(1);
    if (existing.length) return NextResponse.json({ error: "exists", message: "البريد أو الهاتف مسجل مسبقاً" }, { status: 409 });
    const hash = await hashPassword(String(password));
    const inserted = await db.insert(users).values({
      firstName: String(firstName).slice(0, 100),
      lastName: String(lastName).slice(0, 100),
      email: String(email).toLowerCase().slice(0, 255),
      phone: String(phone).slice(0, 30),
      passwordHash: hash,
      plan: plan === "vip" ? "vip" : "free",
      status: "pending",
      idFrontUrl: String(idFrontUrl),
      idBackUrl: String(idBackUrl),
      avatarUrl: typeof avatarUrl === "string" && avatarUrl.startsWith("/uploads/") ? avatarUrl.slice(0, 500) : null,
      wilayaCode: String(wilayaCode || "16"),
      commune: String(commune || ""),
    }).returning();
    const u = inserted[0];
    const token = signToken({ id: u.id, email: u.email, firstName: u.firstName, lastName: u.lastName, plan: u.plan, status: u.status, isAdmin: u.isAdmin ?? false });
    const res = NextResponse.json({ ok: true, user: { id: u.id, plan: u.plan, status: u.status } });
    res.headers.set("Set-Cookie", sessionCookie(token));
    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}
