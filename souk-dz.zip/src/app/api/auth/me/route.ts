import { NextResponse } from "next/server";
import { getDbUser } from "@/lib/server";

export async function GET() {
  const u = await getDbUser();
  if (!u) return NextResponse.json({ error: "no" }, { status: 401 });
  return NextResponse.json({ id: u.id, firstName: u.firstName, lastName: u.lastName, email: u.email, phone: u.phone, plan: u.plan, status: u.status, isAdmin: u.isAdmin, wilayaCode: u.wilayaCode, avatarUrl: u.avatarUrl || "" });
}
