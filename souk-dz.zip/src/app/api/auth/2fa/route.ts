import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyToken, signToken, sessionCookie } from "@/lib/auth";
import { verifyTotp } from "@/lib/totp";
import { sameOrigin } from "@/lib/sameorigin";

// POST /api/auth/2fa { twofaToken, code } — complete login after TOTP verification
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  try {
    const { twofaToken, code } = await req.json();
    const payload = typeof twofaToken === "string" ? verifyToken(twofaToken) : null;
    if (!payload || !(payload as any).twofa) return NextResponse.json({ error: "invalid_token" }, { status: 400 });
    const u = (await db.select().from(users).where(eq(users.id, payload.id)).limit(1))[0];
    if (!u || !u.totpSecret) return NextResponse.json({ error: "invalid_token" }, { status: 400 });
    if (!verifyTotp(u.totpSecret, String(code || "").trim())) {
      return NextResponse.json({ error: "bad_code", message: "رمز التحقق غير صحيح" }, { status: 400 });
    }
    const token = signToken({ id: u.id, email: u.email, firstName: u.firstName, lastName: u.lastName, plan: u.plan, status: u.status, isAdmin: u.isAdmin ?? false, sv: u.sessionVersion ?? 0 });
    const res = NextResponse.json({ ok: true, user: { id: u.id, firstName: u.firstName, plan: u.plan, status: u.status, isAdmin: u.isAdmin } });
    res.headers.set("Set-Cookie", sessionCookie(token));
    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
