import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { sameOrigin } from "@/lib/sameorigin";

// Update own profile fields (avatar, etc.)
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};
  if (typeof body.avatarUrl === "string" && body.avatarUrl.startsWith("/uploads/")) patch.avatarUrl = body.avatarUrl.slice(0, 500);
  if (typeof body.commune === "string") patch.commune = body.commune.slice(0, 120);
  if (typeof body.address === "string") patch.address = body.address.slice(0, 500);
  if (typeof body.baridiMob === "string") patch.baridiMob = body.baridiMob.replace(/[^\d\/]/g, "").slice(0, 30);
  if (!Object.keys(patch).length) return NextResponse.json({ error: "nothing" }, { status: 400 });
  await db.update(users).set(patch).where(eq(users.id, me.id));
  return NextResponse.json({ ok: true });
}
