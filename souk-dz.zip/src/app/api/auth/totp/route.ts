import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { verifyPassword } from "@/lib/auth";
import { generateSecret, verifyTotp, authenticatorURI } from "@/lib/totp";
import QRCode from "qrcode";
import { sameOrigin } from "@/lib/sameorigin";

// 2FA (TOTP) management — admin accounts only

async function requireAdmin() {
  const me = await getDbUser();
  if (!me || !me.isAdmin) return null;
  return me;
}

// GET → { enabled } or { enabled:false, secret, qr, uri }
export async function GET() {
  const me = await requireAdmin();
  if (!me) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  if (me.totpSecret) return NextResponse.json({ enabled: true });
  const secret = generateSecret();
  const uri = authenticatorURI(secret, me.email);
  const qr = await QRCode.toDataURL(uri, { width: 220, margin: 1 });
  return NextResponse.json({ enabled: false, secret, qr, uri });
}

// POST { action:"enable", secret, code } | { action:"disable", password }
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await requireAdmin();
  if (!me) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  try {
    const body = await req.json();
    if (body.action === "enable") {
      if (me.totpSecret) return NextResponse.json({ error: "already_enabled" }, { status: 400 });
      const secret = String(body.secret || "");
      if (!/^[A-Z2-7]{16,}$/.test(secret.toUpperCase())) return NextResponse.json({ error: "bad_secret" }, { status: 400 });
      if (!verifyTotp(secret, String(body.code || ""))) {
        return NextResponse.json({ error: "bad_code", message: "الرمز غير صحيح — تحقق من تطبيق المصادقة" }, { status: 400 });
      }
      await db.update(users).set({ totpSecret: secret.toUpperCase() }).where(eq(users.id, me.id));
      return NextResponse.json({ ok: true, enabled: true });
    }
    if (body.action === "disable") {
      if (!me.totpSecret) return NextResponse.json({ error: "not_enabled" }, { status: 400 });
      if (!body.password || !(await verifyPassword(String(body.password), me.passwordHash))) {
        return NextResponse.json({ error: "bad_password", message: "كلمة السر غير صحيحة" }, { status: 400 });
      }
      await db.update(users).set({ totpSecret: null }).where(eq(users.id, me.id));
      return NextResponse.json({ ok: true, enabled: false });
    }
    return NextResponse.json({ error: "bad_action" }, { status: 400 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
