import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, loginLocks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword, signToken, signTwoFactorToken, sessionCookie } from "@/lib/auth";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

const MAX_ATTEMPTS = 5;
const LOCK_MS = 48 * 3600 * 1000; // 48h

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "login", 10, 15 * 60 * 1000, "محاولات كثيرة للدخول — انتظر 15 دقيقة ثم حاول");
  if (denied) return denied;
  try {
    const { email, password } = await req.json();
    if (!email || !password) return NextResponse.json({ error: "missing" }, { status: 400 });
    const key = String(email).toLowerCase().trim();

    // Lock check
    const locks = await db.select().from(loginLocks).where(eq(loginLocks.key, key)).limit(1);
    const lock = locks[0];
    const now = new Date();
    if (lock?.lockedUntil && lock.lockedUntil > now) {
      const mins = Math.max(1, Math.ceil((lock.lockedUntil.getTime() - now.getTime()) / 60000));
      const h = Math.floor(mins / 60);
      const m = mins % 60;
      return NextResponse.json(
        { error: "locked", message: `🔒 الحساب مقفل مؤقتاً — حاول بعد ${h} سا${m ? ` و${m} د` : ""} (بعد 5 محاولات فاشلة)` },
        { status: 423 }
      );
    }

    const rows = await db.select().from(users).where(eq(users.email, key)).limit(1);
    const u = rows[0];
    const okCred = u && (await verifyPassword(String(password), u.passwordHash));

    if (!okCred) {
      const attempts = (lock?.attempts ?? 0) + 1;
      const lockedNow = attempts >= MAX_ATTEMPTS;
      await db.insert(loginLocks)
        .values({
          key,
          attempts: lockedNow ? 0 : attempts,
          lastAttemptAt: now,
          lockedUntil: lockedNow ? new Date(now.getTime() + LOCK_MS) : null,
        })
        .onConflictDoUpdate({
          target: loginLocks.key,
          set: {
            attempts: lockedNow ? 0 : attempts,
            lastAttemptAt: now,
            lockedUntil: lockedNow ? new Date(now.getTime() + LOCK_MS) : lock?.lockedUntil ?? null,
          },
        });
      if (lockedNow) return NextResponse.json({ error: "locked", message: "🔒 تم قفل الدخول 48 ساعة بعد 5 محاولات فاشلة" }, { status: 423 });
      return NextResponse.json({ error: "invalid", message: `بيانات غير صحيحة — متبقي ${MAX_ATTEMPTS - attempts} محاولات قبل القفل` }, { status: 401 });
    }

    if (u!.status === "suspended") return NextResponse.json({ error: "suspended" }, { status: 403 });

    // success → clear attempts
    await db.delete(loginLocks).where(eq(loginLocks.key, key));
    const base = { id: u!.id, email: u!.email, firstName: u!.firstName, lastName: u!.lastName, plan: u!.plan, status: u!.status, isAdmin: u!.isAdmin ?? false, sv: u!.sessionVersion ?? 0 };

    // Two-factor step (admin with TOTP enabled)
    if (u!.totpSecret) {
      const twofaToken = signTwoFactorToken(base);
      return NextResponse.json({ twofa: true, twofaToken });
    }
    const token = signToken(base);
    const res = NextResponse.json({ ok: true, user: { id: u!.id, firstName: u!.firstName, plan: u!.plan, status: u!.status, isAdmin: u!.isAdmin } });
    res.headers.set("Set-Cookie", sessionCookie(token));
    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
