import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passwordResets, users, loginLocks } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

const TOKEN_TTL_MS = 24 * 3600 * 1000; // reset links expire 24h after approval

// GET /api/auth/reset?token=... → validate link state
export async function GET(req: NextRequest) {
  const token = String(req.nextUrl.searchParams.get("token") || "");
  if (!token) return NextResponse.json({ state: "invalid" }, { status: 400 });
  const rows = await db.select().from(passwordResets).where(eq(passwordResets.token, token)).limit(1);
  const r = rows[0];
  if (!r) return NextResponse.json({ state: "invalid" });
  if (r.status === "used") return NextResponse.json({ state: "used" });
  if (r.status === "rejected") return NextResponse.json({ state: "rejected" });
  if (r.status === "pending") return NextResponse.json({ state: "pending" });
  if (r.approvedAt && Date.now() - new Date(r.approvedAt).getTime() > TOKEN_TTL_MS) return NextResponse.json({ state: "expired" });
  // approved
  const u = (await db.select().from(users).where(eq(users.id, r.userId)).limit(1))[0];
  return NextResponse.json({ state: "ready", name: u ? u.firstName : "" });
}

// POST /api/auth/reset { token, password } → set new password (one-time link)
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "reset-set", 5, 60 * 60 * 1000, "محاولات كثيرة — انتظر ثم حاول");
  if (denied) return denied;
  try {
    const { token, password } = await req.json();
    const t = String(token || "");
    if (!t) return NextResponse.json({ error: "invalid" }, { status: 400 });
    if (!password || String(password).length < 8 || !/[A-Za-z]/.test(String(password)) || !/\d/.test(String(password))) {
      return NextResponse.json({ error: "weak", message: "كلمة السر يجب أن تكون 8 أحرف على الأقل وتحتوي حروفاً وأرقاماً" }, { status: 400 });
    }
    const rows = await db.select().from(passwordResets).where(eq(passwordResets.token, t)).limit(1);
    const r = rows[0];
    if (!r || r.status !== "approved") return NextResponse.json({ error: "invalid", message: "الرابط غير صالح أو مستعمل مسبقاً — اطلب رابطاً جديداً" }, { status: 400 });
    if (r.approvedAt && Date.now() - new Date(r.approvedAt).getTime() > TOKEN_TTL_MS) {
      return NextResponse.json({ error: "expired", message: "انتهت صلاحية الرابط (24 ساعة) — اطلب رابطاً جديداً" }, { status: 400 });
    }
    const hash = await hashPassword(String(password));
    // invalidate all existing sessions of the account
    await db.update(users).set({ passwordHash: hash, sessionVersion: sql`session_version + 1` }).where(eq(users.id, r.userId));
    await db.update(passwordResets).set({ status: "used", usedAt: new Date() }).where(eq(passwordResets.id, r.id));
    // Identity verified by admin → lift any active login lock
    const uRow = (await db.select().from(users).where(eq(users.id, r.userId)).limit(1))[0];
    if (uRow) await db.delete(loginLocks).where(eq(loginLocks.key, uRow.email.toLowerCase()));
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
