import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { clearCookie } from "@/lib/auth";

// POST /api/auth/logout?all=1 → revoke ALL sessions of the current user
export async function POST(req: NextRequest) {
  const me = await getDbUser();
  if (me && req.nextUrl.searchParams.get("all") === "1") {
    // bump session version → all existing tokens become invalid
    await db.update(users).set({ sessionVersion: sql`session_version + 1` }).where(eq(users.id, me.id));
  }
  const r = NextResponse.json({ ok: true });
  r.headers.set("Set-Cookie", clearCookie());
  return r;
}
