import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, passwordResets } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

// Request a password reset by phone number — admin will verify identity (ID card) and approve.
export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "reset-request", 5, 60 * 60 * 1000, "طلبات كثيرة — انتظر ساعة ثم حاول");
  if (denied) return denied;
  try {
    const { phone } = await req.json();
    const p = String(phone || "").trim();
    if (!p || p.length < 8) return NextResponse.json({ error: "bad_phone" }, { status: 400 });

    const rows = await db.select().from(users).where(eq(users.phone, p)).limit(1);
    const u = rows[0];
    if (u) {
      const existing = await db.select().from(passwordResets)
        .where(and(eq(passwordResets.userId, u.id), eq(passwordResets.status, "pending")))
        .limit(1);
      if (!existing.length) {
        await db.insert(passwordResets).values({ userId: u.id, phone: u.phone, status: "pending" });
      }
    }
    // generic response (do not leak whether the phone is registered)
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
