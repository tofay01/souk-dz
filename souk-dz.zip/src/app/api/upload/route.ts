import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

const IMG_SIGS: [RegExp, string][] = [
  [/^\xff\xd8\xff/, "jpg"],
  [/^\x89PNG/, "png"],
  [/^RIFF....WEBP/, "webp"],
  [/^GIF8/, "gif"],
];
const IMG_MAX = 5 * 1024 * 1024; // 5MB
const VID_MAX = 60 * 1024 * 1024; // 60MB
const VID_EXTS: Record<string, [RegExp, string]> = {
  mp4: [/^....ftyp/, "mp4"],
  webm: [/^\x1a\x45\xdf\xa3/, "webm"],
  mov: [/^....ftyp/, "mp4"],
};

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "upload", 30, 10 * 60 * 1000, "طلبات كثيرة — انتظر قليلاً ثم حاول مجدداً");
  if (denied) return denied;
  try {
    const kind = req.nextUrl.searchParams.get("kind"); // "id" = restricted (admin-only) storage
    const form = await req.formData();
    const files = form.getAll("files") as File[];
    const single = form.get("file") as File | null;
    const all: File[] = [...files];
    if (single) all.push(single as File);
    if (!all.length) return NextResponse.json({ error: "no_file" }, { status: 400 });

    const base = kind === "id" ? path.join(process.cwd(), ".data", "id") : path.join(process.cwd(), ".data", "uploads");
    await mkdir(base, { recursive: true });
    const pubDir = path.join(process.cwd(), "public", "uploads");

    const urls: string[] = [];
    for (const f of all.slice(0, 12)) {
      if (!f || typeof f.arrayBuffer !== "function") continue;
      const nameGuess = (f.name || "").toLowerCase();
      const isVideo = f.type.startsWith("video/") || /\.(mp4|webm|mov)$/.test(nameGuess);
      const max = isVideo ? VID_MAX : IMG_MAX;
      const buf = Buffer.from(await f.arrayBuffer());
      if (buf.length > max) continue;

      let ext: string | null = null;
      const head = buf.subarray(0, 12).toString("latin1");
      if (isVideo) {
        const m = nameGuess.match(/\.(mp4|webm|mov)$/);
        const sig = m ? VID_EXTS[m[1]] : null;
        if (sig && sig[0].test(head)) ext = sig[1];
      } else {
        const hit = IMG_SIGS.find(([re]) => re.test(head));
        if (hit) ext = hit[1];
      }
      if (!ext) continue; // not a real image/video → skip

      const fname = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
      await writeFile(path.join(base, fname), buf);
      if (kind !== "id") {
        try {
          await mkdir(pubDir, { recursive: true });
          await writeFile(path.join(pubDir, fname), buf);
        } catch { /* ignore */ }
      }
      urls.push(kind === "id" ? `/api/idcard/${fname}` : `/uploads/${fname}`);
    }
    if (!urls.length) return NextResponse.json({ error: "invalid_file", message: "ملفات غير صالحة — الصور: JPG/PNG/WebP (5MB) والفيديو: MP4/WebM (60MB)" }, { status: 400 });
    return NextResponse.json({ ok: true, urls });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "upload_failed" }, { status: 500 });
  }
}
