import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listings, users, payments } from "@/db/schema";
import { desc, eq, and, ilike, sql } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { PRICING } from "@/lib/data";
import { createChargilyCheckout } from "@/lib/chargily";
import { sameOrigin } from "@/lib/sameorigin";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") || "";
  const category = searchParams.get("category") || "";
  const wilaya = searchParams.get("wilaya") || "";
  const mine = searchParams.get("mine") || "";
  const featured = searchParams.get("featured") || "";
  const min = Number(searchParams.get("min") || 0);
  const max = Number(searchParams.get("max") || 0);
  const cond = searchParams.get("cond") || "";
  const sort = searchParams.get("sort") || "new"; // new | price_asc | price_desc
  const page = Math.max(1, Number(searchParams.get("page") || 1));
  const paged = searchParams.get("paged") === "1";
  const limit = Math.min(Number(searchParams.get("limit") || 60), 200);

  try {
    let query = db.select().from(listings).orderBy(desc(listings.createdAt)).limit(limit);
    const all = await query;
    let filtered = all.filter((l) => l.status === "active");
    if (mine) {
      const me = await getDbUser();
      if (!me) return NextResponse.json([]);
      filtered = all.filter((l) => l.userId === me.id);
    }
    if (q) {
      const ql = q.toLowerCase();
      filtered = filtered.filter((l) => (l.title + " " + l.description).toLowerCase().includes(ql));
    }
    if (category) filtered = filtered.filter((l) => l.category === category);
    if (wilaya) filtered = filtered.filter((l) => l.wilayaCode === wilaya);
    if (featured === "1") filtered = filtered.filter((l) => l.isVip || l.isFeatured);
    if (min > 0) filtered = filtered.filter((l) => l.price >= min);
    if (max > 0) filtered = filtered.filter((l) => l.price <= max);
    if (cond) filtered = filtered.filter((l) => l.condition === cond);
    if (sort === "price_asc") filtered.sort((a, b) => a.price - b.price);
    else if (sort === "price_desc") filtered.sort((a, b) => b.price - a.price);
    else filtered.sort((a, b) => Number(b.isVip || b.isFeatured) - Number(a.isVip || a.isFeatured) || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    if (paged) {
      const pageSize = 12;
      const total = filtered.length;
      const pages = Math.max(1, Math.ceil(total / pageSize));
      const items = filtered.slice((page - 1) * pageSize, page * pageSize);
      return NextResponse.json({ items, total, pages, page });
    }
    return NextResponse.json(filtered);
  } catch (e) {
    console.error(e);
    return NextResponse.json([], { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login_required" }, { status: 401 });
  if (me.status === "pending") return NextResponse.json({ error: "not_verified", message: "حسابك قيد المراجعة — سيتم تفعيله بعد التحقق من الهوية / Compte en cours de vérification" }, { status: 403 });
  if (me.status !== "verified") return NextResponse.json({ error: "blocked" }, { status: 403 });
  try {
    const body = await req.json();
    const { title, description, price, category, wilayaCode, commune, phone, condition, images, deliveryAvailable, videoUrl } = body;
    if (!title || !description || !category) return NextResponse.json({ error: "missing" }, { status: 400 });
    const imgs = Array.isArray(images) ? images.filter((x: unknown) => typeof x === "string" && (x as string).startsWith("/uploads/")).slice(0, 12) : [];
    if (imgs.length < 8) {
      return NextResponse.json({ error: "need_images", message: "⚠️ يجب إضافة 8 صور على الأقل للمنتج / Ajoutez au moins 8 photos du produit" }, { status: 400 });
    }
    const vid = typeof videoUrl === "string" && videoUrl.startsWith("/uploads/") ? videoUrl.slice(0, 500) : null;
    const isVipUser = me.plan === "vip";
    const inserted = await db.insert(listings).values({
      userId: me.id,
      title: String(title).slice(0, 200),
      description: String(description).slice(0, 5000),
      price: Number(price) || 0,
      category: String(category),
      wilayaCode: String(wilayaCode || me.wilayaCode || "16"),
      commune: String(commune || ""),
      phone: String(phone || me.phone || ""),
      condition: String(condition || "used"),
      images: imgs,
      videoUrl: vid,
      deliveryAvailable: deliveryAvailable !== false,
      isVip: isVipUser,
      isFeatured: isVipUser,
      // Moderation: VIP (verified) publish instantly; others wait for admin review
      status: isVipUser ? "active" : "pending_review",
    }).returning();
    const listing = inserted[0];

    if (isVipUser) {
      return NextResponse.json({ ok: true, listing, vip: true });
    }
    // Free plan: 50 DZD per ad via Chargily (amounts in centimes: 50 DZD = 5000)
    const base = process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin;
    const checkout = await createChargilyCheckout({
      amountCents: PRICING.listingFee * 100,
      description: `نشر إعلان: ${listing.title} — 50 دج`,
      successUrl: `${base}/paiement/success?listing=${listing.id}`,
      failureUrl: `${base}/paiement/fail?listing=${listing.id}`,
      metadata: { listingId: listing.id, userId: me.id, type: "listing_fee" },
    }, req.url);
    await db.insert(payments).values({
      userId: me.id,
      type: "listing_fee",
      amount: PRICING.listingFee,
      status: "pending",
      checkoutId: checkout.id,
      checkoutUrl: checkout.url,
      listingId: listing.id,
      meta: { mode: checkout.mode },
    });
    return NextResponse.json({ ok: true, listing, paymentUrl: checkout.url, checkoutId: checkout.id, mode: checkout.mode, needPayment: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
