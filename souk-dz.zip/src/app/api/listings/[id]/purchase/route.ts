import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listings, payments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { createChargilyCheckout, publicAppUrl } from "@/lib/chargily";
import { guard429 } from "@/lib/ratelimit";
import { sameOrigin } from "@/lib/sameorigin";

// Buy a listing via Chargily Pay (CIB bank card / EDAHABIA golden card)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const denied = guard429(req, "purchase", 10, 60 * 60 * 1000, "عمليات شراء كثيرة — انتظر ثم حاول");
  if (denied) return denied;
  const { id } = await params;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login_required", message: "سجّل الدخول أولاً لإتمام الشراء" }, { status: 401 });
  if (me.status === "suspended" || me.status === "rejected") return NextResponse.json({ error: "blocked", message: "حسابك غير مفعّل — تواصل مع الإدارة" }, { status: 403 });
  try {
    const rows = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
    const l = rows[0];
    if (!l || l.status !== "active") return NextResponse.json({ error: "not_available", message: "هذا الإعلان غير متاح للبيع" }, { status: 404 });
    if (l.userId === me.id) return NextResponse.json({ error: "own_listing" }, { status: 400 });
    if (!l.price || l.price <= 0) return NextResponse.json({ error: "no_price", message: "هذا الإعلان مجاني — تواصل مباشرة" }, { status: 400 });
    if (l.price > 100000) {
      return NextResponse.json({
        error: "amount_limit",
        message: "المبلغ يتجاوز حد البطاقة (100 000 دج/عملية) — رتّب الدفع مع البائع عبر واتساب",
      }, { status: 400 });
    }

    const body = await req.json().catch(() => ({}));
    const method: "edahabia" | "cib" = body.method === "cib" ? "cib" : "edahabia";
    const base = publicAppUrl(req.url);
    const checkout = await createChargilyCheckout({
      amountCents: l.price * 100,
      description: `شراء: ${l.title} — ${l.price} دج`,
      successUrl: `${base}/paiement/success?purchase=1&listing=${l.id}`,
      failureUrl: `${base}/paiement/fail`,
      metadata: { listingId: l.id, buyerId: me.id, type: "purchase", method },
      paymentMethod: method,
    }, req.url);

    const p = await db.insert(payments).values({
      userId: me.id,
      type: "purchase",
      amount: l.price,
      status: "pending",
      checkoutId: checkout.id,
      checkoutUrl: checkout.url,
      listingId: l.id,
      meta: { mode: checkout.mode, method, sellerId: l.userId },
    }).returning();
    return NextResponse.json({ ok: true, payment: p[0], paymentUrl: checkout.url, mode: checkout.mode });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server" }, { status: 500 });
  }
}
