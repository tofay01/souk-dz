import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listings, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getDbUser } from "@/lib/server";
import { sameOrigin } from "@/lib/sameorigin";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
  const l = rows[0];
  if (!l) return NextResponse.json({ error: "not_found" }, { status: 404 });
  await db.update(listings).set({ views: (l.views ?? 0) + 1 }).where(eq(listings.id, id)).catch(() => {});
  const sellerRows = await db.select().from(users).where(eq(users.id, l.userId)).limit(1);
  const seller = sellerRows[0];
  return NextResponse.json({
    ...l,
    sellerName: seller ? `${seller.firstName} ${seller.lastName}` : "",
    sellerPlan: seller?.plan ?? "free",
    sellerVerified: seller?.status === "verified",
    sellerAvatar: seller?.avatarUrl ?? "",
    sellerBaridiMob: seller?.baridiMob ?? "",
  });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const { id } = await params;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  const rows = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
  const l = rows[0];
  if (!l) return NextResponse.json({ error: "nf" }, { status: 404 });
  if (l.userId !== me.id && !me.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = await req.json();
  const allowed: Record<string, unknown> = {};
  for (const k of ["title", "description", "price", "category", "wilayaCode", "commune", "phone", "condition", "images", "status", "isFeatured", "isVip", "deliveryAvailable"]) {
    if (k in body) (allowed as Record<string, unknown>)[k] = body[k];
  }
  // non-admin cannot set featured/vip
  if (!me.isAdmin) { delete allowed.isFeatured; delete allowed.isVip; }
  await db.update(listings).set(allowed).where(eq(listings.id, id));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const bad = sameOrigin(req);
  if (bad) return bad;
  const { id } = await params;
  const me = await getDbUser();
  if (!me) return NextResponse.json({ error: "login" }, { status: 401 });
  const rows = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
  const l = rows[0];
  if (!l) return NextResponse.json({ error: "nf" }, { status: 404 });
  if (l.userId !== me.id && !me.isAdmin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  await db.delete(listings).where(eq(listings.id, id));
  return NextResponse.json({ ok: true });
}
