"use client";
import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { PhoneIc } from "@/components/AuthShell";

function Inner() {
  const { lang } = useLang();
  const sp = useSearchParams();
  const [phone, setPhone] = useState(sp.get("phone") || "");
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<any[]>([]);

  const load = useCallback(() => {
    if (!phone) return;
    fetch(`/api/inbox?phone=${encodeURIComponent(phone)}`)
      .then((r) => r.json())
      .then((d) => setMsgs(d.messages || []))
      .catch(() => {});
  }, [phone]);

  useEffect(() => {
    if (!open) return;
    load();
    const iv = setInterval(load, 10000);
    return () => clearInterval(iv);
  }, [open, load]);

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden p-10 text-white lg:flex" style={{ background: "linear-gradient(140deg, #0b2a5b 0%, #0e3f6e 45%, #0e5c28 115%)" }}>
        <div className="blob absolute -start-24 -top-24 h-80 w-80 rounded-full bg-[#25D366]/20 blur-3xl" />
        <div className="blob2 absolute -end-20 bottom-0 h-96 w-96 rounded-full bg-[#ff6e14]/20 blur-3xl" />
        <div className="grid-pattern pointer-events-none absolute inset-0 opacity-40" />
        <Link href="/" className="anim-up relative z-10 inline-flex w-fit text-sm font-bold text-white/80 hover:text-white">← {lang === "ar" ? "العودة للموقع" : "Retour"}</Link>
        <div className="relative z-10">
          <p className="text-6xl">📬</p>
          <h1 className="anim-up d2 font-logo-ar mt-4 text-4xl font-black">{lang === "ar" ? "صندوق الرسائل" : "Boîte de réception"}</h1>
          <p className="anim-up d3 mt-3 max-w-md text-sm leading-relaxed text-white/75">
            {lang === "ar"
              ? "هنا تصلك روابط إعادة تعيين كلمة السر من الإدارة — بدون تسجيل دخول! أدخل رقم هاتفك المسجل، وأبقِ الصفحة مفتوحة: الرسائل تظهر تلقائياً."
              : "Les liens de réinitialisation de l'admin arrivent ici — sans connexion ! Entrez votre numéro et gardez la page ouverte : les messages apparaissent automatiquement."}
          </p>
          <div className="anim-up d4 mt-6 space-y-2 text-sm font-bold text-white/85">
            <p>1️⃣ {lang === "ar" ? "قدّم طلب الاسترجاع برقم هاتفك" : "Faites une demande avec votre numéro"}</p>
            <p>2️⃣ {lang === "ar" ? "الإدارة تتحقق من هويتك (بطاقة التعريف)" : "L'admin vérifie votre identité (CNI)"}</p>
            <p>3️⃣ {lang === "ar" ? "الرابط يصل هنا + واتساب — أبقِ الصفحة مفتوحة" : "Le lien arrive ici + WhatsApp — page ouverte"}</p>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-center bg-[#f6f8fb]/80 p-6">
        <div className="w-full max-w-md">
          <Link href="/" className="anim-up mb-4 inline-block text-sm font-bold text-slate-500 lg:hidden">← {lang === "ar" ? "الرئيسية" : "Accueil"}</Link>
          {!open ? (
            <>
              <p className="anim-up text-5xl">📬</p>
              <h2 className="anim-up d1 font-logo-ar mt-3 text-3xl font-black text-[#0b2a5b]">{lang === "ar" ? "افتح صندوقك برقم هاتفك" : "Ouvrez votre boîte"}</h2>
              <p className="anim-up d2 mt-2 text-sm font-bold text-slate-500">{lang === "ar" ? "بدون تسجيل دخول — رقمك هو مفتاحك" : "Sans connexion — votre numéro est la clé"}</p>
              <form
                onSubmit={(e) => { e.preventDefault(); if (phone) setOpen(true); }}
                className="anim-up d3 mt-6"
              >
                <label className="mb-1.5 block text-[13px] font-black text-slate-700">{lang === "ar" ? "رقم الهاتف المسجل" : "Numéro enregistré"}</label>
                <div className="relative">
                  <span className="pointer-events-none absolute inset-y-0 start-3.5 grid place-items-center text-slate-400"><PhoneIc /></span>
                  <input dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="05 / 06 / 07 ..." className="w-full rounded-2xl border-2 border-slate-200 bg-white py-3.5 pe-4 ps-11 text-sm font-bold outline-none focus:border-[#25D366]" />
                </div>
                <button type="submit" disabled={!phone} className="btn-auth font-logo font-logo-ar mt-4 w-full rounded-2xl bg-gradient-to-l from-[#25D366] to-[#128C7E] py-4 text-base font-extrabold text-white disabled:opacity-50">
                  📬 {lang === "ar" ? "فتح صندوق الرسائل" : "Ouvrir ma boîte"}
                </button>
                <p className="mt-4 text-center text-sm font-bold text-slate-500">
                  {lang === "ar" ? "لم تقم بطلب استرجاع؟" : "Pas encore de demande ?"}{" "}
                  <Link href="/auth/reset-request" className="link-anim font-logo-ar font-black text-[#ff6e14]">{lang === "ar" ? "اطلب الآن" : "Demander"}</Link>
                </p>
              </form>
            </>
          ) : (
            <div className="anim-up overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
              <div className="flex items-center gap-2.5 bg-[#0b2a5b] px-4 py-3 text-white">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-lg">📬</span>
                <div className="flex-1">
                  <p className="text-sm font-black" dir="ltr">📱 {phone}</p>
                  <p className="text-[11px] text-green-300">● {lang === "ar" ? "يُحدَّث تلقائياً كل 10 ثوانٍ — أبقِ الصفحة مفتوحة" : "Auto-actualisation — gardez la page ouverte"}</p>
                </div>
                <button onClick={() => setOpen(false)} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-bold">✕</button>
              </div>
              <div className="h-96 space-y-2 overflow-y-auto bg-slate-50 p-3">
                {msgs.length === 0 && (
                  <div className="rounded-2xl bg-white p-6 text-center">
                    <p className="text-4xl">⏳</p>
                    <p className="mt-2 text-sm font-black text-slate-600">{lang === "ar" ? "لا رسائل بعد" : "Aucun message"}</p>
                    <p className="mt-1 text-xs font-bold text-slate-400">{lang === "ar" ? "عند موافقة الإدارة يصلك الرابط هنا فوراً — انتظر بضع دقائق" : "Le lien arrive ici dès approbation de l'admin"}</p>
                  </div>
                )}
                {msgs.map((m) => (
                  <div key={m.id} className="flex justify-start">
                    <div className="max-w-[85%] rounded-2xl rounded-bl-md bg-white px-3.5 py-2.5 text-sm font-bold shadow">
                      <p className="whitespace-pre-line break-words">{m.body}</p>
                      <p className="mt-1 text-right text-[10px] text-slate-400" dir="ltr">{new Date(m.createdAt).toLocaleString([], { dateStyle: "short", timeStyle: "short" })}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Page() {
  return (
    <Suspense>
      <Inner />
    </Suspense>
  );
}
