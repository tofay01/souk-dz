"use client";
import { useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { AuthLayout, Field, inputCls, MailIc, LockIc, EyeIc, EyeOffIc } from "@/components/AuthShell";

export default function Login() {
  const { lang } = useLang();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [twofaToken, setTwofaToken] = useState<string | null>(null);
  const [code, setCode] = useState("");

  const goNext = (isAdmin: boolean) => {
    const next = new URLSearchParams(window.location.search).get("next") || (isAdmin ? "/admin" : "/dashboard");
    window.location.href = next;
  };

  const doLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const r = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const d = await r.json();
    setBusy(false);
    if (d.twofa && d.twofaToken) {
      setTwofaToken(d.twofaToken);
      return;
    }
    if (!r.ok) {
      setErr(d.message || (lang === "ar" ? "بيانات الدخول غير صحيحة — تحقق من البريد وكلمة السر" : "Identifiants invalides — vérifiez email et mot de passe"));
      return;
    }
    goNext(d.user?.isAdmin === true);
  };

  const do2fa = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const r = await fetch("/api/auth/2fa", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ twofaToken, code }),
    });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) {
      setErr(d.message || (lang === "ar" ? "رمز التحقق غير صحيح" : "Code invalide"));
      return;
    }
    goNext(d.user?.isAdmin === true);
  };

  return (
    <AuthLayout>
      <h2 className="anim-up d1 font-logo-ar text-center text-3xl font-black text-[#0b2a5b] lg:text-start">
        {lang === "ar" ? "مرحباً بعودتك 👋" : "Bon retour 👋"}
      </h2>
      <p className="anim-up d2 mt-1.5 text-center text-sm font-bold text-slate-500 lg:text-start">
        {lang === "ar" ? "سجّل دخولك لمتابعة البيع والشراء" : "Connectez-vous pour vendre et acheter"}
      </p>
      {twofaToken ? (
        <form onSubmit={do2fa} className="anim-up mt-7 space-y-4">
          <div className="text-center">
            <p className="text-5xl">🔐</p>
            <h3 className="mt-2 text-lg font-black text-[#0b2a5b]">{lang === "ar" ? "التحقق المزدوج" : "Vérification en deux étapes"}</h3>
            <p className="mt-1 text-sm font-bold text-slate-500">{lang === "ar" ? "أدخل الرمز المكوّن من 6 أرقام من تطبيق المصادقة" : "Saisissez le code à 6 chiffres de votre app"}</p>
          </div>
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            dir="ltr"
            inputMode="numeric"
            autoFocus
            placeholder="••••••"
            className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-4 text-center text-3xl font-black tracking-[0.5em] outline-none focus:border-[#148a3c]"
          />
          {err && <div className="anim-up shake rounded-2xl border border-red-200 bg-red-50 p-3 text-center text-sm font-bold text-red-600">⚠️ {err}</div>}
          <button disabled={busy || code.length < 6} className="btn-auth font-logo font-logo-ar w-full rounded-2xl bg-gradient-to-l from-[#148a3c] to-[#0b2a5b] py-4 text-base font-extrabold text-white disabled:opacity-50">
            {busy ? "⏳..." : `✅ ${lang === "ar" ? "تأكيد ودخول" : "Confirmer"}`}
          </button>
          <button type="button" onClick={() => { setTwofaToken(null); setCode(""); setErr(""); }} className="w-full text-center text-sm font-bold text-slate-400 hover:text-slate-600">
            ← {lang === "ar" ? "رجوع" : "Retour"}
          </button>
        </form>
      ) : (
      <form onSubmit={doLogin} className="mt-7 space-y-4">
        <div className="anim-up d3">
          <Field icon={<MailIc />} label={lang === "ar" ? "البريد الإلكتروني" : "Email"}>
            <input type="email" required dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.dz" className={inputCls} />
          </Field>
        </div>
        <div className="anim-up d4">
          <Field icon={<LockIc />} label={lang === "ar" ? "كلمة السر" : "Mot de passe"}>
            <input type={showPw ? "text" : "password"} required dir="ltr" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className={inputCls + " pe-12"} />
            <button type="button" onClick={() => setShowPw(!showPw)} className="absolute inset-y-0 end-3.5 grid place-items-center text-slate-400 transition hover:text-[#148a3c]" title={showPw ? (lang === "ar" ? "إخفاء" : "Masquer") : (lang === "ar" ? "إظهار" : "Afficher")}>
              {showPw ? <EyeOffIc /> : <EyeIc />}
            </button>
          </Field>
        </div>
        {err && (
          <div className="anim-up shake rounded-2xl border border-red-200 bg-red-50 p-3 text-center text-sm font-bold text-red-600">
            ⚠️ {err}
          </div>
        )}
        <button disabled={busy} className="btn-auth anim-up d5 font-logo font-logo-ar w-full rounded-2xl bg-gradient-to-l from-[#148a3c] to-[#0b2a5b] py-4 text-base font-extrabold text-white disabled:opacity-60">
          {busy ? (
            <span className="flex items-center justify-center gap-2">
              <span className="spin inline-block h-5 w-5 rounded-full border-[3px] border-white/30 border-t-white" />
              {lang === "ar" ? "جاري الدخول..." : "Connexion..."}
            </span>
          ) : (
            <span className="flex items-center justify-center gap-2">
              {lang === "ar" ? "تسجيل الدخول" : "Se connecter"} <span className="text-lg">←</span>
            </span>
          )}
        </button>
      </form>
      )}
      <p className="anim-up d6 mt-3 text-center text-sm font-bold text-slate-500">
        {lang === "ar" ? "نسيت كلمة السر؟ " : "Mot de passe oublié ? "}
        <Link href="/auth/reset-request" className="link-anim font-logo-ar font-black text-[#ff6e14]">
          {lang === "ar" ? "استرجعها برقم هاتفك" : "Récupérer par téléphone"}
        </Link>
      </p>
      <p className="anim-up d6 mt-6 text-center text-sm font-bold text-slate-500">
        {lang === "ar" ? "ليس لديك حساب؟" : "Pas encore de compte ?"}{" "}
        <Link href="/auth/register" className="link-anim font-logo-ar font-black text-[#148a3c]">
          {lang === "ar" ? "أنشئ حساباً — مجاناً" : "Créer un compte — gratuit"}
        </Link>
      </p>
      <div className="anim-up d7 mt-6 rounded-2xl bg-white p-3.5 text-center text-[11px] font-bold text-slate-400 shadow-sm">
        🛠️ {lang === "ar" ? "دخول الأدمن" : "Admin"}: <span dir="ltr">admin@dzsouq.dz / admin123</span>
      </div>
    </AuthLayout>
  );
}
