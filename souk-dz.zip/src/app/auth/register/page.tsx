"use client";
import { useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { AuthLayout, Field, inputCls, MailIc, LockIc, UserIc, PhoneIc, EyeIc, EyeOffIc } from "@/components/AuthShell";
import { WILAYAS } from "@/lib/data";

export default function Register() {
  const { lang } = useLang();
  const [plan, setPlan] = useState<"free" | "vip">("free");
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", password: "", wilayaCode: "16", commune: "" });
  const [showPw, setShowPw] = useState(false);
  const [front, setFront] = useState<File | null>(null);
  const [back, setBack] = useState<File | null>(null);
  const [avatar, setAvatar] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const uploadOne = async (f: File, kind?: "id") => {
    const fd = new FormData();
    fd.append("file", f);
    const r = await fetch(`/api/upload${kind === "id" ? "?kind=id" : ""}`, { method: "POST", body: fd }).then((x) => x.json());
    return (r.urls?.[0] || "") as string;
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!front || !back) { setErr(lang === "ar" ? "🪪 رفع صورة بطاقة التعريف (أمام + خلف) إجباري" : "🪪 CNI recto + verso obligatoire"); return; }
    if (form.password.length < 8 || !/[A-Za-z]/.test(form.password) || !/\d/.test(form.password)) {
      setErr(lang === "ar" ? "كلمة السر: 8 أحرف على الأقل وتحتوي حروفاً وأرقاماً" : "Mot de passe : 8+ caractères, lettres et chiffres");
      return;
    }
    setBusy(true);
    try {
      const [fUrl, bUrl, aUrl] = await Promise.all([
        uploadOne(front, "id"),
        uploadOne(back, "id"),
        avatar ? uploadOne(avatar) : Promise.resolve(""),
      ]);
      const r = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, plan, idFrontUrl: fUrl, idBackUrl: bUrl, avatarUrl: aUrl || null }),
      });
      const d = await r.json();
      if (!r.ok) { setErr(d.message || d.error || "Error"); setBusy(false); return; }
      window.location.href = plan === "vip" ? "/tarifs?new=1" : "/dashboard";
    } catch {
      setErr(lang === "ar" ? "حدث خطأ — حاول مجدداً" : "Erreur — réessayez");
      setBusy(false);
    }
  };

  const UploadBox = ({ file, onFile, label }: { file: File | null; onFile: (f: File | null) => void; label: string }) => (
    <label className={`group block cursor-pointer overflow-hidden rounded-2xl border-2 border-dashed p-4 text-center transition-all duration-300 ${file ? "border-green-400 bg-green-50" : "border-slate-300 bg-slate-50 hover:scale-[1.02] hover:border-[#148a3c] hover:bg-green-50/40"}`}>
      <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0] || null)} />
      {file ? (
        <span className="anim-up block">
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-green-500 text-xl text-white">✓</span>
          <span className="mt-1.5 block truncate text-xs font-black text-green-700">{file.name}</span>
          <span className="text-[10px] font-bold text-green-500">{lang === "ar" ? "اضغط للاستبدال" : "Cliquer pour remplacer"}</span>
        </span>
      ) : (
        <>
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-white text-2xl shadow-sm transition-transform duration-300 group-hover:scale-125 group-hover:rotate-6">🪪</span>
          <span className="mt-2 block text-xs font-black text-slate-600">{label}</span>
          <span className="text-[10px] font-bold text-slate-400">JPG / PNG</span>
        </>
      )}
    </label>
  );

  return (
    <AuthLayout>
      <h2 className="anim-up d1 font-logo-ar text-center text-3xl font-black text-[#0b2a5b] lg:text-start">
        {lang === "ar" ? "أنشئ حسابك مجاناً ✨" : "Créez votre compte ✨"}
      </h2>
      <p className="anim-up d2 mt-1.5 text-center text-sm font-bold text-slate-500 lg:text-start">
        {lang === "ar" ? "بريد + هاتف + بطاقة التعريف — وتصبح تبيع في دقيقة" : "Email + téléphone + CNI — vendez en 1 minute"}
      </p>

      {/* Plan cards */}
      <div className="mt-6 grid grid-cols-2 gap-3">
        <button type="button" onClick={() => setPlan("free")} className={`anim-up d2 relative rounded-3xl border-2 p-4 text-start transition-all duration-200 ${plan === "free" ? "scale-[1.03] border-[#ff6e14] bg-orange-50/80 shadow-lg" : "border-slate-200 bg-white hover:-translate-y-0.5 hover:border-orange-300 hover:shadow"}`}>
          {plan === "free" && <span className="anim-up absolute -end-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-[#ff6e14] text-sm font-black text-white shadow">✓</span>}
          <span className="text-2xl">📋</span>
          <p className="font-logo-ar mt-1 text-sm font-black">{lang === "ar" ? "عادي — مجاني" : "Classique — Gratuit"}</p>
          <p className="mt-0.5 text-[11px] font-bold leading-snug text-slate-500">{lang === "ar" ? "50 دج لكل إعلان" : "50 DA par annonce"}</p>
        </button>
        <button type="button" onClick={() => setPlan("vip")} className={`anim-up d3 relative rounded-3xl border-2 p-4 text-start transition-all duration-200 ${plan === "vip" ? "scale-[1.03] border-amber-400 bg-amber-50 shadow-lg" : "border-slate-200 bg-white hover:-translate-y-0.5 hover:border-amber-300 hover:shadow"}`}>
          {plan === "vip" && <span className="anim-up absolute -end-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-amber-400 text-sm font-black text-white shadow">✓</span>}
          <span className="text-2xl">⭐</span>
          <p className="font-logo-ar mt-1 text-sm font-black">{lang === "ar" ? "VIP — 5000 دج/سنة" : "VIP — 5000 DA/an"}</p>
          <p className="mt-0.5 text-[11px] font-bold leading-snug text-slate-500">{lang === "ar" ? "نشر غير محدود + متجر خاص" : "Illimité + boutique privée"}</p>
        </button>
      </div>

      <form onSubmit={submit} className="mt-5 space-y-4">
        {/* Profile picture (optional) */}
        <div className="anim-up d3 flex items-center gap-4 rounded-3xl border-2 border-slate-200 bg-white p-4">
          <label className="group relative cursor-pointer">
            {avatar ? (
              <img src={URL.createObjectURL(avatar)} alt="" className="h-16 w-16 rounded-full object-cover ring-4 ring-orange-200" />
            ) : (
              <span className="grid h-16 w-16 place-items-center rounded-full border-2 border-dashed border-slate-300 bg-slate-50 text-2xl transition group-hover:scale-110 group-hover:border-[#ff6e14]">📷</span>
            )}
            <span className="absolute -bottom-1 -end-1 grid h-6 w-6 place-items-center rounded-full bg-[#ff6e14] text-[11px] font-black text-white shadow">＋</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => setAvatar(e.target.files?.[0] || null)} />
          </label>
          <div>
            <p className="text-sm font-black text-slate-800">{lang === "ar" ? "صورتك الشخصية" : "Photo de profil"} <span className="text-[10px] font-bold text-slate-400">({lang === "ar" ? "اختياري" : "optionnel"})</span></p>
            <p className="text-[11px] font-bold leading-snug text-slate-400">
              {lang === "ar" ? "تظهر في الشريط العلوي وعند تواصل المشترين معك — يمكنك تغييرها لاحقاً من لوحتك" : "Visible dans le header et pour vos clients — modifiable depuis votre espace"}
            </p>
            {avatar && <p className="mt-0.5 text-[11px] font-black text-green-600">✅ {avatar.name}</p>}
          </div>
        </div>
        <div className="anim-up d4 grid gap-4 sm:grid-cols-2">
          <Field icon={<UserIc />} label={lang === "ar" ? "الاسم" : "Prénom"}>
            <input required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} placeholder={lang === "ar" ? "مثال: أمين" : "Ex: Amine"} className={inputCls} />
          </Field>
          <Field icon={<UserIc />} label={lang === "ar" ? "اللقب" : "Nom"}>
            <input required value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} placeholder={lang === "ar" ? "مثال: بن علي" : "Ex: Benali"} className={inputCls} />
          </Field>
        </div>
        <div className="anim-up d4 grid gap-4 sm:grid-cols-2">
          <Field icon={<MailIc />} label={lang === "ar" ? "البريد الإلكتروني" : "Email"}>
            <input required type="email" dir="ltr" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.dz" className={inputCls} />
          </Field>
          <Field icon={<PhoneIc />} label={lang === "ar" ? "رقم الهاتف" : "Téléphone"}>
            <input required dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05 / 06 / 07..." className={inputCls} />
          </Field>
        </div>
        <div className="anim-up d5">
          <Field icon={<LockIc />} label={lang === "ar" ? "كلمة السر (8+ أحرف: حروف وأرقام)" : "Mot de passe (8+ : lettres + chiffres)"}>
            <input type={showPw ? "text" : "password"} required dir="ltr" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" className={inputCls + " pe-12"} />
            <button type="button" onClick={() => setShowPw(!showPw)} className="absolute inset-y-0 end-3.5 grid place-items-center text-slate-400 transition hover:text-[#148a3c]">
              {showPw ? <EyeOffIc /> : <EyeIc />}
            </button>
          </Field>
        </div>
        <div className="anim-up d5 grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-[13px] font-black text-slate-700">{lang === "ar" ? "الولاية" : "Wilaya"}</label>
            <select value={form.wilayaCode} onChange={(e) => setForm({ ...form, wilayaCode: e.target.value })} className="auth-input w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3.5 text-sm font-bold outline-none">
              {WILAYAS.map((w) => <option key={w.code} value={w.code}>{lang === "ar" ? `${w.code}-${w.ar}` : `${w.code}-${w.fr}`}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-[13px] font-black text-slate-700">{lang === "ar" ? "البلدية" : "Commune"}</label>
            <input value={form.commune} onChange={(e) => setForm({ ...form, commune: e.target.value })} placeholder={lang === "ar" ? "مثال: باب الزوار" : "Ex: Bab El Oued"} className="auth-input w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3.5 text-sm font-bold outline-none" />
          </div>
        </div>

        {/* ID upload */}
        <div className="anim-up d6 rounded-3xl border-2 border-dashed border-amber-300 bg-amber-50/50 p-4">
          <p className="text-center text-sm font-black text-amber-800">🪪 {lang === "ar" ? "إثبات الهوية — بطاقة التعريف الوطنية (إجباري)" : "CNI obligatoire (recto + verso)"}</p>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <UploadBox file={front} onFile={setFront} label={lang === "ar" ? "📄 الوجه الأمامي" : "📄 Recto"} />
            <UploadBox file={back} onFile={setBack} label={lang === "ar" ? "📄 الوجه الخلفي" : "📄 Verso"} />
          </div>
          <p className="mt-2.5 text-center text-[10px] font-bold text-slate-400">
            {lang === "ar" ? "تُستخدم للتحقق فقط • تُراجع خلال 24 سا" : "Utilisée pour vérification • revue sous 24h"}
          </p>
        </div>

        {err && (
          <div className="anim-up shake rounded-2xl border border-red-200 bg-red-50 p-3 text-center text-sm font-bold text-red-600">⚠️ {err}</div>
        )}
        <button disabled={busy} className="btn-auth anim-up d7 font-logo font-logo-ar w-full rounded-2xl bg-gradient-to-l from-[#ff6e14] to-[#d21034] py-4 text-base font-extrabold text-white disabled:opacity-60">
          {busy ? (
            <span className="flex items-center justify-center gap-2">
              <span className="spin inline-block h-5 w-5 rounded-full border-[3px] border-white/30 border-t-white" />
              {lang === "ar" ? "جاري إنشاء الحساب..." : "Création du compte..."}
            </span>
          ) : (
            <span className="flex items-center justify-center gap-2">
              ✅ {lang === "ar" ? "إنشاء الحساب" : "Créer mon compte"}
            </span>
          )}
        </button>
      </form>
      <p className="anim-up d7 mt-5 text-center text-sm font-bold text-slate-500">
        {lang === "ar" ? "لديك حساب؟" : "Déjà inscrit ?"}{" "}
        <Link href="/auth/login" className="link-anim font-logo-ar font-black text-[#148a3c]">
          {lang === "ar" ? "سجّل دخولك" : "Se connecter"}
        </Link>
      </p>
    </AuthLayout>
  );
}
