"use client";
import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useLang } from "@/lib/i18n";
import { AuthLayout, Field, inputCls, LockIc, EyeIc, EyeOffIc } from "@/components/AuthShell";

function Inner() {
  const { lang } = useLang();
  const sp = useSearchParams();
  const token = sp.get("token") || "";
  const [state, setState] = useState<"loading" | "ready" | "pending" | "invalid" | "expired" | "used" | "rejected">("loading");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!token) { setState("invalid"); return; }
    fetch(`/api/auth/reset?token=${encodeURIComponent(token)}`)
      .then((r) => r.json())
      .then((d) => {
        setState(d.state === "ready" ? "ready" : d.state === "pending" ? "pending" : d.state === "used" ? "used" : d.state === "rejected" ? "rejected" : d.state === "expired" ? "expired" : "invalid");
        if (d.name) setName(d.name);
      })
      .catch(() => setState("invalid"));
  }, [token]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) { setErr(lang === "ar" ? "8 أحرف على الأقل مع حروف وأرقام" : "8+ caractères avec lettres et chiffres"); return; }
    if (pw !== pw2) { setErr(lang === "ar" ? "كلمتا السر غير متطابقتين" : "Les mots de passe ne correspondent pas"); return; }
    setBusy(true);
    const r = await fetch("/api/auth/reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password: pw }) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) { setErr(d.message || d.error || "Error"); return; }
    setDone(true);
  };

  const center = "anim-up mt-7 rounded-3xl border-2 p-6 text-center";
  return (
    <AuthLayout>
      <h2 className="anim-up d1 font-logo-ar text-center text-3xl font-black text-[#0b2a5b] lg:text-start">
        {lang === "ar" ? "كلمة سر جديدة 🆕" : "Nouveau mot de passe 🆕"}
      </h2>
      <p className="anim-up d2 mt-1.5 text-center text-sm font-bold text-slate-500 lg:text-start">
        {name ? (lang === "ar" ? `أهلاً ${name} — عيّن كلمة السر الجديدة لحسابك` : `Bonjour ${name} — définissez votre nouveau mot de passe`) : (lang === "ar" ? "عيّن كلمة السر الجديدة لحسابك" : "Définissez votre nouveau mot de passe")}
      </p>

      {state === "loading" && <div className="anim-up mt-10 grid place-items-center"><span className="spin inline-block h-10 w-10 rounded-full border-4 border-slate-200 border-t-[#148a3c]" /></div>}

      {state === "pending" && (
        <div className={`${center} border-amber-200 bg-amber-50`}>
          <p className="text-5xl">⏳</p>
          <h3 className="mt-3 text-lg font-black text-amber-800">{lang === "ar" ? "طلبك قيد المراجعة" : "Demande en cours de vérification"}</h3>
          <p className="mt-2 text-sm font-bold text-amber-700">{lang === "ar" ? "سيتم تفعيل الرابط فور تأكيد الإدارة لبطاقة تعريفك ورقم هاتفك. أغلق الصفحة وأعد فتح الرابط لاحقاً." : "Le lien sera activé après validation de votre CNI par l'admin. Réessayez plus tard."}</p>
        </div>
      )}

      {state === "invalid" && (
        <div className={`${center} border-red-200 bg-red-50`}>
          <p className="text-5xl"></p>
          <h3 className="mt-3 text-lg font-black text-red-700">{lang === "ar" ? "الرابط غير صالح" : "Lien invalide"}</h3>
          <p className="mt-2 text-sm font-bold text-red-600">{lang === "ar" ? "تواصل مع الإدارة للحصول على رابط جديد" : "Contactez l'admin pour un nouveau lien"}</p>
          <Link href="/auth/reset-request" className="btn-auth mt-4 inline-block rounded-2xl bg-[#d21034] px-6 py-3 text-sm font-black text-white">📨 {lang === "ar" ? "طلب رابط جديد" : "Nouvelle demande"}</Link>
        </div>
      )}

      {state === "expired" && (
        <div className={`${center} border-amber-200 bg-amber-50`}>
          <p className="text-5xl">⌛</p>
          <h3 className="mt-3 text-lg font-black text-amber-800">{lang === "ar" ? "انتهت صلاحية الرابط" : "Lien expiré"}</h3>
          <p className="mt-2 text-sm font-bold text-amber-700">{lang === "ar" ? "روابط إعادة التعيين صالحة لمدة 24 ساعة فقط — اطلب رابطاً جديداً" : "Les liens valent 24h — demandez un nouveau lien"}</p>
          <Link href="/auth/reset-request" className="btn-auth mt-4 inline-block rounded-2xl bg-[#ff6e14] px-6 py-3 text-sm font-black text-white">📨 {lang === "ar" ? "طلب رابط جديد" : "Nouvelle demande"}</Link>
        </div>
      )}

      {state === "used" && (
        <div className={`${center} border-slate-200 bg-slate-50`}>
          <p className="text-5xl">✅</p>
          <h3 className="mt-3 text-lg font-black text-slate-700">{lang === "ar" ? "الرابط مستعمل مسبقاً" : "Lien déjà utilisé"}</h3>
          <p className="mt-2 text-sm font-bold text-slate-500">{lang === "ar" ? "إذا لم تقم بتغيير كلمة السر، اطلب رابطاً جديداً" : "Si vous n'avez pas changé votre mot de passe, demandez un nouveau lien"}</p>
          <Link href="/auth/login" className="btn-auth mt-4 inline-block rounded-2xl bg-[#148a3c] px-6 py-3 text-sm font-black text-white">🔑 {lang === "ar" ? "تسجيل الدخول" : "Connexion"}</Link>
        </div>
      )}

      {state === "rejected" && (
        <div className={`${center} border-red-200 bg-red-50`}>
          <p className="text-5xl">❌</p>
          <h3 className="mt-3 text-lg font-black text-red-700">{lang === "ar" ? "الطلب مرفوض" : "Demande refusée"}</h3>
          <p className="mt-2 text-sm font-bold text-red-600">{lang === "ar" ? "راجع الإدارة أو اطلب رابطاً جديداً" : "Contactez l'admin ou faites une nouvelle demande"}</p>
        </div>
      )}

      {state === "ready" && done && (
        <div className={`${center} border-green-200 bg-green-50`}>
          <p className="text-5xl">🎉</p>
          <h3 className="mt-3 text-lg font-black text-green-800">{lang === "ar" ? "تم تغيير كلمة السر!" : "Mot de passe changé !"}</h3>
          <p className="mt-2 text-sm font-bold text-green-700">{lang === "ar" ? "سجّل دخولك الآن بكلمة السر الجديدة" : "Connectez-vous avec votre nouveau mot de passe"}</p>
          <Link href="/auth/login" className="btn-auth mt-4 inline-block rounded-2xl bg-[#148a3c] px-8 py-3 text-sm font-black text-white">🔓 {lang === "ar" ? "تسجيل الدخول" : "Connexion"}</Link>
        </div>
      )}

      {state === "ready" && !done && (
        <form onSubmit={submit} className="mt-7 space-y-4">
          <div className="anim-up d3">
            <Field icon={<LockIc />} label={lang === "ar" ? "كلمة السر الجديدة" : "Nouveau mot de passe"}>
              <input type={showPw ? "text" : "password"} required dir="ltr" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••" className={inputCls + " pe-12"} />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute inset-y-0 end-3.5 grid place-items-center text-slate-400 transition hover:text-[#148a3c]" title={showPw ? (lang === "ar" ? "إخفاء" : "Masquer") : (lang === "ar" ? "إظهار" : "Afficher")}>
                {showPw ? <EyeOffIc /> : <EyeIc />}
              </button>
            </Field>
          </div>
          <div className="anim-up d4">
            <Field icon={<LockIc />} label={lang === "ar" ? "تأكيد كلمة السر" : "Confirmer le mot de passe"}>
              <input type={showPw ? "text" : "password"} required dir="ltr" value={pw2} onChange={(e) => setPw2(e.target.value)} placeholder="••••••••" className={inputCls} />
            </Field>
          </div>
          {err && <div className="anim-up shake rounded-2xl border border-red-200 bg-red-50 p-3 text-center text-sm font-bold text-red-600">⚠️ {err}</div>}
          <button disabled={busy} className="btn-auth anim-up d5 font-logo font-logo-ar w-full rounded-2xl bg-gradient-to-l from-[#148a3c] to-[#0b2a5b] py-4 text-base font-extrabold text-white disabled:opacity-60">
            {busy ? (
              <span className="flex items-center justify-center gap-2">
                <span className="spin inline-block h-5 w-5 rounded-full border-[3px] border-white/30 border-t-white" />
                {lang === "ar" ? "جاري الحفظ..." : "Enregistrement..."}
              </span>
            ) : (
              `🔒 ${lang === "ar" ? "حفظ كلمة السر الجديدة" : "Enregistrer"}`
            )}
          </button>
        </form>
      )}
    </AuthLayout>
  );
}

export default function Page() {
  return (
    <Suspense>
      <Inner />
    </Suspense>
  );
}
