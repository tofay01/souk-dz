"use client";
import { useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { AuthLayout, Field, inputCls, PhoneIc } from "@/components/AuthShell";

export default function ResetRequest() {
  const { lang } = useLang();
  const [phone, setPhone] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const r = await fetch("/api/auth/reset-request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone }),
    });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) {
      setErr(d.message || (lang === "ar" ? "رقم غير صالح — أدخل رقمك كاملاً (05...)" : "Numéro invalide"));
      return;
    }
    setDone(true);
  };

  return (
    <AuthLayout>
      <h2 className="anim-up d1 font-logo-ar text-center text-3xl font-black text-[#0b2a5b] lg:text-start">
        {lang === "ar" ? "استرجاع كلمة السر 🔑" : "Réinitialiser le mot de passe 🔑"}
      </h2>
      <p className="anim-up d2 mt-1.5 text-center text-sm font-bold text-slate-500 lg:text-start">
        {lang === "ar" ? "أدخل رقم هاتفك المسجل — نتواصل معك بعد التحقق" : "Saisissez votre numéro enregistré"}
      </p>

      {done ? (
        <div className="anim-up mt-7 rounded-3xl border-2 border-green-200 bg-green-50 p-6 text-center">
          <p className="text-5xl">✅</p>
          <h3 className="mt-3 text-lg font-black text-green-800">{lang === "ar" ? "تم استلام طلبك!" : "Demande reçue !"}</h3>
          <p className="mt-2 text-sm font-bold leading-relaxed text-green-700">
            {lang === "ar"
              ? "سيراجع فريق الإدارة هويتك (بطاقة التعريف المرفوعة عند التسجيل) ورقم هاتفك، ثم يصلك رابط إعادة التعيين في **صندوق رسائلك** وبرقم هاتفك (بدون تسجيل دخول) + واتساب. عادة خلال 24 ساعة."
              : "Notre équipe vérifiera votre identité (CNI) et votre numéro, puis le lien arrivera dans votre **boîte de messages** (sans connexion) + WhatsApp. Sous 24h."}
          </p>
          <Link href={`/auth/inbox?phone=${encodeURIComponent(phone)}`} className="btn-auth mt-4 inline-block rounded-2xl bg-[#25D366] px-6 py-3 text-sm font-black text-white">
            📬 {lang === "ar" ? "افتح صندوق رسائلك (هنا يصلك الرابط)" : "Ouvrir ma boîte (le lien arrive ici)"}
          </Link>
          <Link href="/auth/login" className="btn-auth mt-2 ms-2 inline-block rounded-2xl bg-[#148a3c] px-6 py-3 text-sm font-black text-white">
            {lang === "ar" ? "العودة لتسجيل الدخول" : "Retour à la connexion"}
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-7 space-y-4">
          <div className="anim-up d3">
            <Field icon={<PhoneIc />} label={lang === "ar" ? "رقم الهاتف المسجل" : "Numéro de téléphone enregistré"}>
              <input required dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="05 / 06 / 07 ..." className={inputCls} />
            </Field>
          </div>
          {err && <div className="anim-up shake rounded-2xl border border-red-200 bg-red-50 p-3 text-center text-sm font-bold text-red-600">⚠️ {err}</div>}
          <button disabled={busy} className="btn-auth anim-up d4 font-logo font-logo-ar w-full rounded-2xl bg-gradient-to-l from-[#ff6e14] to-[#d21034] py-4 text-base font-extrabold text-white disabled:opacity-60">
            {busy ? (
              <span className="flex items-center justify-center gap-2">
                <span className="spin inline-block h-5 w-5 rounded-full border-[3px] border-white/30 border-t-white" />
                {lang === "ar" ? "جاري الإرسال..." : "Envoi..."}
              </span>
            ) : (
              `📨 ${lang === "ar" ? "إرسال طلب الاسترجاع" : "Envoyer la demande"}`
            )}
          </button>
          <p className="anim-up d5 rounded-2xl bg-slate-50 p-3 text-center text-[11px] font-bold leading-relaxed text-slate-400">
            🛡️ {lang === "ar" ? "لا نرسل رسائل عشوائية — الرابط يُرسل فقط بعد تأكيد الإدارة لبطاقة تعريفك" : "Aucun envoi automatique — le lien n'est envoyé qu'après validation de votre CNI par l'admin"}
          </p>
        </form>
      )}
      <p className="anim-up d6 mt-6 text-center text-sm font-bold text-slate-500">
        {lang === "ar" ? "تذكرت كلمة السر؟" : "Vous vous en souvenez ?"}{" "}
        <Link href="/auth/login" className="link-anim font-logo-ar font-black text-[#148a3c]">
          {lang === "ar" ? "سجّل دخولك" : "Se connecter"}
        </Link>
      </p>
    </AuthLayout>
  );
}
