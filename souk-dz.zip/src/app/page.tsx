"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, ListingCard, useMe } from "@/components/site";
import { Logo } from "@/components/Logo";
import { WILAYAS, CATEGORIES, formatDZN } from "@/lib/data";

type Listing = { id: string; title: string; price: number; images: string[]; wilayaCode: string; category: string; createdAt: string; isVip?: boolean; isFeatured?: boolean };

export default function Home() {
  const { lang, t } = useLang();
  const { me } = useMe();
  const [listings, setListings] = useState<Listing[]>([]);
  const [q, setQ] = useState("");
  const [wilaya, setWilaya] = useState("");
  const [cat, setCat] = useState("");

  useEffect(() => {
    fetch("/api/listings?limit=24").then((r) => r.json()).then((d) => Array.isArray(d) && setListings(d)).catch(() => {});
  }, []);

  const goSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (wilaya) p.set("wilaya", wilaya);
    if (cat) p.set("category", cat);
    window.location.href = "/annonces?" + p.toString();
  };

  const vip = listings.filter((l) => l.isVip || l.isFeatured).slice(0, 4);
  const recent = listings.slice(0, 12);

  return (
    <div>
      <Navbar user={me} />
      {/* HERO leboncoin style */}
      <section className="hero-pattern grid-pattern">
        <div className="mx-auto max-w-7xl px-4 py-10 md:py-14">
          <div className="grid items-center gap-8 md:grid-cols-2">
            <div className="text-white">
              <div className="mt-2 flex items-center gap-5">
                <div className="rounded-[30px] bg-white p-4 shadow-2xl ring-1 ring-black/5">
                  <Logo size={190} />
                </div>
              </div>
              <span className="mt-3 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-bold backdrop-blur">🇩🇿 {lang === "ar" ? "النسخة الجزائرية من leboncoin" : "Le leboncoin algérien"} • 58 Wilayas</span>
              <h1 className="mt-3 text-3xl font-black leading-tight md:text-5xl">{t.ctaTitle}</h1>
              <p className="mt-3 max-w-lg text-sm text-white/85 md:text-base">{t.ctaSub}</p>
              <form onSubmit={goSearch} className="mt-6 rounded-2xl bg-white p-2 shadow-2xl">
                <div className="flex flex-col gap-2 md:flex-row">
                  <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.searchPlaceholder} className="flex-1 rounded-xl bg-slate-100 px-4 py-3 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-[#ff6e14]" />
                  <select value={wilaya} onChange={(e) => setWilaya(e.target.value)} className="rounded-xl bg-slate-100 px-3 py-3 text-sm text-slate-800 outline-none">
                    <option value="">{t.allWilayas}</option>
                    {WILAYAS.map((w) => <option key={w.code} value={w.code}>{lang === "ar" ? `${w.code} - ${w.ar}` : `${w.code} - ${w.fr}`}</option>)}
                  </select>
                  <button className="btn-brand rounded-xl px-6 py-3 text-sm font-black">🔍 {t.search}</button>
                </div>
                <div className="mt-2 flex flex-wrap gap-2 px-1 pb-1">
                  {CATEGORIES.slice(0, 6).map((c) => (
                    <button type="button" key={c.slug} onClick={() => setCat(c.slug)} className={`rounded-full px-3 py-1 text-xs font-bold ${cat === c.slug ? "bg-[#0b2a5b] text-white" : "bg-slate-100 text-slate-600 hover:bg-orange-100"}`}>{c.icon} {lang === "ar" ? c.ar : c.fr}</button>
                  ))}
                </div>
              </form>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href="/publier" className="rounded-xl bg-[#ff6e14] px-5 py-2.5 text-sm font-black text-white shadow-lg hover:bg-[#d9530a]">＋ {t.publish} — 50 DA</Link>
                <Link href="/tarifs" className="rounded-xl bg-white px-5 py-2.5 text-sm font-black text-[#0b2a5b] hover:bg-slate-100">⭐ VIP + {lang === "ar" ? "متجر" : "Boutique"} — 5000 DA</Link>
              </div>
            </div>
            {/* visual card mimicking leboncoin */}
            <div className="hidden md:block">
              <div className="rounded-3xl bg-white p-4 shadow-2xl">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-black text-[#0b2a5b]">{lang === "ar" ? "إعلانات مميزة اليوم" : "À la une aujourd'hui"}</p>
                  <Link href="/annonces" className="text-xs font-bold text-[#ff6e14]">{lang === "ar" ? "عرض الكل ←" : "Tout voir →"}</Link>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  {(vip.length ? vip : [
                    { id: "1", title: lang === "ar" ? "رونو سامبول 2019 — عداد قليل" : "Renault Symbol 2019 — faible km", price: 2150000, images: ["https://images.pexels.com/photos/34562588/pexels-photo-34562588.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"], wilayaCode: "16", category: "vehicules", createdAt: new Date().toISOString(), isVip: true },
                    { id: "2", title: lang === "ar" ? "آيفون 13 برو — حالة ممتازة" : "iPhone 13 Pro — excellent état", price: 185000, images: ["https://images.pexels.com/photos/9434650/pexels-photo-9434650.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"], wilayaCode: "31", category: "telephones", createdAt: new Date().toISOString(), isVip: true },
                    { id: "3", title: lang === "ar" ? "شقة F3 للبيع — سطيف" : "Appart F3 à vendre — Sétif", price: 9800000, images: ["https://images.pexels.com/photos/11631278/pexels-photo-11631278.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"], wilayaCode: "19", category: "immobilier", createdAt: new Date().toISOString() },
                    { id: "4", title: lang === "ar" ? "كنابي صالون تركي جديد" : "Salon turc neuf", price: 145000, images: ["https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"], wilayaCode: "09", category: "maison", createdAt: new Date().toISOString() },
                  ] as Listing[]).slice(0, 4).map((l) => (
                    <div key={l.id} className="card-hover overflow-hidden rounded-2xl border border-slate-100 bg-white">
                      <div className="relative h-24 bg-slate-100">
                        {l.images?.[0] ? (
                          <img src={l.images[0]} alt="" loading="lazy" className="h-full w-full object-cover" />
                        ) : (
                          <div className="grid h-full place-items-center bg-gradient-to-br from-slate-100 to-orange-50 text-4xl">{l.category === "vehicules" ? "🚗" : l.category === "telephones" ? "📱" : l.category === "immobilier" ? "🏠" : "🛋️"}</div>
                        )}
                        {(l.isVip || l.isFeatured) && (
                          <span className="absolute end-1.5 top-1.5 rounded-full bg-gradient-to-l from-amber-400 to-orange-500 px-2 py-0.5 text-[10px] font-black text-white shadow">⭐ VIP</span>
                        )}
                        <span className="absolute bottom-1.5 start-1.5 rounded-full bg-black/55 px-2 py-0.5 text-[10px] font-bold text-white">📍 {l.wilayaCode}</span>
                      </div>
                      <div className="p-2">
                        <p className="truncate text-xs font-bold">{l.title}</p>
                        <p className="text-sm font-black text-[#0b2a5b]" dir="ltr">{formatDZN(l.price)} <span className="text-[11px] text-[#ff6e14]">DA</span></p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px] font-bold">
                  <div className="rounded-xl bg-green-50 p-2">⚡ Chargily<br /><span className="text-green-700">CIB / EDAHABIA</span></div>
                  <div className="rounded-xl bg-blue-50 p-2">🚚 Yalidine<br /><span className="text-blue-700">58 Wilayas</span></div>
                  <div className="rounded-xl bg-orange-50 p-2">🛡️ {lang === "ar" ? "هوية موثقة" : "ID vérifiée"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4">
        {/* trust strip */}
        <div className="mt-6 grid grid-cols-2 gap-2 md:grid-cols-4">
          {[
            { e: "💳", a: "الدفع عبر Chargily Pay", f: "Paiement Chargily Pay" },
            { e: "🪪", a: "توثيق الهوية إجباري", f: "Vérification CNI obligatoire" },
            { e: "🚚", a: "توصيل لكل الولايات", f: "Livraison 58 wilayas" },
            { e: "⭐", a: "متاجر VIP بـ 5000 دج/سنة", f: "Boutiques VIP 5000 DA/an" },
          ].map((x, i) => (
            <div key={i} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white p-3">
              <span className="text-2xl">{x.e}</span>
              <span className="text-[12px] font-black text-slate-700">{lang === "ar" ? x.a : x.f}</span>
            </div>
          ))}
        </div>

        {vip.length > 0 && (
          <>
            <div className="mt-8 flex items-center justify-between">
              <h2 className="text-lg font-black text-[#0b2a5b]">⭐ {t.featured}</h2>
              <Link href="/annonces" className="text-sm font-bold text-[#ff6e14]">{lang === "ar" ? "عرض الكل" : "Tout voir"}</Link>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
              {vip.map((l) => <ListingCard key={l.id} l={l} lang={lang} />)}
            </div>
          </>
        )}

        <div className="mt-8 flex items-center justify-between">
          <h2 className="text-lg font-black text-[#0b2a5b]">🆕 {t.recent}</h2>
          <Link href="/annonces" className="rounded-xl bg-[#0b2a5b] px-4 py-2 text-xs font-bold text-white">{t.allAds}</Link>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
          {recent.length ? recent.map((l) => <ListingCard key={l.id} l={l} lang={lang} />) : (
            <div className="col-span-full rounded-2xl bg-white p-8 text-center text-sm text-slate-500">
              {lang === "ar" ? "لا توجد إعلانات بعد — كن أول من ينشر! 🎉" : "Aucune annonce — soyez le premier ! 🎉"}
              <br /><Link href="/publier" className="btn-brand mt-3 inline-block rounded-xl px-6 py-2 font-bold">＋ {t.publish}</Link>
            </div>
          )}
        </div>

        {/* VIP banner */}
        <section className="mt-10 overflow-hidden rounded-3xl bg-gradient-to-l from-[#0b2a5b] via-[#134e9e] to-[#ff6e14] p-6 text-white md:p-10">
          <div className="grid items-center gap-6 md:grid-cols-2">
            <div>
              <p className="inline rounded-full bg-white/20 px-3 py-1 text-xs font-bold">⭐ VIP — 5000 DA / {lang === "ar" ? "سنة" : "an"}</p>
              <h3 className="mt-3 text-2xl font-black md:text-3xl">{lang === "ar" ? "افتح متجرك الخاص وابِع أكثر" : "Ouvrez votre boutique et vendez plus"}</h3>
              <ul className="mt-3 space-y-1.5 text-sm text-white/90">
                <li>✅ {lang === "ar" ? "نشر غير محدود بدون 50 دج" : "Publications illimitées sans 50 DA"}</li>
                <li>✅ {lang === "ar" ? "صفحة متجر باسمك وشعارك" : "Page boutique à votre nom"}</li>
                <li>✅ {lang === "ar" ? "إعلاناتك تظهر أولاً بشارة VIP" : "Annonces en tête avec badge VIP"}</li>
                <li>✅ {lang === "ar" ? "إحصائيات وتوصيل مدمج" : "Stats + livraison intégrée"}</li>
              </ul>
              <div className="mt-4 flex gap-2">
                <Link href="/tarifs" className="rounded-xl bg-white px-6 py-2.5 text-sm font-black text-[#0b2a5b]">{lang === "ar" ? "اشترك الآن" : "S'abonner"}</Link>
                <Link href="/boutiques" className="rounded-xl bg-white/15 px-6 py-2.5 text-sm font-bold">{lang === "ar" ? "اكتشف المتاجر" : "Voir boutiques"}</Link>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {["🏬", "📦", "🚚", "💳"].map((e, i) => (
                <div key={i} className="grid h-28 place-items-center rounded-2xl bg-white/15 text-5xl backdrop-blur">{e}</div>
              ))}
            </div>
          </div>
        </section>

        {/* delivery */}
        <section className="mt-8 rounded-3xl border border-slate-100 bg-white p-6">
          <h3 className="text-lg font-black text-[#0b2a5b]">🚚 {lang === "ar" ? "شركاء التوصيل المعتمدون" : "Partenaires livraison agréés"}</h3>
          <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[["🟡", "Yalidine", "450 - 1100 DA"], ["🔵", "Maystro", "420 - 990 DA"], ["📮", "EMS", "350 - 850 DA"], ["🟢", "Noest", "400 - 950 DA"]].map(([e, n, p]) => (
              <div key={n} className="rounded-2xl bg-slate-50 p-4 text-center">
                <span className="text-3xl">{e}</span>
                <p className="mt-1 text-sm font-black">{n}</p>
                <p className="text-xs text-slate-500">{p}</p>
              </div>
            ))}
          </div>
          <Link href="/livraison" className="mt-4 inline-block rounded-xl bg-slate-900 px-5 py-2 text-sm font-bold text-white">{lang === "ar" ? "احسب سعر التوصيل ←" : "Calculer la livraison →"}</Link>
        </section>
      </main>
      <Footer />
    </div>
  );
}
