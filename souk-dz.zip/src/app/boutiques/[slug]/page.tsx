"use client";
import { use, useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, ListingCard, useMe } from "@/components/site";

export default function StorePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const { lang } = useLang();
  const { me } = useMe();
  const [store, setStore] = useState<any>(null);
  const [ads, setAds] = useState<any[]>([]);
  useEffect(() => {
    fetch("/api/stores").then((r) => r.json()).then((all) => {
      const s = (Array.isArray(all) ? all : []).find((x: any) => x.slug === slug);
      setStore(s || null);
      if (s) fetch(`/api/listings?limit=60`).then((r) => r.json()).then((l) => Array.isArray(l) && setAds(l.filter((x: any) => x.userId === s.userId)));
    });
  }, [slug]);
  if (store === null) return <div className="grid min-h-screen place-items-center">⏳...</div>;
  if (!store) return <div className="grid min-h-screen place-items-center font-bold">404 — {lang === "ar" ? "متجر غير موجود" : "Boutique introuvable"}</div>;
  return (
    <div>
      <Navbar user={me} />
      <div className="h-44" style={{ background: `linear-gradient(120deg, ${store.coverColor || "#0EA5E9"}, #0b2a5b)` }} />
      <div className="mx-auto max-w-6xl px-4">
        <div className="-mt-12 flex items-center gap-4 rounded-3xl bg-white p-5 shadow">
          <span className="grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-5xl">🏬</span>
          <div>
            <h1 className="text-2xl font-black">{store.name} <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-700">⭐ VIP</span></h1>
            <p className="text-sm text-slate-500">📞 {store.phone} • 📍 {store.wilayaCode}</p>
            <p className="text-sm text-slate-600">{store.description}</p>
          </div>
        </div>
        <h2 className="mt-6 font-black text-[#0b2a5b]">📦 {lang === "ar" ? `إعلانات المتجر (${ads.length})` : `Annonces (${ads.length})`}</h2>
        <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">{ads.map((a) => <ListingCard key={a.id} l={a} lang={lang} />)}</div>
        {!ads.length && <p className="mt-4 rounded-2xl bg-white p-6 text-center text-sm text-slate-400">{lang === "ar" ? "لا إعلانات بعد" : "Aucune annonce"}</p>}
      </div>
      <Footer />
    </div>
  );
}
