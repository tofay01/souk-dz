"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";
import { wilayaName } from "@/lib/data";

export default function Boutiques() {
  const { lang } = useLang();
  const { me } = useMe();
  const [stores, setStores] = useState<any[]>([]);
  useEffect(() => { fetch("/api/stores").then((r) => r.json()).then((d) => Array.isArray(d) && setStores(d)); }, []);
  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black text-[#0b2a5b]">🏬 {lang === "ar" ? "متاجر VIP" : "Boutiques VIP"}</h1>
          <Link href="/tarifs" className="rounded-xl bg-[#ff6e14] px-4 py-2 text-sm font-black text-white">⭐ {lang === "ar" ? "افتح متجرك — 5000 دج/سنة" : "Ouvrir ma boutique — 5000 DA/an"}</Link>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          {stores.map((s) => (
            <Link key={s.id} href={`/boutiques/${s.slug}`} className="card-hover overflow-hidden rounded-3xl bg-white">
              <div className="h-24" style={{ background: `linear-gradient(120deg, ${s.coverColor || "#0EA5E9"}, #0b2a5b)` }} />
              <div className="p-4">
                <div className="-mt-10 flex items-center gap-3">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-3xl shadow">🏬</span>
                  <div>
                    <p className="font-black">{s.name}</p>
                    <p className="text-xs text-slate-400">📍 {wilayaName(s.wilayaCode, lang)} • ⭐ VIP</p>
                  </div>
                </div>
                <p className="clamp2 mt-2 text-sm text-slate-500">{s.description || (lang === "ar" ? "متجر موثّق — توصيل لكل الولايات" : "Boutique vérifiée — livraison 58 wilayas")}</p>
              </div>
            </Link>
          ))}
        </div>
        {!stores.length && (
          <div className="mt-6 rounded-3xl bg-white p-10 text-center">
            <p className="text-5xl">🏬</p>
            <p className="mt-2 font-black">{lang === "ar" ? "لا متاجر بعد — كن أول تاجر VIP!" : "Aucune boutique — soyez le premier VIP !"}</p>
            <Link href="/tarifs" className="btn-brand mt-3 inline-block rounded-xl px-6 py-2 font-bold">⭐ 5000 DA/an</Link>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
