"use client";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";
import { PRICING, WILAYAS } from "@/lib/data";

export default function Tarifs() {
  const { lang } = useLang();
  const { me } = useMe();
  const [storeName, setStoreName] = useState("");
  const [storeDesc, setStoreDesc] = useState("");
  const [busy, setBusy] = useState(false);

  const buyVip = async () => {
    if (!me) { window.location.href = "/auth/register"; return; }
    setBusy(true);
    const r = await fetch("/api/payments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "store_subscription", storeName, storeDescription: storeDesc }) });
    const d = await r.json();
    setBusy(false);
    if (d.paymentUrl) window.location.href = d.paymentUrl;
    else alert(JSON.stringify(d));
  };

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <h1 className="text-center text-3xl font-black text-[#0b2a5b]">💎 {lang === "ar" ? "الأسعار والاشتراكات" : "Tarifs & Abonnements"}</h1>
        <p className="text-center text-sm text-slate-500">Chargily Pay ⚡ • CIB 💳 • EDAHABIA 💳</p>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-3xl border-2 border-slate-200 bg-white p-6">
            <p className="text-lg font-black">📋 {lang === "ar" ? "اشتراك عادي" : "Classique"}</p>
            <p className="mt-2 text-4xl font-black text-[#0b2a5b]">{lang === "ar" ? "مجاني" : "Gratuit"}</p>
            <ul className="mt-4 space-y-2 text-sm">
              <li>✅ {lang === "ar" ? "التسجيل مجاني بالبريد والهاتف والهوية" : "Inscription gratuite (email+tél+CNI)"}</li>
              <li>💰 {lang === "ar" ? `تدفع ${PRICING.listingFee} دج فقط على كل إعلان` : `Seulement ${PRICING.listingFee} DA par annonce`}</li>
              <li>✅ {lang === "ar" ? "توصيل مدمج Yalidine/Maystro/EMS" : "Livraison intégrée"}</li>
              <li>✅ {lang === "ar" ? "رسائل ومفضلة" : "Favoris & messages"}</li>
            </ul>
            <a href="/auth/register" className="mt-5 block rounded-2xl bg-slate-900 py-3 text-center font-black text-white">{lang === "ar" ? "سجّل مجاناً" : "S'inscrire gratuitement"}</a>
          </div>
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b2a5b] to-[#ff6e14] p-6 text-white shadow-xl">
            <span className="absolute end-4 top-4 rounded-full bg-amber-400 px-3 py-1 text-xs font-black text-black">⭐ {lang === "ar" ? "الأكثر طلباً" : "Populaire"}</span>
            <p className="text-lg font-black">⭐ VIP + {lang === "ar" ? "متجر خاص" : "Boutique"}</p>
            <p className="mt-2 text-4xl font-black">5,000 <span className="text-lg">DA/{lang === "ar" ? "سنة" : "an"}</span></p>
            <ul className="mt-4 space-y-2 text-sm text-white/95">
              <li>✅ {lang === "ar" ? "نشر غير محدود — بدون 50 دج" : "Annonces illimitées — sans 50 DA"}</li>
              <li>✅ {lang === "ar" ? "صفحة متجر باسمك: logo + وصف + كل إعلاناتك" : "Page boutique à votre nom"}</li>
              <li>✅ {lang === "ar" ? "شارة VIP وإعلاناتك أولاً" : "Badge VIP + tête de liste"}</li>
              <li>✅ {lang === "ar" ? "إحصائيات المشاهدات" : "Statistiques de vues"}</li>
              <li>✅ {lang === "ar" ? "دعم أولوية + توصيل مخفّض" : "Support prioritaire"}</li>
            </ul>
            <div className="mt-4 space-y-2 rounded-2xl bg-white/15 p-3 backdrop-blur">
              <input value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder={lang === "ar" ? "اسم متجرك (مثال: متجر النور للهواتف)" : "Nom de boutique"} className="w-full rounded-xl px-3 py-2 text-sm text-black" />
              <input value={storeDesc} onChange={(e) => setStoreDesc(e.target.value)} placeholder={lang === "ar" ? "وصف قصير لمتجرك" : "Description courte"} className="w-full rounded-xl px-3 py-2 text-sm text-black" />
            </div>
            <button onClick={buyVip} disabled={busy} className="mt-3 w-full rounded-2xl bg-white py-3 font-black text-[#0b2a5b] disabled:opacity-50">⚡ {busy ? "..." : (lang === "ar" ? "ادفع عبر Chargily Pay" : "Payer via Chargily Pay")}</button>
            <p className="mt-2 text-center text-[11px] text-white/70">CIB • EDAHABIA • {lang === "ar" ? "تفعيل فوري بعد الدفع + Webhook جاهز" : "Activation immédiate + webhook prêt"}</p>
          </div>
        </div>
        <div className="mt-6 rounded-3xl bg-white p-6 text-sm">
          <p className="font-black text-[#0b2a5b]">⚙️ {lang === "ar" ? "كيف يعمل الدفع؟ (مهيأ لـ Chargily Pay)" : "Comment marche le paiement ? (Chargily ready)"}</p>
          <ol className="mt-2 list-decimal space-y-1 ps-5 text-slate-600">
            <li>{lang === "ar" ? "تضغط «ادفع» — ننشئ Checkout عبر Chargily API (وضع Demo إن لم توجد المفاتيح)." : "Cliquez «Payer» — checkout créé via l'API Chargily (mode démo sans clés)."}</li>
            <li>{lang === "ar" ? "تدفع ببطاقة CIB أو EDAHABIA في صفحة Chargily الآمنة." : "Payez par CIB ou EDAHABIA sur la page sécurisée Chargily."}</li>
            <li>{lang === "ar" ? "يصلنا Webhook على /api/payments/webhook فيُفعَّل إعلانك أو متجرك تلقائياً." : "Le webhook /api/payments/webhook active auto votre annonce/boutique."}</li>
            <li>{lang === "ar" ? "للإنتاج: ضع CHARGILY_API_KEY (مفتاح test_sk_ أو live_sk_) و NEXT_PUBLIC_APP_URL في متغيرات البيئة — يكتشف الموقع وضع Test/Live تلقائياً." : "En prod: définissez CHARGILY_API_KEY (test_sk_ / live_sk_) et NEXT_PUBLIC_APP_URL — le site détecte automatiquement le mode test/live."}</li>
          </ol>
          <div className="mt-3 rounded-2xl bg-slate-900 p-3 font-mono text-[11px] text-green-300" dir="ltr">CHARGILY_API_KEY=test_sk_...<br />CHARGILY_LIVE=false<br />NEXT_PUBLIC_APP_URL=https://votre-domaine.dz<br />POST /api/payments/webhook ← Chargily (HMAC-SHA256)</div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
