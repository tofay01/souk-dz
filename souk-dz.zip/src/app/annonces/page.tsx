"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, ListingCard, useMe } from "@/components/site";
import { WILAYAS, CATEGORIES } from "@/lib/data";

function Inner() {
  const { lang, t } = useLang();
  const { me } = useMe();
  const sp = useSearchParams();
  const [listings, setListings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState(sp.get("q") || "");
  const [wilaya, setWilaya] = useState(sp.get("wilaya") || "");
  const [cat, setCat] = useState(sp.get("category") || "");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [cond, setCond] = useState("");
  const [sort, setSort] = useState("new");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const load = (pg = 1) => {
    setLoading(true);
    setPage(pg);
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (wilaya) p.set("wilaya", wilaya);
    if (cat) p.set("category", cat);
    if (minPrice) p.set("min", minPrice);
    if (maxPrice) p.set("max", maxPrice);
    if (cond) p.set("cond", cond);
    if (sort !== "new") p.set("sort", sort);
    p.set("paged", "1");
    p.set("page", String(pg));
    fetch("/api/listings?" + p.toString()).then((r) => r.json()).then((d) => {
      if (d && Array.isArray(d.items)) { setListings(d.items); setPages(d.pages || 1); }
      else if (Array.isArray(d)) { setListings(d); setPages(1); }
      else { setListings([]); setPages(1); }
      setLoading(false);
    }).catch(() => setLoading(false));
  };
  useEffect(() => { load(1); }, []);
  useEffect(() => { setQ(sp.get("q") || ""); setWilaya(sp.get("wilaya") || ""); setCat(sp.get("category") || ""); }, [sp]);

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="rounded-3xl bg-[#0b2a5b] p-4 md:p-6">
          <div className="grid gap-2 md:grid-cols-[1fr_180px_170px_130px_auto]">
            <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load(1)} placeholder={t.searchPlaceholder} className="rounded-xl px-4 py-2.5 text-sm outline-none" />
            <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-xl px-3 py-2.5 text-sm">
              <option value="">{t.allCategories}</option>
              {CATEGORIES.filter((c) => c.slug !== "bonsplans").map((c) => <option key={c.slug} value={c.slug}>{lang === "ar" ? c.ar : c.fr}</option>)}
            </select>
            <select value={wilaya} onChange={(e) => setWilaya(e.target.value)} className="rounded-xl px-3 py-2.5 text-sm">
              <option value="">{t.allWilayas}</option>
              {WILAYAS.map((w) => <option key={w.code} value={w.code}>{lang === "ar" ? `${w.code}-${w.ar}` : `${w.code}-${w.fr}`}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-xl px-3 py-2.5 text-sm">
              <option value="new">{lang === "ar" ? "الأحدث أولاً" : "Plus récentes"}</option>
              <option value="price_asc">{lang === "ar" ? "السعر: من الأقل" : "Prix: croissant"}</option>
              <option value="price_desc">{lang === "ar" ? "السعر: من الأعلى" : "Prix: décroissant"}</option>
            </select>
            <button onClick={() => load(1)} className="btn-brand rounded-xl px-6 py-2.5 text-sm font-black">🔍 {t.search}</button>
          </div>
          <div className="mt-2 grid gap-2 md:grid-cols-[140px_140px_170px_1fr]">
            <input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} placeholder={lang === "ar" ? "أدنى سعر (دج)" : "Prix min (DA)"} type="number" className="rounded-xl px-3 py-2 text-sm outline-none" />
            <input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder={lang === "ar" ? "أقصى سعر (دج)" : "Prix max (DA)"} type="number" className="rounded-xl px-3 py-2 text-sm outline-none" />
            <select value={cond} onChange={(e) => setCond(e.target.value)} className="rounded-xl px-3 py-2 text-sm">
              <option value="">{lang === "ar" ? "الحالة: الكل" : "État : tous"}</option>
              <option value="new">{lang === "ar" ? "✨ جديد" : "✨ Neuf"}</option>
              <option value="used">{lang === "ar" ? "♻️ مستعمل" : "♻️ Occasion"}</option>
            </select>
            <div className="hidden items-center rounded-xl bg-white/10 px-3 text-xs font-bold text-white/70 md:flex">
              ⚡ {lang === "ar" ? "الفلاتر تُطبَّق عند الضغط على البحث" : "Filtres appliqués au clic sur Rechercher"}
            </div>
          </div>
        </div>
        <p className="mt-4 text-sm font-bold text-slate-500">📋 {listings.length} {lang === "ar" ? "إعلان" : "annonces"}</p>
        {loading ? <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">{[1,2,3,4,5,6,7,8].map((i) => <div key={i} className="h-64 animate-pulse rounded-2xl bg-white" />)}</div> : (
          <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
            {listings.map((l) => <ListingCard key={l.id} l={l} lang={lang} />)}
          </div>
        )}
        {!loading && !listings.length && (
          <div className="mt-6 rounded-3xl bg-white p-10 text-center">
            <p className="text-5xl">🔍</p>
            <p className="mt-2 font-black">{lang === "ar" ? "لا نتائج — جرّب كلمات أخرى" : "Aucun résultat — essayez d'autres mots"}</p>
            <Link href="/publier" className="btn-brand mt-4 inline-block rounded-xl px-6 py-2 text-sm font-bold">＋ {t.publish}</Link>
          </div>
        )}
        {pages > 1 && (
          <div className="mt-6 flex flex-wrap items-center justify-center gap-1.5">
            {page > 1 && (
              <button onClick={() => { load(page - 1); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="h-10 w-10 rounded-xl bg-white font-black hover:bg-slate-100">←</button>
            )}
            {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
              <button key={n} onClick={() => { load(n); window.scrollTo({ top: 0, behavior: "smooth" }); }} className={`h-10 w-10 rounded-xl text-sm font-black transition ${n === page ? "bg-[#0b2a5b] text-white" : "bg-white hover:bg-slate-100"}`}>{n}</button>
            ))}
            {page < pages && (
              <button onClick={() => { load(page + 1); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="h-10 w-10 rounded-xl bg-white font-black hover:bg-slate-100">→</button>
            )}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
export default function Page() {
  return <Suspense><Inner /></Suspense>;
}
