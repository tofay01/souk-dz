"use client";
import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, ListingCard, useMe } from "@/components/site";
import { ProfileAvatar } from "@/components/ProfileAvatar";
import { CcpQRModal, parseCcp } from "@/components/CcpQR";
import { wilayaName, categoryName, formatPrice, formatDZN, DELIVERY_PROVIDERS, deliveryFee, CARD_TX_LIMIT_DA } from "@/lib/data";

export default function Detail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { lang } = useLang();
  const { me, loading: meLoading } = useMe();
  const [l, setL] = useState<any>(null);
  const [similar, setSimilar] = useState<any[]>([]);
  const [mediaIdx, setMediaIdx] = useState(0); // -1 = video
  const [showPhone, setShowPhone] = useState(false);
  const [dProv, setDProv] = useState("yalidine");
  const [dType, setDType] = useState<"home" | "office">("home");
  const [dWilaya, setDWilaya] = useState("16");
  const [ordering, setOrdering] = useState(false);
  const [buyer, setBuyer] = useState({ name: "", phone: "", commune: "", address: "" });
  const [track, setTrack] = useState("");
  const [buyBusy, setBuyBusy] = useState<"" | "edahabia" | "cib">("");
  const [buyErr, setBuyErr] = useState("");
  const [myBuy, setMyBuy] = useState<any>(null);
  const [payMethod, setPayMethod] = useState<"edahabia" | "cib" | "baridi">("edahabia");
  const [msg, setMsg] = useState("");
  const [fav, setFav] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [pm, setPm] = useState<Record<string, boolean>>({ cib: true, edahabia: true, baridi: true, cod: true });

  useEffect(() => {
    fetch("/api/payment-methods").then((r) => r.json()).then((d) => d.methods && setPm(d.methods)).catch(() => {});
  }, []);

  // if the selected method was frozen by admin, fall back to another
  useEffect(() => {
    if (pm[payMethod] === false) {
      if (pm.cib !== false) setPayMethod("cib");
      else if (pm.edahabia !== false) setPayMethod("edahabia");
      else if (pm.baridi !== false) setPayMethod("baridi");
    }
  }, [pm]);

  const anyCard = pm.edahabia !== false || pm.cib !== false || pm.baridi !== false;

  useEffect(() => {
    if (!me) return;
    fetch(`/api/favorites?listing=${id}`).then((r) => (r.ok ? r.json() : null)).then((d) => { if (d?.fav !== undefined) setFav(d.fav); }).catch(() => {});
  }, [me, id]);

  const toggleFav = async () => {
    if (!me) { window.location.href = `/auth/login?next=${encodeURIComponent(`/annonces/${id}`)}`; return; }
    const d = await fetch("/api/favorites", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ listingId: id }) }).then((r) => r.json()).catch(() => null);
    if (d && d.fav !== undefined) setFav(d.fav);
  };

  useEffect(() => {
    fetch(`/api/listings/${id}`).then((r) => r.json()).then((d) => {
      setL(d);
      setMediaIdx(d?.videoUrl ? -1 : 0);
      if (d?.category) fetch(`/api/listings?category=${d.category}&limit=8`).then((r) => r.json()).then((a) => Array.isArray(a) && setSimilar(a.filter((x: any) => x.id !== d.id).slice(0, 4)));
    });
  }, [id]);

  useEffect(() => {
    if (!me) return;
    fetch("/api/payments").then((r) => r.json()).then((all) => {
      if (Array.isArray(all)) {
        const b = all.find((x: any) => x.listingId === id);
        if (b) setMyBuy(b);
      }
    }).catch(() => {});
  }, [me, id]);

  // after login return: preselect the requested card (visual hint only — buttons are always inline)
  useEffect(() => {
    if (me) {
      const m = new URLSearchParams(window.location.search).get("buy");
      if (m === "edahabia" || m === "cib") {
        const el = document.getElementById(`buy-${m}`);
        if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [me]);

  if (!l || l.error) return <div className="grid min-h-screen place-items-center"><p className="rounded-2xl bg-white p-8 font-bold">⏳ ... / {l?.error === "not_found" ? "غير موجود" : ""}</p></div>;

  const fee = deliveryFee(dProv, dType, dWilaya);

  const waPhone = (() => {
    const p = String(l.phone || "").replace(/\D/g, "");
    if (!p) return "";
    return p.startsWith("0") ? "213" + p.slice(1) : p;
  })();
  const waMsg = encodeURIComponent(
    lang === "ar"
      ? `السلام عليكم 👋\nأرغب في شراء: ${l.title}\n💰 ${l.price} دج\nمن إعلانكم على Souq-DZ 🇩\nالتسليم يد بيد إن أمكن.`
      : `Bonjour 👋\nJe souhaite acheter : ${l.title}\n💰 ${l.price} DA\nVotre annonce sur Souq-DZ 🇩\nRemise en main propre.`
  );
  const codMsg = encodeURIComponent(
    lang === "ar"
      ? `مرحباً 👋 — طلب من Souq-DZ\n📦 المنتج: ${l.title}\n💰 السعر: ${l.price} دج\n💵 أفضّل الدفع عند الاستلام (توصيل أو يد بيد). هل يتوفر؟\nشكراً!`
      : `Bonjour 👋 — Commande via Souq-DZ\n📦 Article : ${l.title}\n💰 Prix : ${l.price} DA\n💵 Paiement à la livraison (livraison ou main propre) possible ?\nMerci !`
  );
  const baridiMsg = encodeURIComponent(
    lang === "ar"
      ? `مرحباً 👋 — طلب من Souq-DZ\n📦 المنتج: ${l.title}\n💰 أنجزت تحويل BaridiMob بقيمة ${l.price} دج\n📱 إلى الحساب: ${l.sellerBaridiMob || "—"}\n🔖 رقم مرجع التحويل: [اكتب الرقم هنا]\nبانتظار التأكيد 🙏`
      : `Bonjour 👋 — Commande via Souq-DZ\n📦 Article : ${l.title}\n💰 Virement BrédiMob de ${l.price} DA effectué\n📱 vers le compte : ${l.sellerBaridiMob || "—"}\n🔖 N° de référence : [à compléter]\nEn attente de confirmation 🙏`
  );

  const openBaridi = () => {
    if (parseCcp(l.sellerBaridiMob)) { setQrOpen(true); return; }
    setBuyErr(lang === "ar" ? "⚠️ البائع لم يسجّل رقم CCP بعد — رتّب الدفع عبر واتساب" : "⚠️ Le vendeur n'a pas enregistré de CCP — convenez via WhatsApp");
  };

  const payBaridi = () => {
    if (parseCcp(l.sellerBaridiMob)) { setQrOpen(true); return; }
    if (!l.sellerBaridiMob) {
      setBuyErr(lang === "ar" ? "⚠️ البائع لم يفعّل حساب بريدي موب بعد — رتّب الدفع عبر واتساب" : "⚠️ Le vendeur n'a pas activé BrédiMob — convenez via WhatsApp");
      return;
    }
    if (waPhone) window.open(`https://wa.me/${waPhone}?text=${baridiMsg}`, "_blank");
    else setBuyErr(lang === "ar" ? "⚠️ رقم واتساب البائع غير متوفر" : "⚠️ Numéro WhatsApp du vendeur indisponible");
  };
  const limitMsg = lang === "ar"
    ? `💰 هذا المبلغ يتجاوز حد البطاقة (${formatDZN(CARD_TX_LIMIT_DA)} دج/عملية) — رتّب الدفع مع البائع عبر واتساب 💬`
    : `💰 Ce montant dépasse la limite par carte (${formatDZN(CARD_TX_LIMIT_DA)} DA/opération) — convenez du paiement avec le vendeur via WhatsApp 💬`;

  const buyDirect = async (m: "edahabia" | "cib") => {
    setBuyErr("");
    if (l.userId === me?.id) return;
    if ((l.price || 0) > CARD_TX_LIMIT_DA) { setBuyErr(limitMsg); return; }
    if (!me) {
      if (meLoading) { setBuyErr("⏳ ..."); return; }
      window.location.href = `/auth/login?next=${encodeURIComponent(`/annonces/${id}?buy=${m}`)}`;
      return;
    }
    setBuyBusy(m);
    try {
      const r = await fetch(`/api/listings/${id}/purchase`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ method: m }) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.paymentUrl) {
        setBuyBusy("");
        setBuyErr(d.error === "amount_limit" ? limitMsg : d.message || (typeof d.error === "string" ? d.error : (lang === "ar" ? "حدث خطأ غير متوقع — حاول مجدداً" : "Une erreur est survenue — réessayez")) + (r.status === 401 ? (lang === "ar" ? " (سجّل الدخول أولاً)" : " (connexion requise)") : ""));
        return;
      }
      window.location.href = d.paymentUrl;
    } catch {
      setBuyBusy("");
      setBuyErr(lang === "ar" ? "⚠️ فشل الاتصال بالخادم — تحقق من الإنترنت وحاول مجدداً" : "⚠️ Échec de connexion au serveur — réessayez");
    }
  };

  const sendMsg = () => {
    const body = msg.trim() || (lang === "ar" ? "مرحباً، أرغب في الاستفسار عن إعلانك على Souq-DZ" : "Bonjour, je souhaite me renseigner sur votre annonce Souq-DZ");
    const t = encodeURIComponent(`${body}\n\n— ${l.title}`);
    window.open(waPhone ? `https://wa.me/${waPhone}?text=${t}` : `https://wa.me/?text=${t}`, "_blank");
  };

  const overLimit = (l.price || 0) > CARD_TX_LIMIT_DA;
  const order = async () => {
    if (!buyer.name || !buyer.phone) return alert(lang === "ar" ? "أدخل الاسم والهاتف" : "Nom + téléphone requis");
    setOrdering(true);
    const r = await fetch("/api/delivery", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ listingId: id, buyerName: buyer.name, buyerPhone: buyer.phone, buyerWilaya: dWilaya, buyerCommune: buyer.commune, buyerAddress: buyer.address, provider: dProv, deliveryType: dType }) });
    const d = await r.json();
    setOrdering(false);
    if (d.ok) setTrack(d.order.trackingCode);
  };

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-6xl px-4 py-6">
        <Link href="/annonces" className="text-sm font-bold text-slate-500">{lang === "ar" ? "→ رجوع للنتائج" : "← Retour"}</Link>
        <div className="mt-3 grid gap-4 md:grid-cols-[1fr_340px]">
          <div>
            <div className="overflow-hidden rounded-3xl bg-white">
              {(() => {
                const imgs: string[] = Array.isArray(l.images) ? l.images : [];
                const hasVid = !!l.videoUrl;
                const showVideo = hasVid && mediaIdx === -1;
                return (
                  <>
                    <div className="relative h-[320px] bg-slate-100 md:h-[420px]">
                      {showVideo ? (
                        <video src={l.videoUrl} controls playsInline className="h-full w-full bg-black object-contain" />
                      ) : imgs.length ? (
                        <img src={imgs[Math.max(0, mediaIdx)]} className="h-full w-full object-contain bg-black" />
                      ) : (
                        <div className="grid h-full place-items-center text-8xl">📦</div>
                      )}
                      {(l.isVip || l.isFeatured) && <span className="absolute start-3 top-3 rounded-full bg-gradient-to-l from-amber-400 to-orange-500 px-3 py-1 text-xs font-black text-white">⭐ VIP</span>}
                      {hasVid && <span className="absolute end-3 top-3 rounded-full bg-black/70 px-2.5 py-1 text-xs font-black text-white">🎬 {lang === "ar" ? "فيديو" : "Vidéo"}</span>}
                    </div>
                    {(hasVid || (imgs.length > 1)) && (
                      <div className="flex gap-2 overflow-x-auto p-3">
                        {hasVid && (
                          <button onClick={() => setMediaIdx(-1)} className={`grid h-16 w-16 shrink-0 cursor-pointer place-items-center rounded-xl bg-slate-900 text-2xl text-white ${mediaIdx === -1 ? "ring-2 ring-[#ff6e14]" : "opacity-80"}`}>
                            ▶️
                          </button>
                        )}
                        {imgs.map((s: string, i: number) => (
                          <img key={i} src={s} onClick={() => setMediaIdx(i)} className={`h-16 w-16 shrink-0 cursor-pointer rounded-xl object-cover ${i === mediaIdx ? "ring-2 ring-[#ff6e14]" : "opacity-70"}`} />
                        ))}
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
            <div className="mt-4 rounded-3xl bg-white p-5">
              <div className="flex flex-wrap gap-2 text-[11px] font-bold">
                <span className="rounded-full bg-slate-100 px-3 py-1">📁 {categoryName(l.category, lang)}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">📍 {wilayaName(l.wilayaCode, lang)} {l.commune ? `— ${l.commune}` : ""}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">{l.condition === "new" ? (lang === "ar" ? "✨ جديد" : "✨ Neuf") : (lang === "ar" ? "♻️ مستعمل" : "♻️ Occasion")}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">👁️ {l.views}</span>
              </div>
              <h1 className="mt-3 text-xl font-black md:text-2xl">{l.title}</h1>
              <p className="mt-1 text-xs text-slate-400">{new Date(l.createdAt).toLocaleString(lang === "ar" ? "ar-DZ" : "fr-FR")} • N° {String(l.id).slice(0, 8).toUpperCase()}</p>
              <p className="mt-4 whitespace-pre-line text-[15px] leading-relaxed text-slate-700">{l.description}</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="rounded-3xl bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-1.5 text-sm font-black text-[#0b2a5b]">
                  <ProfileAvatar
                    user={{ name: l.sellerName || "؟", avatarUrl: l.sellerAvatar }}
                    editable={!!me && me.id === l.userId}
                    size={26}
                    onUpdated={(url) => setL((p: any) => ({ ...p, sellerAvatar: url }))}
                  />
                  {lang === "ar" ? "البائع" : "Vendeur"}: {l.sellerName || "—"}
                </p>
                <div className="flex gap-1.5">
                  {l.sellerVerified && <span className="rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-black text-green-700">✓ {lang === "ar" ? "هوية موثقة" : "Vérifié"}</span>}
                  {(l.sellerPlan === "vip" || l.isVip) && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-black text-amber-700">⭐ VIP</span>}
                </div>
              </div>
              <p className="mt-3 text-center text-3xl font-black text-[#0b2a5b]">{formatPrice(l.price, lang)}</p>
              {l.status === "sold" ? (
                <div className="mt-4 rounded-2xl border border-green-200 bg-green-50 p-4 font-black text-green-700">✅ {lang === "ar" ? "تم بيع هذا الإعلان" : "Vendu — Cet article est soldé"}</div>
              ) : l.userId === me?.id ? (
                <div className="mt-4 rounded-2xl border border-blue-200 bg-blue-50 p-3 text-sm font-black text-blue-700">👤 {lang === "ar" ? "هذا إعلانك — يمكنك إدارته من لوحتك" : "Votre annonce — gérez-la depuis votre espace"}</div>
              ) : myBuy?.status === "paid" ? (
                <div className="mt-4 rounded-2xl border border-green-200 bg-green-50 p-4">
                  <p className="font-black text-green-700">🎉 {lang === "ar" ? "لقد اشتريت هذا المنتج!" : "Article acheté !"}</p>
                  <p className="mt-1 text-xs font-bold text-green-600">{lang === "ar" ? "سيتواصل معك البائع للتسليم" : "Le vendeur vous contactera"}</p>
                </div>
              ) : meLoading ? (
                <div className="mt-4 h-28 animate-pulse rounded-2xl bg-slate-100" />
              ) : (
                <div className="mt-4">
                  {anyCard && <button onClick={() => (payMethod === "baridi" ? payBaridi() : buyDirect(payMethod))} disabled={buyBusy !== ""} className={`btn-auth w-full rounded-2xl py-4 text-base font-black text-white shadow-lg disabled:opacity-60 ${payMethod === "baridi" ? "bg-gradient-to-l from-[#0b2a5b] to-[#134e9e]" : "bg-gradient-to-l from-[#ff6e14] to-[#e85d04]"}`}>
                    {buyBusy !== "" ? (
                      <span className="flex items-center justify-center gap-2">
                        <span className="spin inline-block h-5 w-5 rounded-full border-[3px] border-white/40 border-t-white" />
                        {lang === "ar" ? "جاري تحويلك إلى Chargily..." : "Redirection vers Chargily..."}
                      </span>
                    ) : payMethod === "baridi" ? (
                      <>📱 {lang === "ar" ? "إرسال رقم التحويل للبائع" : "Envoyer le n° au vendeur"} • {formatDZN(l.price || 0)} {lang === "ar" ? "دج" : "DA"}</>
                    ) : (
                      <>🛒 {lang === "ar" ? "شراء الآن" : "Acheter maintenant"} • {formatDZN(l.price || 0)} {lang === "ar" ? "دج" : "DA"}</>
                    )}
                  </button>}
                  {anyCard ? (
                    <div className="mt-2.5 flex flex-wrap items-center justify-center gap-1.5">
                      {pm.edahabia !== false && (
                        <button onClick={() => setPayMethod("edahabia")} className={`rounded-full border px-3 py-1 text-[11px] font-black transition ${payMethod === "edahabia" ? "border-amber-400 bg-amber-50 text-amber-700 ring-2 ring-amber-300" : "border-slate-200 bg-white text-slate-600 hover:border-amber-300"}`}>🥇 EDAHABIA</button>
                      )}
                      {pm.cib !== false && (
                        <button onClick={() => setPayMethod("cib")} className={`rounded-full border px-3 py-1 text-[11px] font-black transition ${payMethod === "cib" ? "border-[#c8102e] bg-red-50 text-[#c8102e] ring-2 ring-red-200" : "border-slate-200 bg-white text-slate-600 hover:border-red-300"}`}>💳 CIB</button>
                      )}
                      {pm.baridi !== false && (
                        <button onClick={() => setPayMethod("baridi")} className={`rounded-full border px-3 py-1 text-[11px] font-black transition ${payMethod === "baridi" ? "border-[#0b2a5b] bg-[#0b2a5b]/5 text-[#0b2a5b] ring-2 ring-[#0b2a5b]/30" : "border-slate-200 bg-white text-slate-600 hover:border-[#0b2a5b]/40"}`}>📱 BaridiMob</button>
                      )}
                      <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] font-black text-slate-500">⚡ Chargily Pay</span>
                    </div>
                  ) : (
                    <p className="mt-2.5 rounded-2xl bg-amber-50 border border-amber-200 p-2.5 text-center text-[11px] font-black text-amber-800">
                      ⚠️ {lang === "ar" ? "الدفع الإلكتروني متوقف مؤقتاً — رتّب الدفع مباشرة مع البائع" : "Paiement en ligne temporairement suspendu — convenez directement avec le vendeur"}
                    </p>
                  )}
                  {payMethod === "baridi" && (
                    <div className="mt-2 rounded-2xl border-2 border-[#0b2a5b]/15 bg-[#0b2a5b]/[0.03] p-3 text-start">
                      <p className="text-center text-xs font-black text-[#0b2a5b]">📱 {lang === "ar" ? "الدفع عبر BaridiMob (تحويل بريدي)" : "Paiement par BrédiMob (virement)"}</p>
                      {l.sellerBaridiMob ? (
                        <>
                          <div className="mt-2 rounded-xl bg-white p-2.5 text-center shadow-sm">
                            <p className="text-[10px] font-bold text-slate-400">{lang === "ar" ? "أرسل المبلغ إلى حساب البائع:" : "Envoyez le montant au compte du vendeur :"}</p>
                            <p className="mt-0.5 text-xl font-black tracking-[0.15em] text-[#0b2a5b]" dir="ltr">{l.sellerBaridiMob}</p>
                            <p className="text-[11px] font-black text-[#ff6e14]">= {formatDZN(l.price || 0)} {lang === "ar" ? "دج" : "DA"}</p>
                          </div>
                          <ol className="mt-2 space-y-1 ps-5 text-[11px] font-bold text-slate-600">
                            <li>1️⃣ {lang === "ar" ? "افتح تطبيق BaridiMob" : "Ouvrez l'app BrédiMob"}</li>
                            <li>2️⃣ {lang === "ar" ? `أرسل ${l.price} دج إلى الحساب أعلاه` : `Envoyez ${l.price} DA au compte ci-dessus`}</li>
                            <li>3️⃣ {lang === "ar" ? "انسخ رقم مرجع التحويل" : "Notez le n° de référence"}</li>
                            <li>4️⃣ {lang === "ar" ? "أرسل الرقم للبائع بالزر البرتقالي" : "Envoyez le n° via le bouton"}</li>
                          </ol>
                        </>
                      ) : (
                        <p className="mt-2 rounded-xl bg-amber-50 p-2.5 text-center text-[11px] font-bold text-amber-800">⚠️ {lang === "ar" ? "البائع لم يفعّل حساب بريدي موب بعد — رتّب الدفع عبر واتساب" : "Le vendeur n'a pas activé BrédiMob — convenez via WhatsApp"}</p>
                      )}
                    </div>
                  )}
                  <p className="mt-1.5 text-center text-[11px] font-bold text-slate-400">🔒 {lang === "ar" ? "شراء آمن عبر الإنترنت — بطاقتك لا تُخزَّن" : "Achat sécurisé en ligne — carte jamais stockée"}</p>
                  {pm.cod !== false && waPhone && (
                    <a href={`https://wa.me/${waPhone}?text=${codMsg}`} target="_blank" rel="noreferrer" className="mt-2 block w-full rounded-2xl border-2 border-[#25D366] bg-white py-3 text-center text-sm font-black text-[#128C7E] transition hover:bg-green-50">
                      💵 {lang === "ar" ? "الدفع عند الاستلام — اطلب عبر واتساب" : "Paiement à la livraison — commander via WhatsApp"}
                    </a>
                  )}
                  {pm.baridi !== false && (
                    <button onClick={openBaridi} className="mt-2 w-full rounded-2xl bg-gradient-to-l from-[#0b2a5b] to-[#134e9e] py-3 text-center text-sm font-black text-white shadow transition hover:opacity-90">
                      📱 {lang === "ar" ? "شراء عبر BaridiMob (رمز QR)" : "Acheter via BrédiMob (QR)"}
                    </button>
                  )}
                  {overLimit && (
                    <p className="mt-3 rounded-2xl border border-amber-300 bg-amber-50 p-3 text-xs font-black leading-relaxed text-amber-800">
                      💰 {lang === "ar"
                        ? `هذا السعر يتجاوز حد البطاقة (${formatDZN(CARD_TX_LIMIT_DA)} دج/عملية). رتّب الدفع مع البائع عبر واتساب: تقسيط، دفع عند التسليم، أو حوالة.`
                        : `Ce prix dépasse la limite par carte (${formatDZN(CARD_TX_LIMIT_DA)} DA/opération). Convenez du paiement avec le vendeur via WhatsApp : à terme, à la livraison, ou virement.`}
                    </p>
                  )}
                  {buyErr && <p className="mt-2 rounded-xl bg-red-50 p-2.5 text-center text-sm font-bold leading-relaxed text-red-600">{buyErr}</p>}
                  {!me && !overLimit && <p className="mt-2 rounded-xl bg-blue-50 p-2 text-center text-xs font-bold text-blue-700">🔐 {lang === "ar" ? "ستُحوَّل لتسجيل الدخول أولاً ثم تكمل الشراء من نفس الصفحة" : "Vous serez redirigé pour vous connecter, puis revenir ici"}</p>}
                </div>
              )}
              {myBuy?.status === "pending" && l.status !== "sold" && (
                <a href={myBuy.checkoutUrl || `/paiement/${myBuy.checkoutId}`} className="mt-2 block w-full rounded-2xl bg-amber-500 py-2.5 font-black text-white">💳 {lang === "ar" ? "أكمل دفعك المعلق" : "Finir mon paiement"}</a>
              )}
              {waPhone && l.status === "active" && (
                <>
                  <a href={`https://wa.me/${waPhone}?text=${waMsg}`} target="_blank" rel="noreferrer" className="mt-3 block w-full rounded-2xl bg-[#25D366] py-3 font-black text-white shadow hover:opacity-90">💬 {lang === "ar" ? "واتساب — تسليم يد بيد" : "Contacter sur WhatsApp"}</a>
                  <p className="mt-1 text-center text-[10px] font-bold text-slate-400">🤝 {lang === "ar" ? "التسليم يد بيد متاح" : "Remise en main propre possible"}</p>
                </>
              )}
              <button onClick={() => setShowPhone(true)} className="mt-3 w-full rounded-2xl border-2 border-[#ff6e14] bg-white py-2.5 text-sm font-black text-[#ff6e14] transition hover:bg-orange-50">📞 {showPhone ? (l.phone || "—") : (lang === "ar" ? "أظهر الرقم" : "Voir le numéro")}</button>
              <button onClick={toggleFav} className={`mt-2 w-full rounded-2xl py-2.5 text-sm font-bold transition ${fav ? "bg-red-50 text-[#c8102e] ring-1 ring-red-200" : "bg-slate-100 hover:bg-slate-200"}`}>
                {fav ? `❤️ ${lang === "ar" ? "في مفضلتك" : "Dans vos favoris"}` : `🤍 ${lang === "ar" ? "أضف للمفضلة" : "Ajouter aux favoris"}`}
              </button>
              {/* Message to seller */}
              <div className="mt-3">
                <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={2} placeholder={lang === "ar" ? "رسالتك للبائع..." : "Votre message..."} className="w-full rounded-2xl border-2 border-slate-200 px-4 py-2.5 text-sm font-bold outline-none transition focus:border-[#25D366]" />
                <button onClick={sendMsg} className="mt-2 w-full rounded-2xl bg-slate-900 py-3 text-sm font-black text-white transition hover:bg-black">✉️ {lang === "ar" ? "إرسال الرسالة" : "Envoyer un message"}</button>
              </div>
              <button onClick={() => { const r = prompt(lang === "ar" ? "سبب التبليغ؟" : "Motif du signalement ?"); if (r) fetch("/api/reports", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ listingId: id, reason: r }) }).then(() => alert("✅")); }} className="mt-2 w-full rounded-2xl py-2 text-xs font-bold text-slate-400">🚩 {lang === "ar" ? "تبليغ عن إعلان" : "Signaler"}</button>
            </div>
            <div className="rounded-3xl border-2 border-dashed border-orange-200 bg-orange-50 p-5">
              <p className="font-black">🚚 {lang === "ar" ? "اطلب التوصيل لباب الدار" : "Commander la livraison"}</p>
              <div className="mt-3 space-y-2 text-sm">
                <select value={dProv} onChange={(e) => setDProv(e.target.value)} className="w-full rounded-xl border px-3 py-2">
                  {DELIVERY_PROVIDERS.filter((p) => p.id !== "cash").map((p) => <option key={p.id} value={p.id}>{p.logo} {lang === "ar" ? p.ar : p.fr}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => setDType("home")} className={`rounded-xl px-3 py-2 font-bold ${dType === "home" ? "bg-[#0b2a5b] text-white" : "bg-white"}`}>{lang === "ar" ? "🏠 للمنزل" : "🏠 Domicile"}</button>
                  <button onClick={() => setDType("office")} className={`rounded-xl px-3 py-2 font-bold ${dType === "office" ? "bg-[#0b2a5b] text-white" : "bg-white"}`}>{lang === "ar" ? "🏢 للمكتب" : "🏢 Bureau"}</button>
                </div>
                <p className="rounded-xl bg-white p-2 text-center font-black text-[#0b2a5b]">💰 {formatPrice(fee, lang)} • ⏱️ 24-72h</p>
                <input value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} placeholder={lang === "ar" ? "الاسم الكامل" : "Nom complet"} className="w-full rounded-xl border px-3 py-2" />
                <input value={buyer.phone} onChange={(e) => setBuyer({ ...buyer, phone: e.target.value })} placeholder="05 / 06 / 07 ..." className="w-full rounded-xl border px-3 py-2" />
                <input value={buyer.commune} onChange={(e) => setBuyer({ ...buyer, commune: e.target.value })} placeholder={lang === "ar" ? "البلدية + العنوان" : "Commune + adresse"} className="w-full rounded-xl border px-3 py-2" />
                <button onClick={order} disabled={ordering} className="w-full rounded-xl bg-green-600 py-2.5 font-black text-white disabled:opacity-50">{ordering ? "..." : `✅ ${lang === "ar" ? "تأكيد الطلب" : "Commander"}`}</button>
                {track && <p className="rounded-xl bg-green-100 p-3 text-center text-sm font-black text-green-800">🎉 {lang === "ar" ? "تم! رقم التتبع:" : "Commande OK ! Suivi:"} <br />{track}</p>}
              </div>
            </div>
            <div className="rounded-3xl bg-[#0b2a5b] p-5 text-white">
              <p className="text-sm font-black">🛡️ {lang === "ar" ? "نصائح الأمان" : "Conseils sécurité"}</p>
              <ul className="mt-2 space-y-1 text-xs text-white/80">
                <li>• {lang === "ar" ? "تحقق من هوية البائع الموثقة 🪪" : "Vérifiez l'identité du vendeur 🪪"}</li>
                <li>• {lang === "ar" ? "ادفع عبر Chargily أو عند الاستلام" : "Payez via Chargily ou à la livraison"}</li>
                <li>• {lang === "ar" ? "افحص السلعة قبل الدفع" : "Inspectez avant de payer"}</li>
              </ul>
            </div>
          </div>
        </div>
        {similar.length > 0 && (
          <>
            <h3 className="mt-8 font-black text-[#0b2a5b]">{lang === "ar" ? "إعلانات مشابهة" : "Annonces similaires"}</h3>
            <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">{similar.map((x) => <ListingCard key={x.id} l={x} lang={lang} />)}</div>
          </>
        )}
      </div>
      {qrOpen && (
        <CcpQRModal
          sellerName={l.sellerName || ""}
          ccpRaw={l.sellerBaridiMob || ""}
          amount={l.price || 0}
          title={l.title}
          waPhone={waPhone}
          onClose={() => setQrOpen(false)}
        />
      )}
      <Footer />
    </div>
  );
}
