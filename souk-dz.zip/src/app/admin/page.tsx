"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, TickerMarquee } from "@/components/site";
import { TwoFACard } from "@/components/TwoFACard";
import { formatDZN } from "@/lib/data";
import { wilayaName } from "@/lib/data";

export default function Admin() {
  const { lang } = useLang();
  const [me, setMe] = useState<any>(null);
  const [tab, setTab] = useState("stats");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [threads, setThreads] = useState<any[]>([]);
  const [chatUser, setChatUser] = useState<string | null>(null);
  const [chatMsgs, setChatMsgs] = useState<any[]>([]);
  const [chatDraft, setChatDraft] = useState("");
  const chatBoxRef = useRef<HTMLDivElement>(null);

  // Chat polling
  useEffect(() => {
    if (tab !== "chats") return;
    let stop = false;
    const loadT = () => fetch("/api/chat/threads").then((r) => r.json()).then((d) => { if (!stop && Array.isArray(d)) setThreads(d); }).catch(() => {});
    const loadC = () => { if (!chatUser) return; fetch(`/api/chat?with=${chatUser}`).then((r) => r.json()).then((d) => { if (!stop && d.messages) setChatMsgs(d.messages); }).catch(() => {}); };
    loadT(); loadC();
    const iv = setInterval(() => { loadT(); loadC(); }, 12000);
    return () => { stop = true; clearInterval(iv); };
  }, [tab, chatUser]);
  useEffect(() => { if (chatBoxRef.current) chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight; }, [chatMsgs]);

  const sendChat = async () => {
    const body = chatDraft.trim();
    if (!body || !chatUser) return;
    setChatDraft("");
    await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ to: chatUser, body }) }).catch(() => {});
    fetch("/api/chat?with=" + chatUser).then((r) => r.json()).then((d) => d.messages && setChatMsgs(d.messages)).catch(() => {});
  };
  const quickChat = async (userId: string, text?: string) => {
    if (text) await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ to: userId, body: text }) }).catch(() => {});
    setChatUser(userId);
    setTab("chats");
    setLoading(false);
    setTimeout(() => {
      fetch(`/api/chat?with=${userId}`).then((r) => r.json()).then((d) => d.messages && setChatMsgs(d.messages)).catch(() => {});
      fetch("/api/chat/threads").then((r) => r.json()).then((d) => Array.isArray(d) && setThreads(d)).catch(() => {});
    }, 300);
  };

  useEffect(() => {
    fetch("/api/auth/me").then(async (r) => {
      if (!r.ok) { window.location.href = "/auth/login?next=/admin"; return; }
      const m = await r.json();
      if (!m.isAdmin) { window.location.href = "/dashboard"; return; }
      setMe(m);
      load("stats");
    });
  }, []);

  const load = async (t: string) => {
    setTab(t); setLoading(true);
    if (t === "ticker") {
      const r = await fetch("/api/ticker").then((x) => x.json());
      setData(r); setLoading(false);
      return;
    }
    const r = await fetch(`/api/admin?tab=${t}`).then((x) => x.json());
    setData(r); setLoading(false);
  };
  const logout = async () => {
    if (!confirm(lang === "ar" ? "تسجيل الخروج من لوحة الأدمن؟" : "Déconnexion du panneau admin ?")) return;
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/";
  };

  const act = async (action: string, id: string, value?: string) => {
    if (action.includes("reject") || action.includes("suspend")) {
      const v = prompt(lang === "ar" ? "السبب؟" : "Motif ?");
      if (v === null) return;
      value = v || value;
    } else if (!confirm("Confirmer ؟ تأكيد؟")) return;
    await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, id, value }) });
    load(tab);
  };

  if (!me) return <div className="grid min-h-screen place-items-center">⏳...</div>;

  const [pmAdmin, setPmAdmin] = useState<Record<string, boolean> | null>(null);

  useEffect(() => {
    if (tab !== "pay") return;
    fetch("/api/payment-methods").then((r) => r.json()).then((d) => d.methods && setPmAdmin(d.methods)).catch(() => {});
  }, [tab]);

  const togglePm = async (key: string) => {
    if (!pmAdmin) return;
    const next = { ...pmAdmin, [key]: !pmAdmin[key] };
    setPmAdmin(next); // optimistic
    const r = await fetch("/api/payment-methods", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ methods: next }) }).then((x) => x.json()).catch(() => null);
    if (r?.methods) setPmAdmin(r.methods);
    else fetch("/api/payment-methods").then((x) => x.json()).then((d) => d.methods && setPmAdmin(d.methods)).catch(() => {});
  };

  const PM_META: { key: string; icon: string; a: string; f: string; dA: string; dF: string }[] = [
    { key: "edahabia", icon: "🥇", a: "البطاقة الذهبية (EDAHABIA)", f: "Carte Or (EDAHABIA)", dA: "بريد الجزائر — عبر بوابة Chargily Pay", dF: "Algérie Poste — via la porte Chargily Pay" },
    { key: "cib", icon: "💳", a: "بطاقة بنكية (CIB)", f: "Carte bancaire (CIB)", dA: "SATIM / Visa / Mastercard — عبر Chargily Pay", dF: "SATIM / Visa / Mastercard — via Chargily Pay" },
    { key: "baridi", icon: "📱", a: "بريدي موب (BaridiMob)", f: "BrédiMob", dA: "تحويل بريدي مباشر إلى حساب البائع + تأكيد واتساب", dF: "Virement postal direct + confirmation WhatsApp" },
    { key: "cod", icon: "💵", a: "الدفع عند الاستلام", f: "Paiement à la livraison", dA: "ترتيب الدفع عبر واتساب البائع (توصيل أو يد بيد)", dF: "Coordination via WhatsApp du vendeur" },
  ];

  const tabs: [string, string][] = [["stats", "📊"], ["pay", lang === "ar" ? "⚙️ طرق الدفع" : "⚙️ Paiement"], ["chats", "💬 " + (lang === "ar" ? "المحادثات" : "Chats")], ["resets", lang === "ar" ? "🔑 استرجاع كلمة السر" : "🔑 Resets"], ["ticker", lang === "ar" ? "📰 الشريط الإخباري" : "📰 Bandeau"], ["users", lang === "ar" ? "👥 المستخدمون" : "👥 Utilisateurs"], ["listings", lang === "ar" ? "📋 الإعلانات" : "📋 Annonces"], ["payments", "💳 Paiements"], ["stores", "🏬 Boutiques"], ["reports", "🚩 Signalements"]];

  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-black text-[#0b2a5b]">🛠️ {lang === "ar" ? "لوحة تحكم الأدمن" : "Panneau Admin"}</h1>
          <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-black text-green-700">● LIVE</span>
          <div className="ms-auto flex items-center gap-2">
            <span className="hidden rounded-xl bg-white px-3 py-2 text-xs font-bold text-slate-500 md:block">👤 {me.firstName}</span>
            <Link href="/" className="rounded-xl bg-white px-3 py-2 text-sm font-bold text-slate-600 hover:bg-slate-100">🏠</Link>
            <button onClick={logout} className="rounded-xl bg-red-600 px-4 py-2 text-sm font-black text-white hover:bg-red-700">🚪 {lang === "ar" ? "خروج" : "Déconnexion"}</button>
          </div>
        </div>
        <div className="mt-4 flex gap-2 overflow-x-auto no-scrollbar">
          {tabs.map(([k, l]) => <button key={k} onClick={() => load(k)} className={`whitespace-nowrap rounded-xl px-4 py-2 text-sm font-black ${tab === k ? "bg-[#0b2a5b] text-white" : "bg-white"}`}>{l}</button>)}
        </div>

        {loading ? <div className="mt-6 grid gap-3 md:grid-cols-4">{[1,2,3,4].map((i) => <div key={i} className="h-28 animate-pulse rounded-2xl bg-white" />)}</div> : (
          <>
            {tab === "stats" && data && (
              <div>
                <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
                  {[["👥", data.users, lang === "ar" ? "مستخدم" : "Utilisateurs"], ["📋", data.listings, lang === "ar" ? "إعلان" : "Annonces"], ["💰", formatDZN(Number(data.revenue)) + " DA", lang === "ar" ? "مداخيل" : "Revenus"], ["🏬", data.stores, lang === "ar" ? "متجر" : "Boutiques"]].map(([e, v, l], i) => (
                    <div key={i} className="rounded-3xl bg-white p-5 text-center shadow-sm">
                      <p className="text-3xl">{e}</p>
                      <p className="mt-1 text-2xl font-black text-[#0b2a5b]">{v as string}</p>
                      <p className="text-xs text-slate-400">{l as string}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid gap-3 md:grid-cols-2">
                  <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 text-sm font-bold">⏳ {lang === "ar" ? `حسابات بانتظار التوثيق: ${data.pendingUsers}` : `Comptes en attente: ${data.pendingUsers}`} <button onClick={() => load("users")} className="ms-2 rounded-lg bg-amber-500 px-3 py-1 text-white">→</button></div>
                  <div className="rounded-2xl bg-blue-50 border border-blue-200 p-4 text-sm font-bold">💳 {lang === "ar" ? `مدفوعات معلقة: ${data.pendingPayments}` : `Paiements en attente: ${data.pendingPayments}`} <button onClick={() => load("payments")} className="ms-2 rounded-lg bg-blue-600 px-3 py-1 text-white">→</button></div>
                </div>
                <div className="mt-4 rounded-3xl bg-white p-5">
                  <p className="font-black">🆕 {lang === "ar" ? "أحدث الإعلانات" : "Dernières annonces"}</p>
                  <div className="mt-2 space-y-2">{(data.recent || []).map((l: any) => <div key={l.id} className="flex items-center gap-2 rounded-xl bg-slate-50 p-2 text-sm"><span className="flex-1 truncate font-bold">{l.title}</span><span className="font-black">{formatDZN(Number(l.price))} DA</span><span className="text-xs">{l.status}</span></div>)}</div>
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <div className="rounded-3xl bg-slate-900 p-5 font-mono text-[11px] text-green-300" dir="ltr">
                    Chargily mode: <span className={data.chargilyMode === "live" ? "text-red-400 font-bold" : data.chargilyMode === "test" ? "text-amber-300 font-bold" : "text-slate-300 font-bold"}>{String(data.chargilyMode).toUpperCase()}</span><br />
                    Webhook: /api/payments/webhook (HMAC-SHA256) ✅<br />
                    API: pay.chargily.dz/api/v2/checkouts ✅<br />
                    Yalidine / Maystro / EMS / Noest APIs ✅
                  </div>
                  <div className="rounded-3xl bg-white p-5 text-sm">
                    <p className="font-black">🔑 {lang === "ar" ? "إعدادات Chargily Pay" : "Config Chargily Pay"}</p>
                    <p className="mt-1 text-xs text-slate-500" dir="ltr">CHARGILY_API_KEY: {String(data.chargilyMode).toUpperCase()} (test_sk_...)<br />Webhook: /api/payments/webhook → Supabase ✅</p>
                    <p className="mt-2 text-xs font-bold text-slate-600">
                      {data.chargilyMode === "live" ? (lang === "ar" ? "✅ مفاتيح الإنتاج LIVE مفوّضة — الدفع الحقيقي مفعّل" : "✅ Clés LIVE actives") :
                       data.chargilyMode === "test" ? (lang === "ar" ? "✅ مفاتيح الاختبار TEST مفوّضة — الدفع الحقيقي ببطاقات Chargily التجريبية مفعّل، وWebhook موقّع يُحوَّل أيضاً إلى Supabase" : "✅ Clés TEST actives — paiement réel avec cartes de test, webhook signé + relais Supabase") :
                       (lang === "ar" ? "وضع DEMO: أضف CHARGILY_API_KEY لتفعيل الدفع الحقيقي" : "Mode démo : définissez CHARGILY_API_KEY")}
                    </p>
                  </div>
                </div>
                <TwoFACard />
              </div>
            )}

            {tab === "ticker" && data && <TickerAdmin data={data} />}

            {tab === "users" && (
              <div className="mt-4 space-y-2">
                {(Array.isArray(data) ? data : []).map((u: any) => (
                  <div key={u.id} className="rounded-2xl bg-white p-4">
                    <div className="flex flex-wrap items-center gap-2 text-sm">
                      {u.avatarUrl ? <img src={u.avatarUrl} alt="" className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200" /> : <span className="grid h-9 w-9 place-items-center rounded-full bg-slate-200 text-sm font-black">👤</span>}
                      <span className="font-black">{u.firstName} {u.lastName} {u.plan === "vip" ? "⭐" : ""} {u.isAdmin ? "🛡️" : ""}</span>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-black ${u.status === "verified" ? "bg-green-100 text-green-700" : u.status === "pending" ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-600"}`}>{u.status}</span>
                      <span className="text-xs text-slate-400" dir="ltr">{u.email} • {u.phone} • {wilayaName(u.wilayaCode || "16", lang)}</span>
                      <span className="ms-auto flex flex-wrap gap-1">
                        <button onClick={() => quickChat(u.id)} title={lang === "ar" ? "مراسلة المستخدم" : "Messager"} className="rounded-lg bg-[#25D366] px-3 py-1 text-xs font-black text-white">💬</button>
                        <button onClick={() => act("verify_user", u.id)} className="rounded-lg bg-green-600 px-3 py-1 text-xs font-bold text-white">✅</button>
                        <button onClick={() => act("reject_user", u.id)} className="rounded-lg bg-red-100 px-3 py-1 text-xs font-bold text-red-700">❌</button>
                        <button onClick={() => act("suspend_user", u.id)} className="rounded-lg bg-slate-200 px-3 py-1 text-xs font-bold">⛔</button>
                        {!u.isAdmin && <button onClick={() => act("make_admin", u.id)} className="rounded-lg bg-[#0b2a5b] px-3 py-1 text-xs font-bold text-white">🛡️ admin</button>}
                      </span>
                    </div>
                    {(u.idFrontUrl || u.idBackUrl) && (
                      <div className="mt-2 flex gap-2">
                        {u.idFrontUrl && <a href={u.idFrontUrl} target="_blank" className="overflow-hidden rounded-xl border"><img src={u.idFrontUrl} className="h-20 w-32 object-cover" /><p className="bg-slate-50 py-1 text-center text-[10px] font-bold">Recto / أمام</p></a>}
                        {u.idBackUrl && <a href={u.idBackUrl} target="_blank" className="overflow-hidden rounded-xl border"><img src={u.idBackUrl} className="h-20 w-32 object-cover" /><p className="bg-slate-50 py-1 text-center text-[10px] font-bold">Verso / خلف</p></a>}
                      </div>
                    )}
                    {u.rejectReason && <p className="mt-1 text-xs text-red-500">📝 {u.rejectReason}</p>}
                  </div>
                ))}
              </div>
            )}

            {tab === "listings" && (
              <div className="mt-4 space-y-2">
                {(Array.isArray(data) ? data : []).map((l: any) => (
                  <div key={l.id} className="flex flex-wrap items-center gap-2 rounded-2xl bg-white p-3 text-sm">
                    <span className="flex-1 truncate font-bold">{l.title} <span className="text-xs text-slate-400">({formatDZN(Number(l.price))} DA • {l.wilayaCode} • {l.status})</span></span>
                    <button onClick={() => act("moderate_listing", l.id, "active")} className="rounded-lg bg-green-100 px-3 py-1 text-xs font-bold text-green-700">✅ نشر</button>
                    <button onClick={() => act("moderate_listing", l.id, "rejected")} className="rounded-lg bg-red-100 px-3 py-1 text-xs font-bold text-red-700">❌ رفض</button>
                    <button onClick={() => act("feature_listing", l.id, l.isFeatured ? "false" : "true")} className="rounded-lg bg-amber-100 px-3 py-1 text-xs font-bold">⭐ {l.isFeatured ? "إلغاء التمييز" : "تمييز"}</button>
                    <Link href={`/annonces/${l.id}`} className="rounded-lg bg-slate-100 px-3 py-1 text-xs font-bold">👁️</Link>
                  </div>
                ))}
              </div>
            )}

            {tab === "payments" && (
              <div className="mt-4 space-y-2">
                {(Array.isArray(data) ? data : []).map((p: any) => (
                  <div key={p.id} className="flex flex-wrap items-center gap-2 rounded-2xl bg-white p-3 text-sm">
                    <span className="font-black">{formatDZN(Number(p.amount))} DA</span>
                    <span className="text-xs text-slate-400">{p.type === "purchase" ? `🛒 ${lang === "ar" ? "شراء منتج" : "Achat"}` : p.type === "listing_fee" ? `📋 ${lang === "ar" ? "رسم إعلان" : "Frais annonce"}` : "⭐ VIP"} • <span dir="ltr">{p.checkoutId}</span></span>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-black ${p.status === "paid" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>{p.status}</span>
                    {p.status === "pending" && <button onClick={() => act("confirm_payment", p.id)} className="ms-auto rounded-lg bg-green-600 px-3 py-1 text-xs font-bold text-white">✅ تأكيد يدوي</button>}
                  </div>
                ))}
              </div>
            )}

            {tab === "stores" && (
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                {(Array.isArray(data) ? data : []).map((s: any) => (
                  <div key={s.id} className="rounded-2xl bg-white p-4 text-sm">
                    <p className="font-black">🏬 {s.name}</p>
                    <p className="text-xs text-slate-400" dir="ltr">{s.slug} • paid until: {s.paidUntil ? new Date(s.paidUntil).toLocaleDateString() : "—"}</p>
                    <p className="text-xs">{s.description}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === "pay" && (
              <div className="mt-4 max-w-2xl space-y-3">
                <p className="rounded-2xl bg-blue-50 border border-blue-200 p-3 text-xs font-bold text-blue-800">
                  ️ {lang === "ar"
                    ? "فعّل أو جمّد أي طريقة دفع — التغير يُطبَّق فوراً على كل صفحات الإعلانات. الطرق المجمدة تختفي من واجهة المشتري."
                    : "Activez ou congelez une méthode — appliqué instantanément. Les méthodes gelées disparaissent de la page annonce."}
                </p>
                {!pmAdmin && <div className="rounded-2xl bg-white p-8 text-center text-sm font-bold text-slate-400">⏳...</div>}
                {pmAdmin && PM_META.map((m) => {
                  const on = pmAdmin[m.key] !== false;
                  return (
                    <div key={m.key} className="flex items-center gap-3 rounded-2xl bg-white p-4">
                      <span className="text-3xl">{m.icon}</span>
                      <div className="flex-1">
                        <p className="text-sm font-black text-slate-800">{lang === "ar" ? m.a : m.f}</p>
                        <p className="text-[11px] font-bold text-slate-400">{lang === "ar" ? m.dA : m.dF}</p>
                      </div>
                      <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-black ${on ? "bg-green-100 text-green-700" : "bg-slate-200 text-slate-500"}`}>
                        {on ? (lang === "ar" ? "مفعّلة" : "Active") : (lang === "ar" ? "مجمّدة" : "Gelée")}
                      </span>
                      <button
                        onClick={() => togglePm(m.key)}
                        className={`relative h-7 w-12 shrink-0 rounded-full transition ${on ? "bg-green-500" : "bg-slate-300"}`}
                        title={on ? (lang === "ar" ? "اضغط للتجميد" : "Cliquez pour geler") : (lang === "ar" ? "اضغط للتفعيل" : "Cliquez pour activer")}
                      >
                        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? "start-6" : "start-1"}`} />
                      </button>
                    </div>
                  );
                })}
                {pmAdmin && !Object.values(pmAdmin).some(Boolean) && (
                  <p className="rounded-2xl bg-red-50 border border-red-200 p-3 text-xs font-black text-red-600">
                    🚨 {lang === "ar" ? "كل طرق الدفع مجمّدة حالياً! المشترون لا يستطيعون الشراء." : "Toutes les méthodes sont gelées ! Les acheteurs ne peuvent pas acheter."}
                  </p>
                )}
              </div>
            )}

            {tab === "chats" && (
              <div className="mt-4 grid gap-3 lg:grid-cols-[300px_1fr]">
                <div className="max-h-[28rem] space-y-2 overflow-y-auto pe-1">
                  {threads.map((t) => (
                    <button key={t.userId} onClick={() => setChatUser(t.userId)} className={`w-full rounded-2xl bg-white p-3 text-start transition ${chatUser === t.userId ? "ring-2 ring-[#25D366]" : "hover:ring-1 hover:ring-slate-300"}`}>
                      <div className="flex items-center gap-2.5">
                        {t.avatarUrl ? <img src={t.avatarUrl} alt="" className="h-10 w-10 rounded-full object-cover" /> : <span className="grid h-10 w-10 place-items-center rounded-full bg-slate-200 text-sm font-black">👤</span>}
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-black">{t.name} {t.plan === "vip" ? "⭐" : ""}</p>
                          <p className="truncate text-xs text-slate-400" dir="ltr">{t.phone}</p>
                        </div>
                        {t.unread > 0 && <span className="grid h-6 min-w-6 shrink-0 place-items-center rounded-full bg-red-500 px-1.5 text-xs font-black text-white">{t.unread}</span>}
                      </div>
                      {t.lastBody && <p className="mt-1.5 truncate text-xs font-bold text-slate-500">{t.fromMe ? "→ " : "← "}{t.lastBody}</p>}
                    </button>
                  ))}
                  {!threads.length && <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-400">{lang === "ar" ? "لا محادثات بعد — عندما يرسل مستخدم رسالة ستظهر هنا" : "Aucune conversation pour l'instant"}</p>}
                </div>
                <div className="flex max-h-[28rem] flex-col overflow-hidden rounded-2xl bg-white">
                  {chatUser ? (
                    <>
                      <div className="border-b px-4 py-3 text-sm font-black">💬 {threads.find((t) => t.userId === chatUser)?.name || "..."}</div>
                      <div ref={chatBoxRef} className="h-80 flex-1 space-y-2 overflow-y-auto bg-slate-50 p-3">
                        {chatMsgs.map((m) => {
                          const mine = m.senderId === me?.id;
                          return (
                            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                              <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm font-bold ${mine ? "rounded-br-md bg-[#0b2a5b] text-white" : "rounded-bl-md bg-white text-slate-800 shadow"}`}>
                                <p className="whitespace-pre-line break-words">{m.body}</p>
                                <p className={`mt-1 text-right text-[10px] ${mine ? "text-white/50" : "text-slate-400"}`} dir="ltr">{new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
                              </div>
                            </div>
                          );
                        })}
                        {!chatMsgs.length && <p className="p-8 text-center text-sm font-bold text-slate-400">— {lang === "ar" ? "ابدأ المحادثة" : "Démarrez la conversation"} —</p>}
                      </div>
                      <div className="flex gap-2 border-t p-3">
                        <input value={chatDraft} onChange={(e) => setChatDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && sendChat()} placeholder={lang === "ar" ? "اكتب الرسالة هنا..." : "Écrivez ici..."} className="flex-1 rounded-xl bg-slate-100 px-4 py-2.5 text-sm font-bold outline-none focus:ring-2 focus:ring-[#25D366]/40" />
                        <button onClick={sendChat} className="rounded-xl bg-[#25D366] px-5 text-lg font-black text-white transition hover:scale-105">➤</button>
                      </div>
                    </>
                  ) : (
                    <div className="grid flex-1 place-items-center p-10 text-sm font-bold text-slate-400">{lang === "ar" ? "👈 اختر محادثة من القائمة" : "Choisissez une conversation"}</div>
                  )}
                </div>
              </div>
            )}

            {tab === "resets" && (
              <div className="mt-4 space-y-3">
                <p className="rounded-2xl bg-blue-50 border border-blue-200 p-3 text-xs font-bold text-blue-800">
                  💡 {lang === "ar" ? "راجع بطاقة التعريف المرفوعة عند التسجيل، وتأكد أن الرقم صحيح، ثم اضغط «تأكيد الهوية» — سيُنسخ رابط إعادة التعيين تلقائياً، أرسله للشخص عبر واتساب." : "Vérifiez la CNI et le numéro, puis cliquez «Approuver» — le lien de réinitialisation est copié automatiquement, envoyez-le au client (WhatsApp)."}
                </p>
                {(Array.isArray(data) ? data : []).map((r: any) => (
                  <div key={r.id} className="rounded-2xl bg-white p-4">
                    <div className="flex flex-wrap items-center gap-3 text-sm">
                      <span className="text-2xl">🔑</span>
                      <div className="flex-1">
                        <p className="font-black">{r.user?.name} <span dir="ltr">• {r.phone}</span></p>
                        <p className="text-xs text-slate-400">{new Date(r.requestedAt).toLocaleString(lang === "ar" ? "ar-DZ" : "fr-FR")} — <span dir="ltr">{r.user?.email}</span></p>
                      </div>
                      <span className={`rounded-full px-3 py-1 text-xs font-black ${r.status === "pending" ? "bg-amber-100 text-amber-700" : r.status === "approved" ? "bg-blue-100 text-blue-700" : r.status === "used" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                        {r.status === "pending" ? (lang === "ar" ? "⏳ قيد المراجعة" : "En attente") : r.status === "approved" ? "📩 رابط جاهز" : r.status === "used" ? "✅ مستعمل" : "❌ مرفوض"}
                      </span>
                      {r.status === "pending" && (
                        <div className="flex gap-1">
                          <button
                            onClick={async () => {
                              if (!confirm(lang === "ar" ? "هل تأكدت من هوية الشخص (بطاقة التعريف) ورقم هاتفه؟" : "Identité et numéro confirmés ?")) return;
                              const res = await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "approve_reset", id: r.id }) }).then((x) => x.json());
                              if (res.token) {
                                const link = `${window.location.origin}/auth/reset?token=${res.token}`;
                                await navigator.clipboard.writeText(link).catch(() => {});
                                alert((lang === "ar" ? "✅ تم التأكيد — الرابط نُسخ للحافظة، أرسله للشخص:\n\n" : "Approuvé — lien copié :\n\n") + link);
                              }
                              load("resets");
                            }}
                            className="rounded-lg bg-green-600 px-3 py-1.5 text-xs font-black text-white"
                          >
                            ✅ {lang === "ar" ? "تأكيد الهوية + رابط" : "Approuver + lien"}
                          </button>
                          <button
                            onClick={async () => {
                              if (!confirm(lang === "ar" ? "رفض الطلب؟" : "Refuser ?")) return;
                              await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reject_reset", id: r.id }) });
                              load("resets");
                            }}
                            className="rounded-lg bg-red-100 px-3 py-1.5 text-xs font-bold text-red-700"
                          >
                            ❌
                          </button>
                        </div>
                      )}
                      {r.status === "approved" && r.token && (
                        <>
                          <code className="max-w-[180px] truncate rounded-lg bg-slate-900 px-2 py-1 text-[10px] text-green-300" dir="ltr" title={`${window.location.origin}/auth/reset?token=${r.token}`}>/auth/reset?token={String(r.token).slice(0, 8)}…</code>
                          <button
                            onClick={() => quickChat(r.userId, `${lang === "ar" ? "مرحباً" : "Bonjour"} ${r.user?.name || ""} 👋\n${lang === "ar" ? "رابط إعادة تعيين كلمة السر (لمرة واحدة):" : "Lien de réinitialisation du mot de passe (usage unique) :"}\n${window.location.origin}/auth/reset?token=${r.token}\n\n— Souq-DZ 🇩`)}
                            className="rounded-lg bg-[#0b2a5b] px-3 py-1.5 text-xs font-black text-white transition hover:scale-105"
                          >
                            💬 {lang === "ar" ? "شات" : "Chat"}
                          </button>
                          <a
                            href={`https://wa.me/213${String(r.phone).replace(/\D/g, "").slice(1)}?text=${encodeURIComponent(`🔑 Souq-DZ — ${lang === "ar" ? "رابط إعادة تعيين كلمة السر (لمرة واحدة):" : "Lien de réinitialisation (usage unique) :"}\n${window.location.origin}/auth/reset?token=${r.token}`)}`}
                            target="_blank"
                            rel="noreferrer"
                            className="rounded-lg bg-[#25D366] px-3 py-1.5 text-xs font-black text-white transition hover:scale-105"
                          >
                            📲 {lang === "ar" ? "واتساب" : "WhatsApp"}
                          </a>
                        </>
                      )}
                    </div>
                    {(r.user?.idFrontUrl || r.user?.idBackUrl) && (
                      <div className="mt-3 flex gap-3 border-t border-slate-100 pt-3">
                        {r.user?.idFrontUrl && (
                          <a href={r.user.idFrontUrl} target="_blank" className="block">
                            <img src={r.user.idFrontUrl} className="h-24 w-36 rounded-xl border object-cover" />
                            <p className="mt-1 text-center text-[10px] font-bold text-slate-400">🪪 {lang === "ar" ? "بطاقة التعريف — أمام" : "CNI — Recto"}</p>
                          </a>
                        )}
                        {r.user?.idBackUrl && (
                          <a href={r.user.idBackUrl} target="_blank" className="block">
                            <img src={r.user.idBackUrl} className="h-24 w-36 rounded-xl border object-cover" />
                            <p className="mt-1 text-center text-[10px] font-bold text-slate-400">🪪 {lang === "ar" ? "بطاقة التعريف — خلف" : "CNI — Verso"}</p>
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {(!data || !data.length) && <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-400">✅ {lang === "ar" ? "لا طلبات استرجاع حالياً" : "Aucune demande de réinitialisation"}</p>}
              </div>
            )}

            {tab === "reports" && (
              <div className="mt-4 space-y-2">
                {(Array.isArray(data) ? data : []).map((r: any) => (
                  <div key={r.id} className="rounded-2xl bg-white p-3 text-sm"><b>🚩 {r.listingId.slice(0, 8)}</b> — {r.reason} <span className="text-xs text-slate-400">{new Date(r.createdAt).toLocaleString()}</span></div>
                ))}
                {(!data || !data.length) && <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-400">✅ {lang === "ar" ? "لا تبليغات" : "Aucun signalement"}</p>}
              </div>
            )}
          </>
        )}
        </div>
      <Footer />
    </div>
  );
}

function TickerAdmin({ data }: { data: any }) {
  const { lang } = useLang();
  const [itemsText, setItemsText] = useState<string>(Array.isArray(data.items) ? data.items.join("\n") : "");
  const [speed, setSpeed] = useState(data.speed || 45);
  const [size, setSize] = useState(data.fontSize || 13);
  const [color, setColor] = useState(data.color || "#ffffff");
  const [enabled, setEnabled] = useState(data.enabled ?? true);
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState(false);

  const items = itemsText.split("\n").map((s) => s.trim()).filter(Boolean);

  const save = async () => {
    setBusy(true);
    const r = await fetch("/api/ticker", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items, speed, fontSize: size, color, enabled }) });
    const d = await r.json();
    setBusy(false);
    if (d.ok) { setOk(true); setTimeout(() => setOk(false), 2500); }
    else alert(d.error || "Error");
  };

  return (
    <div className="mt-4 grid gap-4 lg:grid-cols-2">
      <div className="space-y-4 rounded-3xl bg-white p-5">
        <div>
          <label className="text-sm font-black">{lang === "ar" ? "📝 الأخبار والإعلانات (سطر = خبر)" : "📝 Annonces (une ligne = un item)"}</label>
          <textarea value={itemsText} onChange={(e) => setItemsText(e.target.value)} rows={6} dir="auto" className="mt-1 w-full rounded-xl border px-4 py-2.5 text-sm leading-relaxed" />
          <p className="text-[11px] text-slate-400">{lang === "ar" ? "اتركه فارغاً لإخفاء الشريط بالكامل." : "Laissez vide pour masquer."}</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="text-sm font-black">⏱️ {lang === "ar" ? "سرعة الحركة" : "Vitesse"}: <b>{speed} {lang === "ar" ? "ثانية" : "s"}</b> {lang === "ar" ? "(أصغر = أسرع)" : "(plus petit = plus rapide)"}</label>
            <input type="range" min={10} max={120} step={5} value={speed} onChange={(e) => setSpeed(Number(e.target.value))} className="mt-1 w-full accent-[#ff6e14]" />
          </div>
          <div>
            <label className="text-sm font-black">🔠 {lang === "ar" ? "حجم الخط" : "Taille police"}: <b>{size}px</b></label>
            <input type="range" min={10} max={26} step={1} value={size} onChange={(e) => setSize(Number(e.target.value))} className="mt-1 w-full accent-[#ff6e14]" />
          </div>
        </div>
        <div>
          <label className="text-sm font-black">🎨 {lang === "ar" ? "لون الخط" : "Couleur police"}</label>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-14 cursor-pointer rounded-lg border" />
            {[["#ffffff", "أبيض"], ["#ffd60a", "أصفر"], ["#3ddc84", "أخضر"], ["#ff6e14", "برتقالي"], ["#ffd166", "ذهبي"]].map(([c, n]) => (
              <button key={c} type="button" onClick={() => setColor(c)} className={`h-8 w-8 rounded-full border-2 ${color === c ? "border-[#0b2a5b] scale-110" : "border-slate-200"}`} style={{ background: c }} title={n} />
            ))}
            <span className="rounded-lg bg-slate-100 px-3 py-1 text-xs font-bold" dir="ltr">{color}</span>
          </div>
        </div>
        <label className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm font-bold">
          <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
          {enabled ? (lang === "ar" ? "✅ الشريط مفعّل" : "✅ Bandeau actif") : (lang === "ar" ? "️ الشريط موقوف" : "⏸️ Bandeau désactivé")}
        </label>
        <button onClick={save} disabled={busy} className="btn-brand w-full rounded-2xl py-3 font-black disabled:opacity-50">{busy ? "⏳..." : (lang === "ar" ? "💾 حفظ و تطبيق فوراً" : "💾 Enregistrer")}</button>
        {ok && <p className="rounded-xl bg-green-100 p-2 text-center text-sm font-black text-green-700">✅ {lang === "ar" ? "تم الحفظ — الشريط يتحدث لدى الزوار فوراً" : "Enregistré — appliqué immédiatement"}</p>}
      </div>
      <div>
        <p className="text-sm font-black text-[#0b2a5b]">👁️ {lang === "ar" ? "معاينة مباشرة" : "Aperçu en direct"}</p>
        <div className="mt-2 overflow-hidden rounded-2xl">
          {enabled && items.length ? (
            <div className="overflow-hidden bg-[#071b3a]">
              <div className="flex items-center">
                <span className="shrink-0 bg-[#c8102e] px-3 py-1.5 text-[11px] font-black text-white">📰 {lang === "ar" ? "أخبار & عروض" : "Actus & Offres"}</span>
                <div className="relative flex-1 py-1.5">
                  <TickerMarquee items={items} speed={speed} size={size} color={color} />
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl bg-white p-8 text-center text-sm text-slate-400">{lang === "ar" ? "الشريط موقوف أو فارغ" : "Bandeau désactivé ou vide"}</div>
          )}
        </div>
        <div className="mt-3 rounded-2xl bg-slate-50 p-4 text-xs text-slate-500">
          💡 {lang === "ar" ? "نصائح: استغل الشريط لعروض VIP، تواريخ الأعياد، حملات التوصيل المجاني، أو تنبيهات مهمة. يراه الزوار في أعلى كل صفحة ويتوقف عند مرور الفأرة." : "Astuce : promotions VIP, dates de fêtes, livraison gratuite… Visible en haut de chaque page, pause au survol."}
        </div>
      </div>
    </div>
  );
}
