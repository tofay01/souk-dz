"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";
import { WILAYAS, CATEGORIES, PRICING } from "@/lib/data";

export default function Publier() {
  const { lang } = useLang();
  const { me, loading } = useMe();
  const [form, setForm] = useState({ title: "", description: "", price: "", category: "vehicules", wilayaCode: "16", commune: "", phone: "", condition: "used", deliveryAvailable: true });
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [video, setVideo] = useState<File | null>(null);
  const [vidPrev, setVidPrev] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && !me) window.location.href = "/auth/login?next=/publier";
    if (me) setForm((f) => ({ ...f, wilayaCode: (me as any).wilayaCode || "16" }));
  }, [loading, me]);

  const onFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const arr = Array.from(e.target.files || []).slice(0, 12);
    setFiles(arr);
    setPreviews(arr.map((f) => URL.createObjectURL(f)));
  };

  const onVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    if (!f) return;
    if (f.size > 60 * 1024 * 1024) { alert(lang === "ar" ? "حجم الفيديو يتجاوز 60MB" : "Vidéo > 60MB"); return; }
    setVideo(f);
    setVidPrev(URL.createObjectURL(f));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.title.length < 5) return alert(lang === "ar" ? "العنوان قصير" : "Titre trop court");
    if (form.description.length < 10) return alert(lang === "ar" ? "الوصف قصير" : "Description trop courte");
    if (files.length < 8) return alert(lang === "ar" ? "⚠️ يجب إضافة 8 صور على الأقل للمنتج (من جهازك أو هاتفك)" : "⚠️ Ajoutez au moins 8 photos du produit (depuis votre appareil)");
    setBusy(true);
    try {
      let urls: string[] = [];
      if (files.length) {
        const fd = new FormData();
        files.forEach((f) => fd.append("files", f));
        const up = await fetch("/api/upload", { method: "POST", body: fd }).then((r) => r.json());
        urls = up.urls || [];
      }
      if (urls.length < 8) { setBusy(false); return alert(lang === "ar" ? "بعض الصور غير صالحة — ارفع 8 صور JPG/PNG على الأقل" : "Certaines photos invalides — 8 JPG/PNG minimum"); }
      let videoUrl = "";
      if (video) {
        const fd = new FormData();
        fd.append("file", video);
        const up = await fetch("/api/upload", { method: "POST", body: fd }).then((r) => r.json());
        videoUrl = up.urls?.[0] || "";
      }
      // Accept both "185000" and European-style "185.000" input
      const priceNum = Number(String(form.price).replace(/[.\s,]/g, "")) || 0;
      const r = await fetch("/api/listings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, price: priceNum, images: urls, videoUrl }) });
      const d = await r.json();
      if (!r.ok) {
        alert(d.message || d.error);
        setBusy(false);
        return;
      }
      if (d.needPayment) {
        window.location.href = d.paymentUrl;
      } else {
        window.location.href = `/annonces/${d.listing.id}`;
      }
    } catch {
      alert("Error");
      setBusy(false);
    }
  };

  if (loading) return <div className="grid min-h-screen place-items-center">⏳...</div>;
  if (!me) return null;
  const isVip = (me as any).plan === "vip";
  const pending = (me as any).status === "pending";

  return (
    <div>
      <Navbar user={me as any} />
      <div className="mx-auto max-w-3xl px-4 py-6">
        <h1 className="text-2xl font-black text-[#0b2a5b]">＋ {lang === "ar" ? "انشر إعلانك" : "Publier une annonce"}</h1>
        {pending && <div className="mt-3 rounded-2xl bg-amber-50 border border-amber-200 p-4 text-sm font-bold text-amber-800">⏳ {lang === "ar" ? "حسابك قيد مراجعة الهوية — لن تتمكن من النشر حتى التوثيق. عادة أقل من 24 سا." : "Compte en vérification d'identité — publication activée après validation (<24h)."}</div>}
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <div className={`rounded-2xl border-2 p-3 ${!isVip ? "border-[#ff6e14] bg-orange-50" : "border-slate-100 bg-white"}`}>
            <p className="font-black">📋 {lang === "ar" ? "عادي" : "Classique"}</p>
            <p className="text-xs text-slate-500">50 DA / {lang === "ar" ? "للإعلان" : "par annonce"} • Chargily</p>
          </div>
          <div className={`rounded-2xl border-2 p-3 ${isVip ? "border-amber-400 bg-amber-50" : "border-slate-100 bg-white"}`}>
            <p className="font-black">⭐ VIP {isVip ? "✅" : ""}</p>
            <p className="text-xs text-slate-500">{lang === "ar" ? "نشر مجاني غير محدود" : "Illimité gratuit"} • <Link href="/tarifs" className="text-[#ff6e14] underline">5000 DA/an</Link></p>
          </div>
        </div>
        <form onSubmit={submit} className="mt-4 space-y-4 rounded-3xl bg-white p-5 md:p-7">
          <div>
            <label className="text-sm font-black">{lang === "ar" ? "العنوان *" : "Titre *"}</label>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={lang === "ar" ? "مثال: رونو سامبول 2019 نظيفة" : "Ex: Renault Symbol 2019 propre"} className="mt-1 w-full rounded-xl border px-4 py-2.5 text-sm outline-none focus:border-[#ff6e14]" />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-black">{lang === "ar" ? "التصنيف" : "Catégorie"}</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm">
                {CATEGORIES.filter((c) => c.slug !== "bonsplans").map((c) => <option key={c.slug} value={c.slug}>{c.icon} {lang === "ar" ? c.ar : c.fr}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-black">{lang === "ar" ? "السعر (دج) *" : "Prix (DA) *"}</label>
              <input type="text" inputMode="numeric" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="185.000" dir="ltr" className="mt-1 w-full rounded-xl border px-4 py-2.5 text-sm" />
            </div>
          </div>
          <div>
            <label className="text-sm font-black">{lang === "ar" ? "الوصف *" : "Description *"}</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={5} placeholder={lang === "ar" ? "الحالة، المدة، سبب البيع، طريقة التواصل..." : "État, durée, raison de vente..."} className="mt-1 w-full rounded-xl border px-4 py-2.5 text-sm" />
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="text-sm font-black">{lang === "ar" ? "الولاية" : "Wilaya"}</label>
              <select value={form.wilayaCode} onChange={(e) => setForm({ ...form, wilayaCode: e.target.value })} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm">
                {WILAYAS.map((w) => <option key={w.code} value={w.code}>{lang === "ar" ? `${w.code}-${w.ar}` : `${w.code}-${w.fr}`}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-black">{lang === "ar" ? "البلدية" : "Commune"}</label>
              <input value={form.commune} onChange={(e) => setForm({ ...form, commune: e.target.value })} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm" />
            </div>
            <div>
              <label className="text-sm font-black">{lang === "ar" ? "الهاتف" : "Téléphone"}</label>
              <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05..." className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm" />
            </div>
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            <div className="flex gap-2">
              <button type="button" onClick={() => setForm({ ...form, condition: "used" })} className={`flex-1 rounded-xl py-2 text-sm font-bold ${form.condition === "used" ? "bg-slate-900 text-white" : "bg-slate-100"}`}>♻️ {lang === "ar" ? "مستعمل" : "Occasion"}</button>
              <button type="button" onClick={() => setForm({ ...form, condition: "new" })} className={`flex-1 rounded-xl py-2 text-sm font-bold ${form.condition === "new" ? "bg-slate-900 text-white" : "bg-slate-100"}`}>✨ {lang === "ar" ? "جديد" : "Neuf"}</button>
            </div>
            <label className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm font-bold">
              <input type="checkbox" checked={form.deliveryAvailable} onChange={(e) => setForm({ ...form, deliveryAvailable: e.target.checked })} /> 🚚 {lang === "ar" ? "أقبل التوصيل" : "Livraison acceptée"}
            </label>
          </div>
          <div>
            <label className="text-sm font-black">
              📸 {lang === "ar" ? "الصور — 8 على الأقل (حتى 12)" : "Photos — 8 min (max 12)"}
              <span className={`ms-2 rounded-full px-2 py-0.5 text-[11px] ${files.length >= 8 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>{files.length}/8</span>
            </label>
            <label className={`mt-2 flex w-full cursor-pointer items-center justify-center gap-2.5 rounded-2xl px-4 py-4 text-[15px] font-black text-white shadow-md transition hover:opacity-90 active:scale-[0.99] ${files.length >= 8 ? "bg-green-600" : files.length ? "bg-amber-500" : "bg-[#ff6e14]"}`}>
              <span className="text-2xl">📸</span>
              <span className="text-center">
                {files.length >= 8
                  ? (lang === "ar" ? `✓ ${files.length} صور جاهزة — اضغط للاستبدال` : `✓ ${files.length} photos prêtes — cliquer pour remplacer`)
                  : files.length
                    ? (lang === "ar" ? `${files.length}/8 — أضف المزيد` : `${files.length}/8 — ajouter d'autres`)
                    : (lang === "ar" ? "تحميل الصور — 8 على الأقل" : "Télécharger les photos — 8 minimum")}
              </span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={onFiles} />
            </label>
            <p className="mt-1.5 text-[11px] font-bold text-slate-400">{lang === "ar" ? "التصوير مباشرة من كاميرا هاتفك أو اختيار من الجهاز — JPG/PNG/WebP" : "Photo directe depuis la caméra du téléphone — JPG/PNG/WebP"}</p>
            <div className="mt-2 grid grid-cols-4 gap-2">
              {previews.map((s, i) => <img key={i} src={s} className="h-16 w-full rounded-xl object-cover" />)}
              {Array.from({ length: Math.max(0, 8 - previews.length) }).map((_, i) => (
                <div key={`e${i}`} className="grid h-16 place-items-center rounded-xl border-2 border-dashed border-slate-200 text-lg text-slate-300">＋</div>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm font-black">🎬 {lang === "ar" ? "فيديو واحد للمنتج (اختياري)" : "Une vidéo du produit (optionnel)"}</label>
            {video && vidPrev ? (
              <div className="mt-1 overflow-hidden rounded-xl border-2 border-slate-200">
                <video src={vidPrev} controls className="max-h-48 w-full bg-black" />
                <div className="flex items-center justify-between bg-slate-50 px-3 py-1.5 text-[11px] font-bold text-slate-500">
                  <span className="truncate">{video.name} • {(video.size / 1024 / 1024).toFixed(1)}MB</span>
                  <button type="button" onClick={() => { setVideo(null); setVidPrev(""); }} className="font-black text-red-500">✕ {lang === "ar" ? "حذف" : "Retirer"}</button>
                </div>
              </div>
            ) : (
              <label className="mt-2 flex w-full cursor-pointer items-center justify-center gap-2.5 rounded-2xl bg-[#0b2a5b] px-4 py-4 text-[15px] font-black text-white shadow-md transition hover:opacity-90 active:scale-[0.99]">
                <span className="text-2xl">🎬</span>
                <span>{lang === "ar" ? "تحميل فيديو للمنتج (اختياري)" : "Télécharger une vidéo (optionnel)"}</span>
                <input type="file" accept="video/mp4,video/webm,video/quicktime" className="hidden" onChange={onVideo} />
              </label>
            )}
            <p className="mt-1.5 text-[11px] font-bold text-slate-400">MP4 / WebM — 60MB {lang === "ar" ? "كحد أقصى" : "max"}</p>
          </div>
          <button disabled={busy || pending} className="btn-brand w-full rounded-2xl py-3 font-black disabled:opacity-50">
            {busy ? "⏳..." : isVip ? `🚀 ${lang === "ar" ? "انشر مجاناً (VIP)" : "Publier gratuitement (VIP)"}` : `💳 ${lang === "ar" ? `ادفع ${PRICING.listingFee} دج وانشر عبر Chargily` : `Payer ${PRICING.listingFee} DA via Chargily`}`}
          </button>
          <p className="text-center text-[11px] text-slate-400">CIB 💳 • EDAHABIA 💳 • Chargily Pay ⚡ • {lang === "ar" ? "الدفع آمن" : "Paiement sécurisé"}</p>
        </form>
      </div>
      <Footer />
    </div>
  );
}
