"use client";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { Navbar, Footer, useMe } from "@/components/site";
import { WILAYAS, DELIVERY_PROVIDERS, deliveryFee, formatPrice } from "@/lib/data";

export default function Livraison() {
  const { lang } = useLang();
  const { me } = useMe();
  const [wilaya, setWilaya] = useState("31");
  const [type, setType] = useState<"home" | "office">("home");
  return (
    <div>
      <Navbar user={me} />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <h1 className="text-2xl font-black text-[#0b2a5b]">🚚 {lang === "ar" ? "التوصيل لـ 58 ولاية" : "Livraison 58 wilayas"}</h1>
        <p className="text-sm text-slate-500">{lang === "ar" ? "نحن مهيأون للربط المباشر عبر APIs مع Yalidine و Maystro و EMS و Noest — حالياً حاسبة فورية + تتبع." : "Prêt pour APIs Yalidine, Maystro, EMS, Noest — calculateur + suivi inclus."}</p>
        <div className="mt-4 rounded-3xl bg-white p-5">
          <div className="grid gap-2 md:grid-cols-3">
            <select value={wilaya} onChange={(e) => setWilaya(e.target.value)} className="rounded-xl border px-3 py-2.5 text-sm">
              {WILAYAS.map((w) => <option key={w.code} value={w.code}>{lang === "ar" ? `${w.code}-${w.ar}` : `${w.code}-${w.fr}`}</option>)}
            </select>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setType("home")} className={`rounded-xl py-2.5 text-sm font-bold ${type === "home" ? "bg-[#0b2a5b] text-white" : "bg-slate-100"}`}>🏠 {lang === "ar" ? "منزل" : "Domicile"}</button>
              <button onClick={() => setType("office")} className={`rounded-xl py-2.5 text-sm font-bold ${type === "office" ? "bg-[#0b2a5b] text-white" : "bg-slate-100"}`}>🏢 {lang === "ar" ? "مكتب" : "Bureau"}</button>
            </div>
            <div className="rounded-xl bg-green-50 px-3 py-2.5 text-center text-sm font-black text-green-800">⏱️ 24-72h</div>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-4">
            {DELIVERY_PROVIDERS.filter((p) => p.id !== "cash").map((p) => (
              <div key={p.id} className="rounded-2xl border p-4 text-center">
                <p className="text-3xl">{p.logo}</p>
                <p className="mt-1 font-black">{lang === "ar" ? p.ar : p.fr}</p>
                <p className="text-xl font-black text-[#0b2a5b]">{formatPrice(deliveryFee(p.id, type, wilaya), lang)}</p>
                <p className="text-[11px] text-slate-400">API: api.{p.id}.dz/v1 ✨ {lang === "ar" ? "جاهز للربط" : "prêt"}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-4 rounded-3xl bg-slate-900 p-5 font-mono text-[12px] text-green-300" dir="ltr">
          // Yalidine API — مثال الربط (جاهز)<br />
          POST https://api.yalidine.app/v1/parcels<br />
          Headers: X-API-ID, X-API-TOKEN<br />
          // Maystro — POST https://backend.maystro-delivery.com/api<br />
          // EMS — https://www.ems.dz/api • Noest — https://app.noest-dz.com/api
        </div>
      </div>
      <Footer />
    </div>
  );
}
